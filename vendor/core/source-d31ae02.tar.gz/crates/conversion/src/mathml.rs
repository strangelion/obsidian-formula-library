use latexsnipper_ast::{Block, Document, Formula, FormulaSource, Inline};
use latexsnipper_foundation::Result;

use crate::converter::Converter;
use crate::latex_utils::*;

pub struct MathmlConverter;
impl Converter for MathmlConverter {
    fn convert(&self, doc: &Document) -> Result<String> {
        convert_mathml(doc, MathmlMode::Standard)
    }
    fn name(&self) -> &str {
        "mathml"
    }
    fn extension(&self) -> &str {
        "xml"
    }
    fn mime_type(&self) -> &str {
        "application/mathml+xml"
    }
}

pub struct MathmlMmlConverter;
impl Converter for MathmlMmlConverter {
    fn convert(&self, doc: &Document) -> Result<String> {
        convert_mathml(doc, MathmlMode::Mml)
    }
    fn name(&self) -> &str {
        "mathml_mml"
    }
    fn extension(&self) -> &str {
        "mml"
    }
    fn mime_type(&self) -> &str {
        "application/mathml+xml"
    }
}

pub struct MathmlMConverter;
impl Converter for MathmlMConverter {
    fn convert(&self, doc: &Document) -> Result<String> {
        convert_mathml(doc, MathmlMode::M)
    }
    fn name(&self) -> &str {
        "mathml_m"
    }
    fn extension(&self) -> &str {
        "xml"
    }
    fn mime_type(&self) -> &str {
        "application/mathml+xml"
    }
}

pub struct MathmlAttrConverter;
impl Converter for MathmlAttrConverter {
    fn convert(&self, doc: &Document) -> Result<String> {
        convert_mathml(doc, MathmlMode::Attr)
    }
    fn name(&self) -> &str {
        "mathml_attr"
    }
    fn extension(&self) -> &str {
        "xml"
    }
    fn mime_type(&self) -> &str {
        "application/mathml+xml"
    }
}

enum MathmlMode {
    Standard,
    Mml,
    M,
    Attr,
}

fn convert_mathml(doc: &Document, mode: MathmlMode) -> Result<String> {
    let mut parts = Vec::new();
    for page in &doc.pages {
        for block in &page.blocks {
            match block {
                Block::Formula(f) => parts.push(convert_formula_to_mathml(&f.formula, &mode)),
                Block::Paragraph(p) => {
                    for inline in &p.inlines {
                        match inline {
                            Inline::Text(t) => {
                                parts.push(format!("<mtext>{}</mtext>", xml_escape(&t.text)))
                            }
                            Inline::Formula(f) => parts.push(convert_formula_to_mathml(f, &mode)),
                            Inline::Image(_) => {}
                            Inline::Footnote { content } => {
                                let inner = convert_inline_to_mathml(content, &mode);
                                parts.push(inner);
                            }
                            Inline::Label { .. } => {}
                            Inline::Reference { key, .. } => {
                                parts.push(format!("<mtext>({})</mtext>", key));
                            }
                            Inline::Citation { key, .. } => {
                                parts.push(format!("<mtext>[{}]</mtext>", key));
                            }
                            _ => {}
                        }
                    }
                }
                _ => {}
            }
        }
    }
    let content = parts.join("\n");
    match &mode {
        MathmlMode::Standard => Ok(format!(
            "<math xmlns=\"http://www.w3.org/1998/Math/MathML\">\n{}\n</math>",
            content
        )),
        MathmlMode::Mml => Ok(format!(
            "<mml:math xmlns:mml=\"http://www.w3.org/1998/Math/MathML\" xmlns=\"http://www.w3.org/1998/Math/MathML\">\n{}\n</mml:math>",
            content
        )),
        MathmlMode::M => Ok(format!(
            "<m:math xmlns:m=\"http://www.w3.org/1998/Math/MathML\" xmlns=\"http://www.w3.org/1998/Math/MathML\">\n{}\n</m:math>",
            content
        )),
        MathmlMode::Attr => Ok(format!(
            "<math mathmode=\"inline\" xmlns=\"http://www.w3.org/1998/Math/MathML\">\n{}\n</math>",
            content
        )),
    }
}

fn convert_formula_to_mathml(f: &Formula, _mode: &MathmlMode) -> String {
    let content = match &f.source {
        FormulaSource::Latex(s) => latex_to_mathml_mode(s, f.display_mode),
        FormulaSource::MathML(s) => s.clone(),
        FormulaSource::Omml(s) => format!("<mrow><mi>{}</mi></mrow>", xml_escape(s)),
        FormulaSource::Typst(s) => latex_to_mathml_mode(&typst_to_latex(s), f.display_mode),
    };
    if f.display_mode {
        format!("<mstyle displaystyle=\"true\">\n{}\n</mstyle>", content)
    } else {
        format!("<mstyle displaystyle=\"false\">\n{}\n</mstyle>", content)
    }
}

fn convert_inline_to_mathml(inline: &Inline, mode: &MathmlMode) -> String {
    match inline {
        Inline::Text(t) => format!("<mtext>{}</mtext>", xml_escape(&t.text)),
        Inline::Formula(f) => convert_formula_to_mathml(f, mode),
        _ => String::new(),
    }
}

fn latex_to_mathml(latex: &str) -> String {
    latex_to_mathml_mode(latex, true)
}

fn latex_to_mathml_mode(latex: &str, display: bool) -> String {
    let latex = latex.trim();
    let raw_source = latex;
    let lexical_source = crate::latex_utils::without_comments(latex);
    let latex = lexical_source.trim();
    if let Some(rendered) = render_finite_symbol_expression(latex, display) {
        return rendered;
    }
    // Preserve raw column specifications when the finite AST route cannot render them.
    if raw_source.contains("\\begin") {
        if let Some(rendered) = render_matrix_node(&crate::latex_parser::parse_latex(raw_source)) {
            return rendered;
        }
    }
    let chars: Vec<char> = latex.chars().collect();
    if chars.first() == Some(&'{') {
        if let Some((inner, end)) = read_braced_group(&chars, 0) {
            if end == chars.len() {
                return format!("<mrow>{}</mrow>", latex_to_mathml(&inner));
            }
        }
    }

    if let Some(rendered) = render_styled_sequence(latex) {
        return rendered;
    }

    if latex.contains("\\left")
        || latex.contains("\\big")
        || latex.contains("\\Big")
        || (latex.contains('_') && latex.contains('^'))
    {
        if let Some(rendered) = render_left_right_mathml(latex) {
            return rendered;
        }
    }

    // \textcolor{color}{content} → <mstyle mathcolor="color"><mrow>content</mrow></mstyle>
    if let Some(content) = latex.strip_prefix("\\textcolor{") {
        if let Some(close) = content.find('}') {
            let color = &content[..close];
            let rest = &content[close + 1..];
            let inner = rest
                .strip_prefix('{')
                .unwrap_or(rest)
                .strip_suffix('}')
                .unwrap_or(rest);
            let hex = mathml_color_name(color.trim());
            return format!(
                "<mstyle mathcolor=\"{}\"><mrow>{}</mrow></mstyle>",
                hex,
                latex_to_mathml(inner)
            );
        }
    }
    if let Some(content) = latex.strip_prefix("\\color{") {
        if let Some(close) = content.find('}') {
            let color = &content[..close];
            let hex = mathml_color_name(color.trim());
            let rest = &content[close + 1..];
            if rest.is_empty() {
                return format!("<mstyle mathcolor=\"{}\"/>", hex);
            }
            return format!(
                "<mstyle mathcolor=\"{}\"><mrow>{}</mrow></mstyle>",
                hex,
                latex_to_mathml(rest)
            );
        }
    }

    // \boldsymbol{...} → <mstyle fontweight="bold">
    if let Some(content) = latex.strip_prefix("\\boldsymbol{") {
        let inner = content.strip_suffix('}').unwrap_or(content);
        return format!(
            "<mstyle fontweight=\"bold\"><mrow>{}</mrow></mstyle>",
            latex_to_mathml(inner)
        );
    }
    // \mathbf{...} → <mstyle fontweight="bold">
    if let Some(content) = latex.strip_prefix("\\mathbf{") {
        let inner = content.strip_suffix('}').unwrap_or(content);
        return format!(
            "<mstyle fontweight=\"bold\"><mrow>{}</mrow></mstyle>",
            latex_to_mathml(inner)
        );
    }
    // \mathrm{...} → <mstyle fontfamily="serif">
    if let Some(content) = latex.strip_prefix("\\mathrm{") {
        let inner = content.strip_suffix('}').unwrap_or(content);
        return format!(
            "<mstyle fontfamily=\"serif\"><mrow>{}</mrow></mstyle>",
            latex_to_mathml(inner)
        );
    }
    if let Some(content) = latex.strip_prefix("\\text{") {
        let inner = content.strip_suffix('}').unwrap_or(content);
        return format!(
            "<mtext>{}</mtext>",
            xml_escape(&crate::latex_utils::decode_text_symbols(inner))
        );
    }
    // \mathbb{...} → <mi mathvariant="double-struck">
    if let Some(content) = latex.strip_prefix("\\mathbb{") {
        let inner = content.strip_suffix('}').unwrap_or(content);
        return format!(
            "<mi mathvariant=\"double-struck\">{}</mi>",
            latex_to_mathml(inner)
        );
    }
    for (command, variant) in [
        ("\\mathcal{", "script"),
        ("\\mathfrak{", "fraktur"),
        ("\\mathsf{", "sans-serif"),
        ("\\mathtt{", "monospace"),
    ] {
        if let Some(content) = latex.strip_prefix(command) {
            let inner = content.strip_suffix('}').unwrap_or(content);
            return format!(
                "<mstyle mathvariant=\"{}\"><mrow>{}</mrow></mstyle>",
                variant,
                latex_to_mathml(inner)
            );
        }
    }

    if let Some(inner) = latex.strip_prefix("\\frac") {
        if let Some((num, den)) = split_brace_pair(inner) {
            return format!(
                "<mfrac>\n  <mrow>{}</mrow>\n  <mrow>{}</mrow>\n</mfrac>",
                latex_to_mathml(num),
                latex_to_mathml(den)
            );
        }
    }

    if let Some(inner) = latex.strip_prefix("\\sqrt{") {
        let content = inner.strip_suffix('}').unwrap_or(inner);
        return format!("<msqrt><mrow>{}</mrow></msqrt>", latex_to_mathml(content));
    }

    if let Some(inner) = latex.strip_prefix("\\sqrt[") {
        if let Some((degree, rest)) = inner.split_once(']') {
            let content = rest
                .strip_prefix('{')
                .unwrap_or(rest)
                .strip_suffix('}')
                .unwrap_or(rest);
            return format!(
                "<mroot><mrow>{}</mrow><mrow>{}</mrow></mroot>",
                latex_to_mathml(content),
                latex_to_mathml(degree)
            );
        }
    }

    if let Some(rendered) = render_accent_mathml(latex) {
        return rendered;
    }

    // Keep legacy array handling separate; column specifications remain best-effort.
    if let Some(inner) = extract_env(latex, "array") {
        return matrix_to_mathml(inner, None);
    }

    // \phantom
    if let Some(inner) = latex.strip_prefix("\\phantom{") {
        let content = inner.strip_suffix('}').unwrap_or(inner);
        return format!(
            "<mpadded width=\"0\" height=\"0\" depth=\"0\"><mrow>{}</mrow></mpadded>",
            latex_to_mathml(content)
        );
    }
    if let Some(rendered) = render_nary_limits(latex) {
        return rendered;
    }

    if let Some(rendered) = render_operator_limits(latex) {
        return rendered;
    }

    if let Some(parts) = split_math_sequence(latex) {
        let rendered = parts
            .iter()
            .map(|part| {
                if is_math_operator(part) {
                    map_symbol_mathml(part)
                        .map(str::to_string)
                        .unwrap_or_else(|| format!("<mo>{}</mo>", xml_escape(part)))
                } else {
                    latex_to_mathml(part)
                }
            })
            .collect::<Vec<_>>()
            .join("");
        return format!("<mrow>{}</mrow>", rendered);
    }

    if let Some((base, sup)) = split_superscript(latex) {
        return format!(
            "<msup>\n  <mrow>{}</mrow>\n  <mrow>{}</mrow>\n</msup>",
            latex_to_mathml(base),
            latex_to_mathml(sup)
        );
    }

    if let Some((base, sub)) = split_subscript(latex) {
        return format!(
            "<msub>\n  <mrow>{}</mrow>\n  <mrow>{}</mrow>\n</msub>",
            latex_to_mathml(base),
            latex_to_mathml(sub)
        );
    }

    if let Some(sym) = map_symbol_mathml(latex) {
        return sym.to_string();
    }

    if latex.len() == 1 && latex.chars().next().unwrap().is_alphabetic() {
        format!("<mi>{}</mi>", latex)
    } else if latex.parse::<f64>().is_ok() {
        format!("<mn>{}</mn>", latex)
    } else {
        format!("<mi>{}</mi>", xml_escape(latex))
    }
}

fn render_operator_limits(latex: &str) -> Option<String> {
    let (command, mut pos) = [
        "\\limsup", "\\liminf", "\\lim", "\\max", "\\min", "\\sup", "\\inf", "\\log",
    ]
    .iter()
    .find_map(|command| {
        latex
            .strip_prefix(command)
            .map(|_| (*command, command.len()))
    })?;

    let name = command.trim_start_matches('\\');
    let mut lower = None;
    let mut upper = None;

    loop {
        pos = skip_ascii_whitespace(latex, pos);
        let marker = latex[pos..].chars().next();
        match marker {
            Some('_') => {
                let (value, next_pos) = read_script_argument(latex, pos + 1)?;
                lower = Some(value);
                pos = next_pos;
            }
            Some('^') => {
                let (value, next_pos) = read_script_argument(latex, pos + 1)?;
                upper = Some(value);
                pos = next_pos;
            }
            _ => break,
        }
    }

    if lower.is_none() && upper.is_none() {
        return None;
    }

    let core = match (lower, upper) {
        (Some(lower), Some(upper)) => format!(
            "<munderover><mi>{}</mi><mrow>{}</mrow><mrow>{}</mrow></munderover>",
            name,
            latex_to_mathml(&lower),
            latex_to_mathml(&upper)
        ),
        (Some(lower), None) => format!(
            "<munder><mi>{}</mi><mrow>{}</mrow></munder>",
            name,
            latex_to_mathml(&lower)
        ),
        (None, Some(upper)) => format!(
            "<mover><mi>{}</mi><mrow>{}</mrow></mover>",
            name,
            latex_to_mathml(&upper)
        ),
        (None, None) => unreachable!(),
    };

    let body = latex[pos..].trim();
    if body.is_empty() {
        Some(core)
    } else {
        Some(format!(
            "<mrow>{}<mrow>{}</mrow></mrow>",
            core,
            latex_to_mathml(body)
        ))
    }
}

fn render_nary_limits(latex: &str) -> Option<String> {
    let (command, mut pos) = [
        "\\sum", "\\prod", "\\coprod", "\\int", "\\iint", "\\iiint", "\\oint",
    ]
    .iter()
    .find_map(|command| {
        latex
            .strip_prefix(command)
            .map(|_| (*command, command.len()))
    })?;

    let op = map_symbol_mathml(command)?;
    let mut lower = None;
    let mut upper = None;

    loop {
        pos = skip_ascii_whitespace(latex, pos);
        let marker = latex[pos..].chars().next();
        match marker {
            Some('_') => {
                let (value, next_pos) = read_script_argument(latex, pos + 1)?;
                lower = Some(value);
                pos = next_pos;
            }
            Some('^') => {
                let (value, next_pos) = read_script_argument(latex, pos + 1)?;
                upper = Some(value);
                pos = next_pos;
            }
            _ => break,
        }
    }

    if lower.is_none() && upper.is_none() {
        return None;
    }

    let core = match (lower, upper) {
        (Some(lower), Some(upper)) => format!(
            "<munderover>{}<mrow>{}</mrow><mrow>{}</mrow></munderover>",
            op,
            latex_to_mathml(&lower),
            latex_to_mathml(&upper)
        ),
        (Some(lower), None) => format!(
            "<munder>{}<mrow>{}</mrow></munder>",
            op,
            latex_to_mathml(&lower)
        ),
        (None, Some(upper)) => format!(
            "<mover>{}<mrow>{}</mrow></mover>",
            op,
            latex_to_mathml(&upper)
        ),
        (None, None) => unreachable!(),
    };

    let body = latex[pos..].trim();
    if body.is_empty() {
        Some(core)
    } else {
        Some(format!(
            "<mrow>{}<mrow>{}</mrow></mrow>",
            core,
            latex_to_mathml(body)
        ))
    }
}

fn skip_ascii_whitespace(text: &str, mut pos: usize) -> usize {
    while pos < text.len() && text.as_bytes()[pos].is_ascii_whitespace() {
        pos += 1;
    }
    pos
}

fn read_script_argument(text: &str, pos: usize) -> Option<(String, usize)> {
    let pos = skip_ascii_whitespace(text, pos);
    let rest = &text[pos..];
    if rest.starts_with('{') {
        let chars: Vec<char> = text.chars().collect();
        let char_start = text[..pos].chars().count();
        let mut depth = 0i32;
        for char_pos in char_start..chars.len() {
            match chars[char_pos] {
                '{' => depth += 1,
                '}' => {
                    depth -= 1;
                    if depth == 0 {
                        let byte_end: usize =
                            chars[..char_pos].iter().map(|ch| ch.len_utf8()).sum();
                        let byte_after: usize =
                            chars[..=char_pos].iter().map(|ch| ch.len_utf8()).sum();
                        return Some((text[pos + 1..byte_end].to_string(), byte_after));
                    }
                }
                _ => {}
            }
        }
        return None;
    }

    if rest.starts_with('\\') {
        let mut end = pos + 1;
        while end < text.len() && text.as_bytes()[end].is_ascii_alphabetic() {
            end += 1;
        }
        if end == pos + 1 && end < text.len() {
            end += text[end..].chars().next()?.len_utf8();
        }
        return Some((text[pos..end].to_string(), end));
    }

    let end = pos + rest.chars().next()?.len_utf8();
    Some((text[pos..end].to_string(), end))
}

fn is_math_operator(text: &str) -> bool {
    matches!(
        text,
        "+" | "-"
            | "="
            | "<"
            | ">"
            | "/"
            | "*"
            | "|"
            | "("
            | ")"
            | "["
            | "]"
            | ","
            | "\\,"
            | "\\:"
            | "\\;"
            | "\\!"
            | "\\quad"
            | "\\qquad"
    ) || is_sequence_command_operator(text)
}

fn is_sequence_command_operator(text: &str) -> bool {
    matches!(
        text,
        "\\implies"
            | "\\Rightarrow"
            | "\\Leftarrow"
            | "\\Leftrightarrow"
            | "\\rightarrow"
            | "\\leftarrow"
            | "\\leftrightarrow"
            | "\\to"
            | "\\mapsto"
            | "\\leq"
            | "\\le"
            | "\\geq"
            | "\\ge"
            | "\\neq"
            | "\\ne"
            | "\\approx"
            | "\\equiv"
            | "\\sim"
    )
}

fn render_accent_mathml(latex: &str) -> Option<String> {
    let (command, accent) = [
        ("\\hat", "^"),
        ("\\widehat", "^"),
        ("\\bar", "\u{00AF}"),
        ("\\overline", "\u{00AF}"),
        ("\\vec", "\u{2192}"),
        ("\\overrightarrow", "\u{2192}"),
        ("\\overleftarrow", "\u{2190}"),
        ("\\dot", "."),
        ("\\ddot", ".."),
        ("\\tilde", "~"),
        ("\\widetilde", "~"),
        ("\\check", "\u{02C7}"),
    ]
    .iter()
    .find_map(|(command, accent)| latex.strip_prefix(command).map(|_| (*command, *accent)))?;
    let (inner, after_inner) = read_script_argument(latex, command.len())?;
    if skip_ascii_whitespace(latex, after_inner) != latex.len() {
        return None;
    }
    Some(format!(
        "<mover><mrow>{}</mrow><mo>{}</mo></mover>",
        latex_to_mathml(&inner),
        xml_escape(accent)
    ))
}

fn render_left_right_mathml(latex: &str) -> Option<String> {
    render_delimited_node(&crate::latex_parser::parse_latex(latex))
}

fn render_fixed_delimiter_node(node: &crate::latex_ast::LatexNode) -> Option<String> {
    let crate::latex_ast::LatexNode::Command { name, args } = node else {
        return None;
    };
    latexsnipper_ast::formula_layout::latex_fixed_delimiter_size(name)?;
    let Some((size, class, glyph)) = crate::latex_utils::fixed_delimiter_parts(name, args) else {
        return Some(format!("<mtext>{}</mtext>", xml_escape(&node.to_string())));
    };
    let (form, fence, space) = match class {
        "opening" => ("prefix", "true", "0em"),
        "closing" => ("postfix", "true", "0em"),
        "relation" => ("infix", "false", "0.277778em"),
        _ => ("infix", "true", "0em"),
    };
    Some(format!("<mo stretchy=\"true\" symmetric=\"true\" minsize=\"{size}\" maxsize=\"{size}\" form=\"{form}\" fence=\"{fence}\" lspace=\"{space}\" rspace=\"{space}\">{}</mo>", xml_escape(glyph)))
}

fn scalable_operator_mathml(glyph: &str, form: &str) -> String {
    let separator = if form == "infix" { "true" } else { "false" };
    format!("<mo fence=\"true\" stretchy=\"true\" symmetric=\"true\" form=\"{form}\" separator=\"{separator}\" lspace=\"0em\" rspace=\"0em\">{}</mo>", xml_escape(glyph))
}

fn scalable_fence_mathml(
    left: &str,
    sections: &[String],
    separators: &[&str],
    right: &str,
) -> String {
    let mut body = scalable_operator_mathml(left, "prefix");
    for (index, section) in sections.iter().enumerate() {
        if index > 0 {
            body.push_str(&scalable_operator_mathml(separators[index - 1], "infix"));
        }
        body.push_str(section);
    }
    body.push_str(&scalable_operator_mathml(right, "postfix"));
    format!("<mrow>{body}</mrow>")
}

fn render_delimited_node(node: &crate::latex_ast::LatexNode) -> Option<String> {
    use crate::latex_ast::LatexNode;
    let child = |node: &LatexNode| {
        render_delimited_node(node).unwrap_or_else(|| latex_to_mathml(&node.to_string()))
    };
    Some(match node {
        LatexNode::Command { name, .. }
            if latexsnipper_ast::formula_layout::latex_fixed_delimiter_size(name).is_some() =>
        {
            render_fixed_delimiter_node(node)?
        }
        LatexNode::Delimited {
            left,
            content,
            right,
        } => {
            let (Some(left), Some(right)) = (
                latexsnipper_syntax::latex::scalable_delimiter_glyph(left),
                latexsnipper_syntax::latex::scalable_delimiter_glyph(right),
            ) else {
                return Some(format!("<mtext>{}</mtext>", xml_escape(&node.to_string())));
            };
            let Ok(parts) = crate::latex_utils::delimiter_parts(content) else {
                return Some(format!("<mtext>{}</mtext>", xml_escape(&node.to_string())));
            };
            let inner: Vec<String> = parts
                .sections
                .into_iter()
                .map(|section| {
                    format!(
                        "<mrow>{}</mrow>",
                        section.iter().map(child).collect::<String>()
                    )
                })
                .collect();
            scalable_fence_mathml(left, &inner, &parts.separators, right)
        }
        LatexNode::Command { name, args } if name == "invalid-scalable-delimiter" => {
            format!(
                "<mtext>{}</mtext>",
                xml_escape(&args.first().map(ToString::to_string).unwrap_or_default())
            )
        }
        LatexNode::Sequence(nodes) | LatexNode::Group(nodes) => {
            if !nodes.iter().any(has_delimited_node) {
                return None;
            }
            format!(
                "<mrow>{}</mrow>",
                nodes.iter().map(child).collect::<String>()
            )
        }
        LatexNode::Superscript { base, exp } => {
            if let LatexNode::Subscript { base, sub } = base.as_ref() {
                if matches!(
                    base.as_ref(),
                    LatexNode::Operator(_) | LatexNode::OperatorName { .. }
                ) {
                    return None;
                }
                return Some(format!(
                    "<msubsup><mrow>{}</mrow><mrow>{}</mrow><mrow>{}</mrow></msubsup>",
                    child(base),
                    child(sub),
                    child(exp)
                ));
            }
            if !has_delimited_node(base) && !has_delimited_node(exp) {
                return None;
            }
            format!(
                "<msup><mrow>{}</mrow><mrow>{}</mrow></msup>",
                child(base),
                child(exp)
            )
        }
        LatexNode::Subscript { base, sub } => {
            if let LatexNode::Superscript { base, exp } = base.as_ref() {
                if matches!(
                    base.as_ref(),
                    LatexNode::Operator(_) | LatexNode::OperatorName { .. }
                ) {
                    return None;
                }
                return Some(format!(
                    "<msubsup><mrow>{}</mrow><mrow>{}</mrow><mrow>{}</mrow></msubsup>",
                    child(base),
                    child(sub),
                    child(exp)
                ));
            }
            if !has_delimited_node(base) && !has_delimited_node(sub) {
                return None;
            }
            format!(
                "<msub><mrow>{}</mrow><mrow>{}</mrow></msub>",
                child(base),
                child(sub)
            )
        }
        LatexNode::Fraction { num, den } => {
            if !has_delimited_node(num) && !has_delimited_node(den) {
                return None;
            }
            format!(
                "<mfrac><mrow>{}</mrow><mrow>{}</mrow></mfrac>",
                child(num),
                child(den)
            )
        }
        _ => return None,
    })
}

fn has_delimited_node(node: &crate::latex_ast::LatexNode) -> bool {
    use crate::latex_ast::LatexNode;
    match node {
        LatexNode::Delimited { .. } => true,
        LatexNode::Command { name, .. } => {
            name == "invalid-scalable-delimiter"
                || latexsnipper_ast::formula_layout::latex_fixed_delimiter_size(name).is_some()
        }
        LatexNode::Sequence(nodes) | LatexNode::Group(nodes) => {
            nodes.iter().any(has_delimited_node)
        }
        LatexNode::Superscript { base, exp } => {
            matches!(base.as_ref(), LatexNode::Subscript { .. })
                || has_delimited_node(base)
                || has_delimited_node(exp)
        }
        LatexNode::Subscript { base, sub } => {
            matches!(base.as_ref(), LatexNode::Superscript { .. })
                || has_delimited_node(base)
                || has_delimited_node(sub)
        }
        LatexNode::Fraction { num, den } => has_delimited_node(num) || has_delimited_node(den),
        _ => false,
    }
}

fn split_math_sequence(latex: &str) -> Option<Vec<String>> {
    let mut parts = Vec::new();
    let mut current = String::new();
    let mut brace_depth = 0i32;
    let mut bracket_depth = 0i32;
    let chars: Vec<char> = latex.chars().collect();
    let mut pos = 0usize;

    while pos < chars.len() {
        let ch = chars[pos];
        if ch == '\\' {
            let command_start = pos;
            current.push(ch);
            pos += 1;
            let name_start = pos;
            while pos < chars.len() && chars[pos].is_ascii_alphabetic() {
                current.push(chars[pos]);
                pos += 1;
            }
            if pos == name_start && pos < chars.len() {
                current.push(chars[pos]);
                pos += 1;
            }
            let command: String = chars[command_start..pos].iter().collect();
            if brace_depth == 0
                && bracket_depth == 0
                && (is_sequence_command_operator(&command)
                    || matches!(
                        command.as_str(),
                        "\\," | "\\:" | "\\;" | "\\!" | "\\quad" | "\\qquad"
                    ))
            {
                let before_command_len = current.len() - command.len();
                let before = current[..before_command_len].trim();
                if !before.is_empty() {
                    parts.push(before.to_string());
                }
                parts.push(command);
                current.clear();
            }
            continue;
        }

        match ch {
            '{' => {
                brace_depth += 1;
                current.push(ch);
            }
            '}' => {
                brace_depth -= 1;
                current.push(ch);
            }
            '[' => {
                bracket_depth += 1;
                current.push(ch);
            }
            ']' => {
                bracket_depth -= 1;
                current.push(ch);
            }
            '+' | '-' | '=' | '<' | '>' | '/' | '*' | '|' | '(' | ')' | ','
                if brace_depth == 0 && bracket_depth == 0 =>
            {
                let trimmed = current.trim();
                if !trimmed.is_empty() {
                    parts.push(trimmed.to_string());
                }
                parts.push(ch.to_string());
                current.clear();
            }
            _ => current.push(ch),
        }
        pos += 1;
    }

    let trimmed = current.trim();
    if !trimmed.is_empty() {
        parts.push(trimmed.to_string());
    }

    if parts.iter().any(|part| is_math_operator(part)) {
        Some(parts)
    } else {
        None
    }
}

fn render_styled_sequence(latex: &str) -> Option<String> {
    let mut output = String::new();
    let mut plain = String::new();
    let chars: Vec<char> = latex.chars().collect();
    let mut pos = 0usize;
    let mut found_style = false;

    while pos < chars.len() {
        // Operand groups are rendered recursively by their owning command.
        // A declaration inside a group must not consume the outer expression.
        if chars[pos] == '{' {
            if let Some((_, end)) = read_braced_group(&chars, pos) {
                plain.extend(chars[pos..end].iter());
                pos = end;
                continue;
            }
        }
        if chars[pos] != '\\' {
            plain.push(chars[pos]);
            pos += 1;
            continue;
        }

        let cmd_start = pos + 1;
        let mut cmd_end = cmd_start;
        while cmd_end < chars.len() && chars[cmd_end].is_ascii_alphabetic() {
            cmd_end += 1;
        }
        let command: String = chars[cmd_start..cmd_end].iter().collect();

        match command.as_str() {
            "substack" => {
                let Some((inner, end)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                let rows = split_stack_rows(&inner)
                    .into_iter()
                    .map(|row| format!("<mtr><mtd>{}</mtd></mtr>", latex_to_mathml(row)))
                    .collect::<String>();
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&math_style_mathml(
                    "scriptstyle",
                    &format!("<mtable columnalign=\"center\">{rows}</mtable>"),
                ));
                pos = end;
                found_style = true;
            }
            "dfrac" | "tfrac" | "cfrac" => {
                let mut operand_start = cmd_end;
                let mut alignment = "";
                if command == "cfrac" {
                    while chars
                        .get(operand_start)
                        .is_some_and(|ch| ch.is_whitespace())
                    {
                        operand_start += 1;
                    }
                    if chars.get(operand_start) == Some(&'[') {
                        let Some(end) = chars[operand_start + 1..].iter().position(|ch| *ch == ']')
                        else {
                            plain.push(chars[pos]);
                            pos += 1;
                            continue;
                        };
                        let option: String = chars[operand_start + 1..operand_start + 1 + end]
                            .iter()
                            .collect();
                        alignment = match option.trim() {
                            "l" => " numalign=\"left\"",
                            "r" => " numalign=\"right\"",
                            _ => "",
                        };
                        operand_start += end + 2;
                    }
                }
                let Some((num, after_num)) = read_braced_group(&chars, operand_start) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                let Some((den, after_den)) = read_braced_group(&chars, after_num) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                flush_mathml_plain(&mut output, &mut plain);
                let fraction = format!(
                    "<mfrac{alignment}><mrow>{}</mrow><mrow>{}</mrow></mfrac>",
                    latex_to_mathml(&num),
                    latex_to_mathml(&den)
                );
                let style = if command == "dfrac" || command == "cfrac" {
                    "displaystyle"
                } else {
                    "textstyle"
                };
                output.push_str(&math_style_mathml(style, &fraction));
                pos = after_den;
                found_style = true;
            }
            "textcolor" => {
                let Some((color, after_color)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                let Some((inner, after_inner)) = read_braced_group(&chars, after_color) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&format!(
                    "<mstyle mathcolor=\"{}\"><mrow>{}</mrow></mstyle>",
                    mathml_color_name(color.trim()),
                    latex_to_mathml(&inner)
                ));
                pos = after_inner;
                found_style = true;
            }
            "mathbf" | "boldsymbol" => {
                let Some((inner, after_inner)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&format!(
                    "<mstyle fontweight=\"bold\"><mrow>{}</mrow></mstyle>",
                    latex_to_mathml(&inner)
                ));
                pos = after_inner;
                found_style = true;
            }
            "mathit" => {
                let Some((inner, after_inner)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&format!(
                    "<mstyle fontstyle=\"italic\"><mrow>{}</mrow></mstyle>",
                    latex_to_mathml(&inner)
                ));
                pos = after_inner;
                found_style = true;
            }
            "mathrm" => {
                let Some((inner, after_inner)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&format!(
                    "<mstyle fontfamily=\"serif\"><mrow>{}</mrow></mstyle>",
                    latex_to_mathml(&inner)
                ));
                pos = after_inner;
                found_style = true;
            }
            "mathbb" => {
                let Some((inner, after_inner)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&format!(
                    "<mstyle mathvariant=\"double-struck\"><mrow>{}</mrow></mstyle>",
                    latex_to_mathml(&inner)
                ));
                pos = after_inner;
                found_style = true;
            }
            "mathcal" | "mathfrak" | "mathsf" | "mathtt" => {
                let Some((inner, after_inner)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                let variant = match command.as_str() {
                    "mathcal" => "script",
                    "mathfrak" => "fraktur",
                    "mathsf" => "sans-serif",
                    "mathtt" => "monospace",
                    _ => "normal",
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&format!(
                    "<mstyle mathvariant=\"{}\"><mrow>{}</mrow></mstyle>",
                    variant,
                    latex_to_mathml(&inner)
                ));
                pos = after_inner;
                found_style = true;
            }
            "text" | "textrm" | "textsf" | "texttt" => {
                let Some((inner, after_inner)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&format!(
                    "<mtext>{}</mtext>",
                    xml_escape(&crate::latex_utils::decode_text_symbols(&inner))
                ));
                pos = after_inner;
                found_style = true;
            }
            "displaystyle" | "textstyle" | "scriptstyle" | "scriptscriptstyle" => {
                let (inner, after_inner) = read_braced_group(&chars, cmd_end)
                    .unwrap_or_else(|| (chars[cmd_end..].iter().collect(), chars.len()));
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&math_style_mathml(
                    command.as_str(),
                    &latex_to_mathml_mode(&inner, command == "displaystyle"),
                ));
                pos = after_inner;
                found_style = true;
            }
            "phantom" | "vphantom" | "hphantom" | "boxed" | "tag" | "abs" | "norm" | "floor"
            | "ceil" => {
                let Some((inner, after_inner)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                let inner = latex_to_mathml(&inner);
                let rendered = match command.as_str() {
                    "phantom" => format!(
                        "<mpadded width=\"0\" height=\"0\" depth=\"0\"><mrow>{inner}</mrow></mpadded>"
                    ),
                    "vphantom" => {
                        format!("<mpadded width=\"0\"><mrow>{inner}</mrow></mpadded>")
                    }
                    "hphantom" => format!(
                        "<mpadded height=\"0\" depth=\"0\"><mrow>{inner}</mrow></mpadded>"
                    ),
                    "boxed" => {
                        format!("<menclosed notation=\"box\"><mrow>{inner}</mrow></menclosed>")
                    }
                    "tag" => format!(
                        "<mo lspace=\"0em\" rspace=\"0em\">(</mo><mrow>{inner}</mrow><mo lspace=\"0em\" rspace=\"0em\">)</mo>"
                    ),
                    "abs" => delimiter_mathml("|", "|", &inner),
                    "norm" => delimiter_mathml("‖", "‖", &inner),
                    "floor" => delimiter_mathml("⌊", "⌋", &inner),
                    "ceil" => delimiter_mathml("⌈", "⌉", &inner),
                    _ => unreachable!("command match is exhaustive"),
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&rendered);
                pos = after_inner;
                found_style = true;
            }
            "tiny" | "scriptsize" | "footnotesize" | "small" | "normalsize" | "large" | "Large"
            | "LARGE" | "huge" | "Huge" => {
                let Some((inner, after_inner)) = read_braced_group(&chars, cmd_end) else {
                    plain.push(chars[pos]);
                    pos += 1;
                    continue;
                };
                flush_mathml_plain(&mut output, &mut plain);
                output.push_str(&format!(
                    "<mstyle mathsize=\"{}\"><mrow>{}</mrow></mstyle>",
                    latex_size_to_mathml(command.as_str()),
                    latex_to_mathml(&inner)
                ));
                pos = after_inner;
                found_style = true;
            }
            _ => {
                plain.push(chars[pos]);
                pos += 1;
            }
        }
    }

    if !found_style {
        return None;
    }
    flush_mathml_plain(&mut output, &mut plain);
    Some(output)
}

fn read_braced_group(chars: &[char], mut pos: usize) -> Option<(String, usize)> {
    while pos < chars.len() && chars[pos].is_whitespace() {
        pos += 1;
    }
    if pos >= chars.len() || chars[pos] != '{' {
        return None;
    }

    let mut depth = 1i32;
    let start = pos + 1;
    pos += 1;
    while pos < chars.len() {
        match chars[pos] {
            '{' => depth += 1,
            '}' => {
                depth -= 1;
                if depth == 0 {
                    let value = chars[start..pos].iter().collect();
                    return Some((value, pos + 1));
                }
            }
            _ => {}
        }
        pos += 1;
    }
    None
}

fn flush_mathml_plain(output: &mut String, plain: &mut String) {
    let text = plain.trim();
    if !text.is_empty() {
        output.push_str(&latex_to_mathml(text));
    }
    plain.clear();
}

fn delimiter_mathml(open: &str, close: &str, inner: &str) -> String {
    scalable_fence_mathml(open, &[format!("<mrow>{inner}</mrow>")], &[], close)
}

fn math_style_mathml(style: &str, inner: &str) -> String {
    let (displaystyle, scriptlevel) = match style {
        "displaystyle" => ("true", "0"),
        "textstyle" => ("false", "0"),
        "scriptstyle" => ("false", "1"),
        "scriptscriptstyle" => ("false", "2"),
        _ => unreachable!("caller only passes supported math styles"),
    };
    format!(
        "<mstyle displaystyle=\"{displaystyle}\" scriptlevel=\"{scriptlevel}\"><mrow>{inner}</mrow></mstyle>"
    )
}

fn latex_size_to_mathml(name: &str) -> &str {
    match name {
        "tiny" => "50%",
        "scriptsize" => "70%",
        "footnotesize" => "80%",
        "small" => "90%",
        "normalsize" => "100%",
        "large" => "120%",
        "Large" => "144%",
        "LARGE" => "173%",
        "huge" => "207%",
        "Huge" => "249%",
        _ => "100%",
    }
}

fn mathml_color_name(name: &str) -> String {
    match name.to_lowercase().as_str() {
        "red" => "red".to_string(),
        "green" => "green".to_string(),
        "blue" => "blue".to_string(),
        "yellow" => "yellow".to_string(),
        "cyan" => "cyan".to_string(),
        "magenta" | "fuchsia" => "magenta".to_string(),
        "black" => "black".to_string(),
        "white" => "white".to_string(),
        "gray" | "grey" => "gray".to_string(),
        "orange" => "orange".to_string(),
        "purple" => "purple".to_string(),
        s if s.starts_with('#') && s.len() == 7 => s.to_string(),
        s if s.len() == 6 && s.chars().all(|c| c.is_ascii_hexdigit()) => format!("#{}", s),
        _ => "black".to_string(),
    }
}

fn map_symbol_mathml(latex: &str) -> Option<&str> {
    match latex {
        "\\min" => Some("<mi mathvariant=\"normal\">min</mi>"),
        "\\max" => Some("<mi mathvariant=\"normal\">max</mi>"),
        "\\%" => Some("<mo>%</mo>"),
        "\\&" => Some("<mo>&amp;</mo>"),
        "\\#" => Some("<mo>#</mo>"),
        "\\_" => Some("<mo>_</mo>"),
        "\\$" => Some("<mo>$</mo>"),
        "\\{" => Some("<mo>{</mo>"),
        "\\}" => Some("<mo>}</mo>"),
        "\\backslash" => Some("<mo>\\</mo>"),
        "\\textasciicircum" => Some("<mo>^</mo>"),
        "\\textasciitilde" => Some("<mo>~</mo>"),
        "\\alpha" | "alpha" => Some("<mi>\u{03B1}</mi>"),
        "\\beta" | "beta" => Some("<mi>\u{03B2}</mi>"),
        "\\gamma" | "gamma" => Some("<mi>\u{03B3}</mi>"),
        "\\Gamma" => Some("<mi>\u{0393}</mi>"),
        "\\delta" | "delta" => Some("<mi>\u{03B4}</mi>"),
        "\\Delta" => Some("<mi>\u{0394}</mi>"),
        "\\theta" | "theta" => Some("<mi>\u{03B8}</mi>"),
        "\\Theta" => Some("<mi>\u{0398}</mi>"),
        "\\lambda" | "lambda" => Some("<mi>\u{03BB}</mi>"),
        "\\Lambda" => Some("<mi>\u{039B}</mi>"),
        "\\mu" => Some("<mi>\u{03BC}</mi>"),
        "\\rho" => Some("<mi>\u{03C1}</mi>"),
        "\\varphi" => Some("<mi>\u{03C6}</mi>"),
        "\\Omega" => Some("<mi>\u{03A9}</mi>"),
        "\\sigma" | "sigma" => Some("<mi>\u{03C3}</mi>"),
        "\\omega" | "omega" => Some("<mi>\u{03C9}</mi>"),
        "\\pi" | "pi" => Some("<mi>\u{03C0}</mi>"),
        "\\infty" | "infinity" => Some("<mi>\u{221E}</mi>"),
        "\\pm" | "plus.minus" => Some("<mo>\u{00B1}</mo>"),
        "\\times" | "times" => Some("<mo>\u{00D7}</mo>"),
        "\\div" | "div" => Some("<mo>\u{00F7}</mo>"),
        "\\cdot" | "dot" => Some("<mo>\u{22C5}</mo>"),
        "\\leq" | "lt.eq" => Some("<mo>\u{2264}</mo>"),
        "\\geq" | "gt.eq" => Some("<mo>\u{2265}</mo>"),
        "\\neq" | "neq" => Some("<mo>\u{2260}</mo>"),
        "\\approx" | "approx" => Some("<mo>\u{2248}</mo>"),
        "\\rightarrow" | "\\to" | "rightarrow" => Some("<mo>\u{2192}</mo>"),
        "\\leftarrow" | "leftarrow" => Some("<mo>\u{2190}</mo>"),
        "\\leftrightarrow" | "leftrightarrow" => Some("<mo>\u{2194}</mo>"),
        "\\mapsto" | "mapsto" => Some("<mo>\u{21A6}</mo>"),
        "\\Rightarrow" => Some("<mo>\u{21D2}</mo>"),
        "\\Leftarrow" => Some("<mo>\u{21D0}</mo>"),
        "\\Leftrightarrow" => Some("<mo>\u{21D4}</mo>"),
        "\\implies" | "implies" => Some("<mo>\u{21D2}</mo>"),
        "\\sum" => Some("<mo>\u{2211}</mo>"),
        "\\prod" => Some("<mo>\u{220F}</mo>"),
        "\\coprod" => Some("<mo>\u{2210}</mo>"),
        "\\int" => Some("<mo>\u{222B}</mo>"),
        "\\iint" => Some("<mo>\u{222C}</mo>"),
        "\\iiint" => Some("<mo>\u{222D}</mo>"),
        "\\oint" => Some("<mo>\u{222E}</mo>"),
        "\\partial" => Some("<mo>\u{2202}</mo>"),
        "\\nabla" => Some("<mo>\u{2207}</mo>"),
        "\\forall" => Some("<mo>\u{2200}</mo>"),
        "\\exists" => Some("<mo>\u{2203}</mo>"),
        "\\neg" | "\\lnot" => Some("<mo>\u{00AC}</mo>"),
        "\\in" => Some("<mo>\u{2208}</mo>"),
        "\\notin" | "\\not\\in" => Some("<mo>\u{2209}</mo>"),
        "\\subset" => Some("<mo>\u{2282}</mo>"),
        "\\supset" => Some("<mo>\u{2283}</mo>"),
        "\\subseteq" => Some("<mo>\u{2286}</mo>"),
        "\\supseteq" => Some("<mo>\u{2287}</mo>"),
        "\\cup" => Some("<mo>\u{222A}</mo>"),
        "\\cap" => Some("<mo>\u{2229}</mo>"),
        "\\emptyset" => Some("<mo>\u{2205}</mo>"),
        "\\wedge" => Some("<mo>\u{2227}</mo>"),
        "\\vee" => Some("<mo>\u{2228}</mo>"),
        "\\oplus" => Some("<mo>\u{2295}</mo>"),
        "\\otimes" => Some("<mo>\u{2297}</mo>"),
        "\\perp" => Some("<mo>\u{22A5}</mo>"),
        "\\ldots" | "\\dots" => Some("<mo>\u{2026}</mo>"),
        "\\cdots" => Some("<mo>\u{22EF}</mo>"),
        // Math spacing
        "\\quad" | "quad" => Some("<mspace width=\"1em\"/>"),
        "\\qquad" | "qquad" => Some("<mspace width=\"2em\"/>"),
        "\\," => Some("<mspace width=\"thinmathspace\"/>"),
        "\\:" => Some("<mspace width=\"mediummathspace\"/>"),
        "\\;" => Some("<mspace width=\"thickmathspace\"/>"),
        "\\!" => Some("<mspace width=\"negativethinmathspace\"/>"),
        _ => None,
    }
}

// Finite AST handling for mixed glyph commands avoids treating an entire
// expression as one identifier. Unsupported nodes retain the legacy path.
fn render_finite_symbol_expression(latex: &str, display: bool) -> Option<String> {
    // Style declarations bind the remaining source, unlike parse_single.
    // Keep the existing declaration-aware scanner in charge of that scope.
    for style in [
        "\\displaystyle",
        "\\textstyle",
        "\\scriptstyle",
        "\\scriptscriptstyle",
    ] {
        for (at, _) in latex.match_indices(style) {
            let suffix = latex[at + style.len()..].trim_start();
            if !suffix.starts_with('{') {
                return None;
            }
        }
    }
    if latex.len() > 65_536
        || !latex.contains('\\')
        || latex.bytes().filter(|byte| *byte == b'\\').count() > 512
        || latex
            .bytes()
            .filter(|byte| matches!(byte, b'^' | b'_'))
            .count()
            > 512
    {
        return None;
    }
    let mut depth = 0usize;
    for ch in latex.chars() {
        if matches!(ch, '{' | '(' | '[') {
            depth += 1;
            if depth > 64 {
                return None;
            }
        } else if matches!(ch, '}' | ')' | ']') {
            depth = depth.saturating_sub(1);
        }
    }
    let mut ast = crate::latex_parser::parse_latex(latex);
    crate::extrema::resolve(&mut ast, display);
    let mut found_symbol = false;
    let xml = render_symbol_ast(&ast, &mut found_symbol, 0)?;
    found_symbol.then_some(xml)
}

fn is_legacy_limit_head(node: &crate::latex_ast::LatexNode) -> bool {
    use crate::latex_ast::LatexNode;
    match node {
        LatexNode::Operator(name) => {
            matches!(name.as_str(), "lim" | "limsup" | "liminf" | "sup" | "inf")
        }
        LatexNode::Subscript { base, .. } | LatexNode::Superscript { base, .. } => {
            is_legacy_limit_head(base)
        }
        LatexNode::Group(nodes) if nodes.len() == 1 => is_legacy_limit_head(&nodes[0]),
        _ => false,
    }
}

// Linear sources already own a validated AST; a TeX bridge loses growth settings.
pub(crate) fn linear_ast_to_mathml(node: &crate::latex_ast::LatexNode) -> Result<String> {
    crate::omml::validate_omml_node(node, 0)
        .map_err(latexsnipper_foundation::SnipperError::Conversion)?;
    let body = render_symbol_ast(node, &mut false, 0).ok_or_else(|| {
        latexsnipper_foundation::SnipperError::Conversion(
            "AST is outside structured MathML output; retain the original source".into(),
        )
    })?;
    Ok(format!(
        "<math xmlns=\"http://www.w3.org/1998/Math/MathML\" display=\"block\">{body}</math>"
    ))
}

fn render_symbol_ast(
    node: &crate::latex_ast::LatexNode,
    found: &mut bool,
    depth: usize,
) -> Option<String> {
    if depth > 64 {
        return None;
    }
    use crate::latex_ast::LatexNode;
    let row = |node: &LatexNode, found: &mut bool| {
        render_symbol_ast(node, found, depth + 1).map(|xml| format!("<mrow>{xml}</mrow>"))
    };
    if let Some(xml) = render_fixed_delimiter_node(node) {
        return Some(xml);
    }
    if let Some(head) = crate::unicodemath_pilot::nary_limits(node) {
        *found = true;
        let integral = matches!(head.name, "int" | "iint" | "iiint" | "oint");
        let vertical = head.limits.unwrap_or(!integral);
        let movable = if integral || head.limits.is_some() {
            "false"
        } else {
            "true"
        };
        let growth = head.grow.map_or_else(String::new, |grow| {
            format!(" stretchy=\"{}\"", if grow { "true" } else { "false" })
        });
        let base = format!(
            "<mo largeop=\"true\" movablelimits=\"{movable}\"{growth}>{}</mo>",
            head.glyph
        );
        let lower = if let Some(node) = head.lower {
            Some(row(node, found)?)
        } else {
            None
        };
        let upper = if let Some(node) = head.upper {
            Some(row(node, found)?)
        } else {
            None
        };
        return Some(match (lower, upper) {
            (Some(lower), Some(upper)) => {
                let tag = if vertical { "munderover" } else { "msubsup" };
                format!("<{tag}>{base}{lower}{upper}</{tag}>")
            }
            (Some(lower), None) => {
                let tag = if vertical { "munder" } else { "msub" };
                format!("<{tag}>{base}{lower}</{tag}>")
            }
            (None, Some(upper)) => {
                let tag = if vertical { "mover" } else { "msup" };
                format!("<{tag}>{base}{upper}</{tag}>")
            }
            _ => base,
        });
    }
    if let Some(extremum) = crate::extrema::head(node) {
        *found = true;
        let base = format!("<mi mathvariant=\"normal\">{}</mi>", extremum.name);
        let lower = if let Some(node) = extremum.lower {
            Some(row(node, found)?)
        } else {
            None
        };
        let upper = if let Some(node) = extremum.upper {
            Some(row(node, found)?)
        } else {
            None
        };
        let vertical = extremum.limits.unwrap_or(true);
        return Some(match (lower, upper) {
            (Some(lower), Some(upper)) => {
                let tag = if vertical { "munderover" } else { "msubsup" };
                format!("<{tag}>{base}{lower}{upper}</{tag}>")
            }
            (Some(lower), None) => {
                let tag = if vertical { "munder" } else { "msub" };
                format!("<{tag}>{base}{lower}</{tag}>")
            }
            (None, Some(upper)) => {
                let tag = if vertical { "mover" } else { "msup" };
                format!("<{tag}>{base}{upper}</{tag}>")
            }
            _ => base,
        });
    }
    match node {
        LatexNode::Text(text) => {
            let text = text.trim();
            if text.contains('\\') {
                return None;
            }
            if text.is_empty() {
                return Some(String::new());
            }
            if text
                .chars()
                .all(|ch| ch.is_ascii_alphanumeric() || "+-=<>., ⅆ".contains(ch))
            {
                let mut output = String::new();
                let mut chars = text.chars().peekable();
                while let Some(ch) = chars.next() {
                    if ch == ' ' {
                        continue;
                    }
                    if ch.is_ascii_digit() {
                        let mut number = ch.to_string();
                        while chars.peek().is_some_and(char::is_ascii_digit) {
                            number.push(chars.next().expect("peeked digit"));
                        }
                        if chars.peek().is_some_and(|ch| matches!(ch, '.' | ','))
                            && chars.clone().nth(1).is_some_and(|ch| ch.is_ascii_digit())
                        {
                            number.push(chars.next().expect("peeked separator"));
                            while chars.peek().is_some_and(char::is_ascii_digit) {
                                number.push(chars.next().expect("peeked digit"));
                            }
                        }
                        output.push_str(&format!("<mn>{number}</mn>"));
                    } else if ch.is_ascii_alphabetic() || ch == 'ⅆ' {
                        output.push_str(&format!("<mi>{ch}</mi>"));
                    } else {
                        output.push_str(&format!("<mo>{}</mo>", xml_escape(&ch.to_string())));
                    }
                }
                return Some(format!("<mrow>{output}</mrow>"));
            }
            // Preserve existing punctuation, decimal and function-call token
            // behavior. No backslash means this cannot re-enter the AST path.
            Some(latex_to_mathml(text))
        }
        // Large operators retain the existing limit-placement path.
        LatexNode::Operator(name) => {
            if matches!(
                name.as_str(),
                "int"
                    | "iint"
                    | "iiint"
                    | "oint"
                    | "sum"
                    | "prod"
                    | "coprod"
                    | "bigcup"
                    | "bigcap"
                    | "limsup"
                    | "liminf"
                    | "sup"
                    | "inf"
            ) {
                None
            } else {
                *found |= crate::unicodemath_pilot::is_function_head(node);
                Some(format!(
                    "<mi mathvariant=\"normal\">{}</mi>",
                    xml_escape(name)
                ))
            }
        }
        LatexNode::OperatorName { .. }
            if crate::unicodemath_pilot::custom_function_name(node).is_some() =>
        {
            *found = true;
            Some(format!(
                "<mi mathvariant=\"normal\">{}</mi>",
                xml_escape(
                    crate::unicodemath_pilot::custom_function_name(node)
                        .expect("checked identifier")
                )
            ))
        }
        LatexNode::Greek(name) | LatexNode::Relation(name) => {
            let command = format!("\\{name}");
            let xml = map_symbol_mathml(&command)?;
            *found = true;
            Some(xml.into())
        }
        LatexNode::Symbol(name) => {
            if let Some(xml) = map_symbol_mathml(&format!("\\{name}")) {
                *found = true;
                Some(xml.into())
            } else if name.len() == 1 && "+-=<>/|(),.;:![]".contains(name.as_str()) {
                Some(format!("<mo>{}</mo>", xml_escape(name)))
            } else {
                None
            }
        }
        LatexNode::Command { name, args } if args.is_empty() => {
            let command = format!("\\{name}");
            let xml = map_symbol_mathml(&command)?;
            *found = true;
            Some(xml.into())
        }
        LatexNode::Command { name, args } if name == "text" && args.len() == 1 => {
            let LatexNode::Text(text) = &args[0] else {
                return None;
            };
            *found = true;
            Some(format!(
                "<mtext>{}</mtext>",
                xml_escape(&crate::latex_utils::decode_text_symbols(text))
            ))
        }
        LatexNode::Sequence(nodes) | LatexNode::Group(nodes) => {
            let mut parts = String::new();
            for (index, node) in nodes.iter().enumerate() {
                parts.push_str(&render_symbol_ast(node, found, depth + 1)?);
                if crate::unicodemath_pilot::is_function_head(node)
                    && nodes.get(index + 1).is_some_and(|argument| {
                        !crate::unicodemath_pilot::is_function_head(argument)
                            && match argument {
                                LatexNode::Relation(_) => false,
                                LatexNode::Text(text) => {
                                    !matches!(text.trim(), "+" | "-" | "=" | "<" | ">" | "." | ",")
                                }
                                _ => true,
                            }
                    })
                {
                    parts.push_str("<mo>&#x2061;</mo>");
                }
            }
            Some(format!("<mrow>{parts}</mrow>"))
        }
        LatexNode::Math { content, .. } => {
            let parts: Option<Vec<_>> = content
                .iter()
                .map(|node| render_symbol_ast(node, found, depth + 1))
                .collect();
            Some(format!("<mrow>{}</mrow>", parts?.concat()))
        }
        LatexNode::Command { name, args }
            if matches!(
                name.as_str(),
                "displaystyle" | "textstyle" | "scriptstyle" | "scriptscriptstyle"
            ) =>
        {
            Some(math_style_mathml(name, &row(args.first()?, found)?))
        }
        LatexNode::Delimited {
            left,
            content,
            right,
        } => {
            let left = latexsnipper_syntax::latex::scalable_delimiter_glyph(left)?;
            let right = latexsnipper_syntax::latex::scalable_delimiter_glyph(right)?;
            let segments = crate::latex_utils::delimiter_parts(content).ok()?;
            let parts: Option<Vec<_>> = segments
                .sections
                .into_iter()
                .map(|section| {
                    let nodes: Option<Vec<_>> = section
                        .iter()
                        .map(|node| render_symbol_ast(node, found, depth + 1))
                        .collect();
                    Some(format!("<mrow>{}</mrow>", nodes?.concat()))
                })
                .collect();
            Some(scalable_fence_mathml(
                left,
                &parts?,
                &segments.separators,
                right,
            ))
        }
        LatexNode::Fraction { num, den } => Some(format!(
            "<mfrac>{}{}</mfrac>",
            row(num, found)?,
            row(den, found)?
        )),
        LatexNode::SquareRoot { index, content } => {
            let content = row(content, found)?;
            Some(if let Some(index) = index {
                format!("<mroot>{content}{}</mroot>", row(index, found)?)
            } else {
                format!("<msqrt>{content}</msqrt>")
            })
        }
        LatexNode::Superscript { base, exp } => {
            if is_legacy_limit_head(base) {
                return None;
            }
            Some(if let LatexNode::Subscript { base, sub } = base.as_ref() {
                format!(
                    "<msubsup>{}{}{}</msubsup>",
                    row(base, found)?,
                    row(sub, found)?,
                    row(exp, found)?
                )
            } else {
                format!("<msup>{}{}</msup>", row(base, found)?, row(exp, found)?)
            })
        }
        LatexNode::Subscript { base, sub } => {
            if is_legacy_limit_head(base) {
                return None;
            }
            Some(
                if let LatexNode::Superscript { base, exp } = base.as_ref() {
                    format!(
                        "<msubsup>{}{}{}</msubsup>",
                        row(base, found)?,
                        row(sub, found)?,
                        row(exp, found)?
                    )
                } else {
                    format!("<msub>{}{}</msub>", row(base, found)?, row(sub, found)?)
                },
            )
        }
        LatexNode::Matrix { env, rows } => {
            let (open, close) = match env.as_str() {
                "matrix" | "smallmatrix" | "aligned" | "align" | "align*" | "gather"
                | "gather*" => ("", ""),
                "pmatrix" => ("(", ")"),
                "bmatrix" => ("[", "]"),
                "Bmatrix" => ("{", "}"),
                "vmatrix" => ("|", "|"),
                "Vmatrix" => ("‖", "‖"),
                _ => return None,
            };
            let table = render_symbol_table(rows, found, depth + 1)?;
            Some(if open.is_empty() {
                table
            } else {
                scalable_fence_mathml(open, &[table], &[], close)
            })
        }
        LatexNode::Cases(rows) => Some(scalable_fence_mathml(
            "{",
            &[render_symbol_table(rows, found, depth + 1)?],
            &[],
            "",
        )),
        _ => None,
    }
}

fn render_symbol_table(
    rows: &[Vec<crate::latex_ast::LatexNode>],
    found: &mut bool,
    depth: usize,
) -> Option<String> {
    let mut xml = String::from("<mtable>");
    for cells in rows {
        xml.push_str("<mtr>");
        for cell in cells {
            xml.push_str("<mtd><mrow>");
            xml.push_str(&render_symbol_ast(cell, found, depth + 1)?);
            xml.push_str("</mrow></mtd>");
        }
        xml.push_str("</mtr>");
    }
    xml.push_str("</mtable>");
    Some(xml)
}

fn matrix_to_mathml(content: &str, delimiters: Option<(&str, &str)>) -> String {
    let rows = split_matrix_rows(content);
    let mut rows_xml = Vec::new();
    for row in &rows {
        let cells: Vec<String> = row
            .iter()
            .map(|cell| {
                format!(
                    "    <mtd><mrow>{}</mrow></mtd>",
                    latex_to_mathml(cell.trim())
                )
            })
            .collect();
        rows_xml.push(format!("  <mtr>\n{}\n  </mtr>", cells.join("\n")));
    }
    let table = format!("<mtable>\n{}\n</mtable>", rows_xml.join("\n"));
    match delimiters {
        Some((open, close)) => scalable_fence_mathml(open, &[table], &[], close),
        None => table,
    }
}

fn render_matrix_node(node: &crate::latex_ast::LatexNode) -> Option<String> {
    use crate::latex_ast::LatexNode;
    match node {
        LatexNode::Command { name, args } if name.starts_with("begin{") => Some(format!(
            "<mtext>{}</mtext>",
            xml_escape(&args.first().map(ToString::to_string).unwrap_or_default())
        )),
        LatexNode::Array { column_spec, rows } => {
            let fallback = || format!("<mtext>{}</mtext>", xml_escape(&node.to_string()));
            let Ok(columns) = crate::array_columns::parse_columns(column_spec) else {
                return Some(fallback());
            };
            if columns.rules.iter().any(|count| *count > 1)
                || rows.iter().any(|row| row.len() > columns.align.len())
            {
                return Some(fallback());
            }
            let body: String = rows
                .iter()
                .map(|row| {
                    let cells: String = (0..columns.align.len())
                        .map(|index| {
                            let content = row
                                .get(index)
                                .map(|cell| {
                                    render_matrix_node(cell)
                                        .unwrap_or_else(|| latex_to_mathml(&cell.to_string()))
                                })
                                .unwrap_or_default();
                            format!("<mtd><mrow>{content}</mrow></mtd>")
                        })
                        .collect();
                    format!("<mtr>{cells}</mtr>")
                })
                .collect();
            let lines = columns.rules[1..columns.align.len()]
                .iter()
                .map(|count| if *count == 0 { "none" } else { "solid" })
                .collect::<Vec<_>>()
                .join(" ");
            let table = format!(
                "<mtable columnalign=\"{}\" columnlines=\"{lines}\">{body}</mtable>",
                columns.align.join(" ")
            );
            let mut notation = Vec::new();
            if columns.rules[0] == 1 {
                notation.push("left");
            }
            if *columns.rules.last().unwrap_or(&0) == 1 {
                notation.push("right");
            }
            Some(if notation.is_empty() {
                table
            } else {
                format!(
                    "<menclose notation=\"{}\">{table}</menclose>",
                    notation.join(" ")
                )
            })
        }
        LatexNode::Matrix { env, rows } => {
            let (open, close) = match env.as_str() {
                "matrix" | "smallmatrix" | "aligned" | "align" | "align*" | "gather"
                | "gather*" => ("", ""),
                "pmatrix" => ("(", ")"),
                "bmatrix" => ("[", "]"),
                "Bmatrix" => ("{", "}"),
                "vmatrix" => ("|", "|"),
                "Vmatrix" => ("‖", "‖"),
                _ => return None,
            };
            let table = ast_table_to_mathml(rows);
            if open.is_empty() {
                Some(table)
            } else {
                Some(scalable_fence_mathml(open, &[table], &[], close))
            }
        }
        LatexNode::Cases(rows) => Some(scalable_fence_mathml(
            "{",
            &[ast_table_to_mathml(rows)],
            &[],
            "",
        )),
        LatexNode::Fraction { num, den } => {
            let numerator = render_matrix_node(num);
            let denominator = render_matrix_node(den);
            if numerator.is_none() && denominator.is_none() {
                return None;
            }
            Some(format!(
                "<mfrac><mrow>{}</mrow><mrow>{}</mrow></mfrac>",
                numerator.unwrap_or_else(|| latex_to_mathml(&num.to_string())),
                denominator.unwrap_or_else(|| latex_to_mathml(&den.to_string()))
            ))
        }
        LatexNode::Sequence(nodes) | LatexNode::Group(nodes) => {
            let rendered: Vec<_> = nodes.iter().map(render_matrix_node).collect();
            if rendered.iter().all(Option::is_none) {
                return None;
            }
            let inner: String = nodes
                .iter()
                .zip(rendered)
                .map(|(node, rendered)| {
                    rendered.unwrap_or_else(|| latex_to_mathml(&node.to_string()))
                })
                .collect();
            Some(format!("<mrow>{inner}</mrow>"))
        }
        LatexNode::Superscript { base, exp } => render_matrix_node(base).map(|base| {
            format!(
                "<msup>{base}<mrow>{}</mrow></msup>",
                latex_to_mathml(&exp.to_string())
            )
        }),
        LatexNode::Subscript { base, sub } => render_matrix_node(base).map(|base| {
            format!(
                "<msub>{base}<mrow>{}</mrow></msub>",
                latex_to_mathml(&sub.to_string())
            )
        }),
        _ => None,
    }
}

fn ast_table_to_mathml(rows: &[Vec<crate::latex_ast::LatexNode>]) -> String {
    let rows: String = rows
        .iter()
        .map(|row| {
            let cells: String = row
                .iter()
                .map(|cell| {
                    let content = render_matrix_node(cell)
                        .unwrap_or_else(|| latex_to_mathml(&cell.to_string()));
                    format!("<mtd><mrow>{}</mrow></mtd>", content)
                })
                .collect();
            format!("<mtr>{cells}</mtr>")
        })
        .collect();
    format!("<mtable>{rows}</mtable>")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn grouped_layout_commands_preserve_trailing_expression() {
        let boxed = latex_to_mathml("\\boxed{x}+y");
        assert!(boxed.contains("<menclosed notation=\"box\">") && boxed.contains("<mi>y</mi>"));

        let phantom = latex_to_mathml("a+\\vphantom{b}+c");
        assert!(phantom.contains("<mpadded width=\"0\">") && phantom.contains("<mi>c</mi>"));
    }

    #[test]
    fn math_delimiter_macros_have_explicit_delimiters() {
        assert!(latex_to_mathml("\\abs{x}").contains(">|</mo>"));
        assert!(latex_to_mathml("\\norm{x}").contains(">‖</mo>"));
        assert!(latex_to_mathml("\\floor{x}").contains(">⌊</mo>"));
        assert!(latex_to_mathml("\\ceil{x}").contains(">⌈</mo>"));
    }

    #[test]
    fn math_style_declarations_apply_to_the_remaining_expression() {
        let display = latex_to_mathml("\\displaystyle \\sum_{i=1}^{n} x_i");
        assert!(display.starts_with("<mstyle displaystyle=\"true\" scriptlevel=\"0\">"));
        assert!(display.contains("∑"));

        let script = latex_to_mathml("\\scriptstyle{x}");
        assert!(script.contains("displaystyle=\"false\" scriptlevel=\"1\""));
    }

    #[test]
    fn accents_own_braced_and_unbraced_arguments() {
        for latex in ["\\vec v", "\\vec{v}", "\\overrightarrow{BC}"] {
            let mathml = latex_to_mathml(latex);
            assert!(mathml.contains("<mover>"), "{latex}: {mathml}");
            assert!(
                mathml.contains("<mi>v</mi>") || mathml.contains("BC"),
                "{latex}: {mathml}"
            );
            assert!(
                mathml.contains('→') && !mathml.contains("<mrow></mrow>"),
                "{latex}: {mathml}"
            );
        }
    }
}
