use quick_xml::events::Event;
use quick_xml::Reader;

/// Parse OMML XML string into a LaTeX string.
pub fn parse_omml_to_latex(xml: &str) -> Result<String, String> {
    let math_xml = extract_o_math(xml).unwrap_or_else(|| xml.to_string());
    let cleaned = strip_xml_declaration(&math_xml);
    parse_inner(&cleaned, false, false)
}

pub(crate) const GROWTH_BRIDGE: &str = "LatexSnipperInternalNaryNoGrow";
pub(crate) const GROWTH_TRUE_BRIDGE: &str = "LatexSnipperInternalNaryGrow";

pub(crate) fn parse_omml_to_linear_ast(xml: &str) -> Result<crate::latex_ast::LatexNode, String> {
    crate::xml_util::guard_single_math_root(xml, crate::xml_util::FormulaXmlKind::Omml)?;
    let latex = parse_inner(&strip_xml_declaration(xml), true, false)?;
    parse_growth_projection(&latex)
}

pub(crate) fn parse_omml_growth_ast(
    xml: &str,
) -> Result<Option<crate::latex_ast::LatexNode>, String> {
    crate::xml_util::guard_single_math_root(xml, crate::xml_util::FormulaXmlKind::Omml)?;
    let latex = parse_inner(&strip_xml_declaration(xml), true, true)?;
    if !latex.contains(GROWTH_BRIDGE) && !latex.contains(GROWTH_TRUE_BRIDGE) {
        return Ok(None);
    }
    parse_growth_projection(&latex).map(Some)
}

fn parse_growth_projection(latex: &str) -> Result<crate::latex_ast::LatexNode, String> {
    crate::document_converter::guard_formula_input(latex, false)
        .map_err(|error| error.to_string())?;
    if let Some(diagnostic) = latexsnipper_syntax::latex::validate_latex_structure(latex).first() {
        return Err(format!("{}: {}", diagnostic.code, diagnostic.message));
    }
    let mut node = crate::latex_parser::parse_latex(latex);
    restore_growth_nodes(&mut node)?;
    crate::omml::validate_omml_node(&node, 0)?;
    Ok(node)
}

// The bridge is produced only while reading properties, never exported as TeX.
pub(crate) fn restore_growth_nodes(node: &mut crate::latex_ast::LatexNode) -> Result<(), String> {
    use crate::latex_ast::LatexNode;
    match node {
        LatexNode::Sequence(nodes)
        | LatexNode::Group(nodes)
        | LatexNode::Delimited { content: nodes, .. } => {
            let mut index = 0;
            while index < nodes.len() {
                if matches!(&nodes[index], LatexNode::Command { name, args }
                    if matches!(name.as_str(), GROWTH_BRIDGE | GROWTH_TRUE_BRIDGE) && args.is_empty())
                {
                    if nodes
                        .get(index + 1)
                        .is_none_or(|head| crate::unicodemath_pilot::nary_limits(head).is_none())
                    {
                        return Err(
                            "Invalid structured n-ary growth bridge; retain the original XML"
                                .into(),
                        );
                    }
                    let grow = matches!(&nodes[index], LatexNode::Command { name, .. }
                        if name == GROWTH_TRUE_BRIDGE);
                    let head = nodes.remove(index + 1);
                    nodes[index] = LatexNode::Command {
                        name: if grow { "nary-grow" } else { "nary-no-grow" }.into(),
                        args: vec![head],
                    };
                }
                restore_growth_nodes(&mut nodes[index])?;
                index += 1;
            }
        }
        LatexNode::Command { args, .. } | LatexNode::OperatorName { args, .. } => {
            for child in args {
                restore_growth_nodes(child)?;
            }
        }
        LatexNode::Subscript { base, sub } => {
            restore_growth_nodes(base)?;
            restore_growth_nodes(sub)?;
        }
        LatexNode::Superscript { base, exp } => {
            restore_growth_nodes(base)?;
            restore_growth_nodes(exp)?;
        }
        LatexNode::Fraction { num, den } => {
            restore_growth_nodes(num)?;
            restore_growth_nodes(den)?;
        }
        LatexNode::SquareRoot { index, content } => {
            restore_growth_nodes(content)?;
            if let Some(index) = index {
                restore_growth_nodes(index)?;
            }
        }
        LatexNode::Matrix { rows, .. } | LatexNode::Array { rows, .. } | LatexNode::Cases(rows) => {
            for child in rows.iter_mut().flatten() {
                restore_growth_nodes(child)?;
            }
        }
        LatexNode::FontModifier { content, .. } | LatexNode::Accent { content, .. } => {
            restore_growth_nodes(content)?
        }
        _ => {}
    }
    Ok(())
}

fn strip_xml_declaration(xml: &str) -> String {
    let mut s = xml.to_string();
    if let Some(pos) = s.find("<?xml") {
        if let Some(end) = s[pos..].find("?>") {
            s.replace_range(..pos + end + 2, "");
        }
    }
    s
}

fn decode_entities(xml: &str) -> String {
    let mut r = xml
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&amp;", "&")
        .replace("&quot;", "\"");
    if let Ok(re) = regex::Regex::new(r"&#x([0-9a-fA-F]+);") {
        r = re
            .replace_all(&r, |c: &regex::Captures| {
                c.get(1)
                    .and_then(|h| u32::from_str_radix(h.as_str(), 16).ok())
                    .and_then(char::from_u32)
                    .map(|ch| ch.to_string())
                    .unwrap_or_default()
            })
            .to_string();
    }
    if let Ok(re) = regex::Regex::new(r"&#(\d+);") {
        r = re
            .replace_all(&r, |c: &regex::Captures| {
                c.get(1)
                    .and_then(|d| d.as_str().parse::<u32>().ok())
                    .and_then(char::from_u32)
                    .map(|ch| ch.to_string())
                    .unwrap_or_default()
            })
            .to_string();
    }
    r
}

fn extract_o_math(xml: &str) -> Option<String> {
    find_o_math_fragment(xml).or_else(|| {
        if xml.contains("&lt;") || xml.contains("&#") {
            find_o_math_fragment(&decode_entities(xml))
        } else {
            None
        }
    })
}

fn find_o_math_fragment(xml: &str) -> Option<String> {
    for pat in &[
        r"<m:oMathPara[\s>]",
        r"<m:oMath[\s>]",
        r"<\w+:oMathPara[\s>]",
        r"<\w+:oMath[\s>]",
        r"<oMathPara[\s>]",
        r"<oMath[\s>]",
    ] {
        if let Ok(re) = regex::Regex::new(pat) {
            if let Some(m) = re.find(xml) {
                let start = m.start();
                let tag = m
                    .as_str()
                    .trim()
                    .trim_end_matches('>')
                    .trim_end_matches(' ');
                let close = format!("</{}>", &tag[1..]);
                if let Some(end) = xml[start..].find(&close) {
                    let end = start + end + close.len();
                    let mut result = xml[start..end].to_string();
                    if !result.contains("xmlns:m=") {
                        if let Some(gt) = result.find('>') {
                            result.insert_str(gt, r#" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math""#);
                        }
                    }
                    return Some(result);
                }
            }
        }
    }
    None
}

fn local(name: &[u8]) -> String {
    let s = String::from_utf8_lossy(name).to_string();
    s.split(':').next_back().unwrap_or(&s).to_string()
}

fn attribute_value(
    element: &quick_xml::events::BytesStart<'_>,
    decoder: quick_xml::encoding::Decoder,
) -> Result<Option<String>, String> {
    let mut value = None;
    for attribute in element.attributes() {
        let attribute = attribute.map_err(|error| error.to_string())?;
        if local(attribute.key.as_ref()) == "val" {
            if value.is_some() {
                return Err("Ambiguous OMML value attribute".into());
            }
            value = Some(
                attribute
                    .decoded_and_normalized_value(quick_xml::XmlVersion::Implicit1_0, decoder)
                    .map_err(|error| error.to_string())?
                    .into_owned(),
            );
        }
    }
    Ok(value)
}

fn parse_inner(
    xml: &str,
    allow_growth: bool,
    preserve_explicit_grow: bool,
) -> Result<String, String> {
    let mut reader = Reader::from_str(xml);
    reader.config_mut().trim_text(false);
    let mut buf = Vec::new();
    let mut stack: Vec<(String, Vec<(String, String)>)> = Vec::new();
    let mut text_buf = String::new();
    let mut roots = Vec::new();

    loop {
        match reader.read_event_into(&mut buf) {
            Ok(Event::Start(e)) => {
                let tag = local(e.name().as_ref());
                if matches!(tag.as_str(), "grow" | "subHide" | "supHide")
                    && attribute_value(&e, reader.decoder())?.is_some_and(|value| value.is_empty())
                {
                    return Err("Empty explicit OMML on/off value; retain the original XML".into());
                }
                let children = if matches!(
                    tag.as_str(),
                    "count"
                        | "mcJc"
                        | "begChr"
                        | "endChr"
                        | "sepChr"
                        | "limLoc"
                        | "grow"
                        | "subHide"
                        | "supHide"
                ) {
                    attribute_value(&e, reader.decoder())?
                        .map(|value| vec![("$val".into(), value)])
                        .unwrap_or_default()
                } else {
                    Vec::new()
                };
                stack.push((tag, children));
                text_buf.clear();
            }
            Ok(Event::Text(e)) => {
                text_buf.push_str(&e.decode().map_err(|error| error.to_string())?);
            }
            Ok(Event::GeneralRef(e)) => {
                text_buf.push_str(&crate::xml_util::decode_xml_reference(&e)?);
            }
            Ok(Event::CData(e)) => {
                text_buf.push_str(&e.decode().map_err(|error| error.to_string())?);
            }
            Ok(Event::Empty(e)) => {
                let tag = local(e.name().as_ref());
                if matches!(tag.as_str(), "grow" | "subHide" | "supHide")
                    && attribute_value(&e, reader.decoder())?.is_some_and(|value| value.is_empty())
                {
                    return Err("Empty explicit OMML on/off value; retain the original XML".into());
                }
                if tag.starts_with("xmlns") {
                    continue;
                }
                let val = attribute_value(&e, reader.decoder())?.unwrap_or_default();
                let val = if matches!(tag.as_str(), "mc" | "mcPr") {
                    "c".into()
                } else {
                    val
                };
                let val = if tag == "spacing" {
                    match val.as_str() {
                        "1" => "\\quad ".to_owned(),
                        "2" => "\\qquad ".to_owned(),
                        "3" => "\\,".to_owned(),
                        "4" => "\\:".to_owned(),
                        "5" => "\\;".to_owned(),
                        "6" => "\\!".to_owned(),
                        _ => String::new(),
                    }
                } else {
                    val
                };
                if let Some((_, ref mut parent)) = stack.last_mut() {
                    parent.push((tag, val));
                } else {
                    roots.push(build_latex(&tag, &[], &val));
                }
            }
            Ok(Event::End(_)) => {
                if let Some((tag, mut tagged_children)) = stack.pop() {
                    let unique_properties: &[&str] = match tag.as_str() {
                        "mcPr" => &["count", "mcJc"],
                        "mc" => &["mcPr"],
                        "mPr" => &["mcs"],
                        "m" => &["mPr"],
                        "dPr" => &["begChr", "endChr", "sepChr"],
                        "d" => &["dPr"],
                        "naryPr" => &["chr", "limLoc", "grow", "subHide", "supHide"],
                        "nary" => &["naryPr", "chr", "sub", "sup", "e"],
                        _ => &[],
                    };
                    for property in unique_properties {
                        if tagged_children
                            .iter()
                            .filter(|(name, _)| name == property)
                            .count()
                            > 1
                        {
                            return Err(format!(
                                "Ambiguous OMML {tag} property {property}; retain the original XML"
                            ));
                        }
                    }
                    if tag == "mcs"
                        && tagged_children
                            .iter()
                            .filter(|(tag, _)| tag == "mc")
                            .map(|(_, value)| value.len())
                            .sum::<usize>()
                            > 128
                    {
                        return Err("OMML expanded matrix column count exceeds 128".into());
                    }
                    if tag == "mcPr" {
                        let count = get_child(&tagged_children, "count");
                        let count = if count.is_empty() {
                            1
                        } else {
                            count
                                .parse::<usize>()
                                .map_err(|_| "Invalid OMML matrix column count")?
                        };
                        if count == 0 || count > 128 {
                            return Err(
                                "OMML matrix column count exceeds the supported bound".into()
                            );
                        }
                        let alignment = get_child(&tagged_children, "mcJc");
                        if !matches!(alignment.as_str(), "" | "left" | "center" | "right") {
                            return Err("Unsupported OMML matrix column alignment".into());
                        }
                    }
                    if tag == "dPr" {
                        for (name, glyph) in &tagged_children {
                            if matches!(name.as_str(), "begChr" | "endChr" | "sepChr")
                                && latexsnipper_syntax::latex::scalable_delimiter_glyph(
                                    &crate::latex_utils::delimiter_source_token(glyph),
                                ) != Some(glyph.as_str())
                            {
                                return Err(
                                    "Unsupported OMML delimiter glyph; retain the original XML"
                                        .into(),
                                );
                            }
                        }
                    }
                    if tag == "naryPr" {
                        for property in ["subHide", "supHide"] {
                            let value = get_child(&tagged_children, property);
                            if !matches!(value.as_str(), "" | "0" | "1" | "false" | "true") {
                                return Err("Unsupported OMML n-ary visibility value; retain the original XML".into());
                            }
                        }
                        let grow = get_child(&tagged_children, "grow");
                        if !matches!(grow.as_str(), "" | "0" | "1" | "false" | "true") {
                            return Err(
                                "Unsupported OMML n-ary growth value; retain the original XML"
                                    .into(),
                            );
                        }
                        if !allow_growth && matches!(grow.as_str(), "0" | "false") {
                            return Err("OMML n-ary growth cannot be faithfully exported through LaTeX; retain the original XML".into());
                        }
                        let location = get_child(&tagged_children, "limLoc");
                        if (tagged_children.iter().any(|(name, _)| name == "limLoc")
                            && location.is_empty())
                            || !matches!(location.as_str(), "" | "undOvr" | "subSup")
                        {
                            return Err(
                                "Unsupported OMML n-ary limit location; retain the original XML"
                                    .into(),
                            );
                        }
                    }
                    let text = text_buf.clone();
                    if matches!(tag.as_str(), "grow" | "subHide" | "supHide")
                        && (!text.trim().is_empty()
                            || tagged_children.iter().any(|(name, _)| name != "$val"))
                    {
                        return Err("Non-leaf OMML on/off property; retain the original XML".into());
                    }
                    if allow_growth
                        && (text.contains(GROWTH_BRIDGE) || text.contains(GROWTH_TRUE_BRIDGE))
                    {
                        return Err("Reserved structured growth marker in source text; retain the original XML".into());
                    }
                    if tag == "nary" {
                        if tagged_children.iter().any(|(name, _)| {
                            matches!(name.as_str(), "grow" | "limLoc" | "subHide" | "supHide")
                        }) {
                            return Err(
                                "Misplaced OMML n-ary style property; retain the original XML"
                                    .into(),
                            );
                        }
                        if allow_growth && !tagged_children.iter().any(|(name, _)| name == "naryPr")
                        {
                            tagged_children.push(("$naryNoGrow".into(), "1".into()));
                        }
                        for (slot, hide) in [("sub", "$narySubHide"), ("sup", "$narySupHide")] {
                            if get_child(&tagged_children, hide) == "1"
                                && !get_child(&tagged_children, slot).trim().is_empty()
                            {
                                return Err("Hidden nonempty OMML limit has no faithful finite projection; retain the original XML".into());
                            }
                        }
                        let direct = get_child(&tagged_children, "chr");
                        let properties = get_child(&tagged_children, "naryPr");
                        if !direct.is_empty() && !properties.is_empty() {
                            return Err(
                                "Ambiguous OMML n-ary character; retain the original XML".into()
                            );
                        }
                        let glyph = if direct.is_empty() {
                            properties.as_str()
                        } else {
                            direct.as_str()
                        };
                        if !matches!(
                            glyph,
                            "" | "∫"
                                | "∬"
                                | "∭"
                                | "∮"
                                | "∑"
                                | "∏"
                                | "∐"
                                | "⋃"
                                | "⋂"
                                | "∂"
                                | "∇"
                        ) {
                            return Err(
                                "Unsupported OMML n-ary character; retain the original XML".into(),
                            );
                        }
                    }
                    text_buf.clear();

                    let result = build_latex(&tag, &tagged_children, &text);

                    if let Some((_, ref mut parent)) = stack.last_mut() {
                        parent.push((tag, result));
                        if parent.last().is_some_and(|(tag, _)| tag == "naryPr") {
                            for (property, key) in
                                [("subHide", "$narySubHide"), ("supHide", "$narySupHide")]
                            {
                                if tagged_children.iter().any(|(name, _)| name == property) {
                                    let value = get_child(&tagged_children, property);
                                    let hidden = !matches!(value.as_str(), "0" | "false");
                                    parent
                                        .push((key.into(), if hidden { "1" } else { "0" }.into()));
                                }
                            }
                            let location = get_child(&tagged_children, "limLoc");
                            if !location.is_empty() {
                                parent.push(("$naryLimLoc".into(), location));
                            }
                            let grow = get_child(&tagged_children, "grow");
                            if allow_growth
                                && (matches!(grow.as_str(), "0" | "false")
                                    || !tagged_children.iter().any(|(name, _)| name == "grow"))
                            {
                                parent.push(("$naryNoGrow".into(), "1".into()));
                            } else if allow_growth && preserve_explicit_grow {
                                parent.push(("$naryGrow".into(), "1".into()));
                            }
                        }
                    } else {
                        roots.push(result);
                    }
                }
            }
            Ok(Event::Eof) => break,
            Ok(Event::Comment(_))
            | Ok(Event::Decl(_))
            | Ok(Event::PI(_))
            | Ok(Event::DocType(_)) => continue,
            Err(e) => return Err(format!("OMML parse error: {}", e)),
        }
        buf.clear();
    }
    if !stack.is_empty() {
        return Err("Unclosed OMML element; retain the original XML".into());
    }
    if roots.is_empty() {
        Err("Empty OMML document".to_string())
    } else {
        Ok(latexsnipper_ast::formula_layout::join_latex_fragments(
            roots,
        ))
    }
}

fn build_latex(tag: &str, children: &[(String, String)], _text: &str) -> String {
    match tag {
        "oMathPara" | "oMath" => children
            .iter()
            .map(|(_, v)| v.clone())
            .collect::<Vec<_>>()
            .join(""),
        "r" => {
            let cells: Vec<String> = children
                .iter()
                .filter(|(t, _)| t == "e")
                .map(|(_, v)| v.clone())
                .collect();
            if !cells.is_empty() {
                return cells.join(" & ");
            }

            // Extract run properties from rPr and apply them to all nested run content.
            let mut color = String::new();
            let mut bold = false;
            let mut italic = false;
            let mut normal_text = false;
            let mut size = String::new();
            let mut sty = String::new();
            for (tag, val) in children {
                if tag == "rPr" {
                    for part in val.split(',') {
                        if let Some(c) = part.strip_prefix("color=") {
                            color = c.to_string();
                        }
                        if part == "b=1" {
                            bold = true;
                        }
                        if part == "i=1" {
                            italic = true;
                        }
                        if part == "nor=1" {
                            normal_text = true;
                        }
                        if let Some(s) = part.strip_prefix("sz=") {
                            size = s.to_string();
                        }
                        if let Some(s) = part.strip_prefix("sty=") {
                            sty = s.to_string();
                        }
                    }
                }
            }
            let text: String = children
                .iter()
                .filter(|(t, _)| t != "rPr")
                .map(|(_, v)| v.as_str())
                .collect::<Vec<_>>()
                .concat();
            let mut result = text;
            // Apply math style (m:sty) — overrides individual bold/italic
            if !sty.is_empty() {
                result = match sty.as_str() {
                    "b" => format!("\\mathbf{{{}}}", result),
                    "d" => format!("\\mathbb{{{}}}", result),
                    "c" => format!("\\mathcal{{{}}}", result),
                    "f" => format!("\\mathfrak{{{}}}", result),
                    "i" => format!("\\mathit{{{}}}", result),
                    "s" => format!("\\mathsf{{{}}}", result),
                    "t" => format!("\\mathtt{{{}}}", result),
                    _ => result,
                };
            } else {
                if italic {
                    result = format!("\\mathit{{{}}}", result);
                }
                if bold {
                    result = format!("\\mathbf{{{}}}", result);
                }
                if normal_text {
                    result = format!("\\mathrm{{{}}}", result);
                }
            }
            if !size.is_empty() {
                result = format!("\\{}{{{}}}", half_points_to_latex_size(&size), result);
            }
            if !color.is_empty() {
                result = format!("\\textcolor{{{}}}{{{}}}", color, result);
            }
            result
        }
        "t" => crate::latex_utils::escape_text_symbols(_text),
        "f" => {
            let (num, den) = get_two(children);
            format!("\\frac{{{}}}{{{}}}", num, den)
        }
        "sSup" => {
            let (base, sup) = get_two(children);
            format!("{{{}}}^{{{}}}", base, sup)
        }
        "sSub" => {
            let (base, sub) = get_two(children);
            format!("{{{}}}_{{{}}}", base, sub)
        }
        "sSubSup" => {
            let (base, sub, sup) = get_three(children);
            format!("{{{}}}_{{{}}}^{{{}}}", base, sub, sup)
        }
        "rad" => {
            let content = get_child(children, "e");
            let deg = get_child(children, "deg");
            if deg.is_empty() {
                format!("\\sqrt{{{}}}", content)
            } else {
                format!("\\sqrt[{}]{{{}}}", deg, content)
            }
        }
        "nary" => {
            let chr = {
                let c = get_child(children, "chr");
                if c.is_empty() {
                    get_child(children, "naryPr")
                } else {
                    c
                }
            };
            let mut op = map_nary(&chr).to_owned();
            let sub = get_child(children, "sub");
            let sup = get_child(children, "sup");
            let present = |slot: &str, hide: &str, value: &str| {
                let visibility = get_child(children, hide);
                !value.trim().is_empty()
                    || visibility == "0"
                    || (visibility != "1" && children.iter().any(|(tag, _)| tag == slot))
            };
            let has_sub = present("sub", "$narySubHide", &sub);
            let has_sup = present("sup", "$narySupHide", &sup);
            let body = get_child(children, "e");
            let location = get_child(children, "$naryLimLoc");
            let integral = matches!(chr.as_str(), "" | "∫" | "∬" | "∭" | "∮");
            if (has_sub || has_sup)
                && ((integral && location == "undOvr") || (!integral && location == "subSup"))
            {
                op.push_str(if location == "undOvr" {
                    "\\limits"
                } else {
                    "\\nolimits"
                });
            }
            if get_child(children, "$naryNoGrow") == "1" || get_child(children, "$naryGrow") == "1"
            {
                if has_sub {
                    op.push_str(&format!("_{{{sub}}}"));
                }
                if has_sup {
                    op.push_str(&format!("^{{{sup}}}"));
                }
                let marker = if get_child(children, "$naryGrow") == "1" {
                    GROWTH_TRUE_BRIDGE
                } else {
                    GROWTH_BRIDGE
                };
                let head = format!("\\{marker}{{{op}}}");
                return format!("{{{head}{{{body}}}}}");
            }
            if !has_sub && !has_sup {
                if body.is_empty() {
                    op
                } else {
                    format!("{}{{{}}}", op, body)
                }
            } else if !has_sub {
                format!("{}^{{{}}}{{{}}}", op, sup, body)
            } else if !has_sup {
                format!("{}_{{{}}}{{{}}}", op, sub, body)
            } else {
                format!("{}^{{{}}}_{{{}}}{{{}}}", op, sup, sub, body)
            }
        }
        "naryPr" => get_child(children, "chr"),
        "func" => {
            let name = get_child(children, "fName");
            let arg = get_child(children, "e");
            let cmd = map_function_name(&name);
            if arg.is_empty() {
                cmd
            } else {
                format!("{}{{{}}}", cmd, arg)
            }
        }
        "fName" => children
            .iter()
            .map(|(_, v)| v.clone())
            .collect::<Vec<_>>()
            .join(""),
        "d" => {
            let (beg, end) = get_delimiter_chars(children);
            let rows: Vec<String> = children
                .iter()
                .filter(|(t, _)| t == "r")
                .map(|(_, v)| v.clone())
                .collect();
            if !rows.is_empty() {
                return format_delimited_rows(&beg, &end, &rows);
            }

            let content: Vec<String> = children
                .iter()
                .filter(|(t, _)| t == "e")
                .map(|(_, v)| v.clone())
                .collect();
            if content.len() > 1 {
                let properties = get_child(children, "dPr");
                let separator = properties
                    .split_once(",sep=")
                    .map(|(_, value)| value)
                    .unwrap_or("|");
                let joined = crate::latex_utils::join_middle_source(&content, separator);
                return crate::latex_utils::delimited_source(&beg, &joined, &end);
            }
            let joined = content.join(" \\\\ ");
            if let Some(body) = whole_matrix_body(&joined) {
                if beg == "{" && end.is_empty() {
                    return format!("\\begin{{cases}} {body} \\end{{cases}}");
                }
                if let Some(env) = matrix_env_from_delimiters(&beg, &end) {
                    return format!("\\begin{{{env}}} {body} \\end{{{env}}}");
                }
            }
            if joined.contains("\\begin{array}") {
                // Do not replace explicit per-column layout with a delimiter matrix.
                return crate::latex_utils::delimited_source(&beg, &joined, &end);
            }
            if joined.contains("\\begin{matrix}") {
                // Retain nested or adjacent matrices instead of inferring a new outer table.
                return crate::latex_utils::delimited_source(&beg, &joined, &end);
            }
            if beg == "{" && end.is_empty() && (joined.contains(" & ") || joined.contains("\\\\")) {
                return format!("\\begin{{cases}} {} \\end{{cases}}", joined);
            }
            if let Some(env) = matrix_env_from_delimiters(&beg, &end) {
                if joined.contains(" & ") || joined.contains("\\\\") {
                    return format!("\\begin{{{}}} {} \\end{{{}}}", env, joined, env);
                }
            }
            crate::latex_utils::delimited_source(&beg, &joined, &end)
        }
        "bar" => {
            let pos = get_child(children, "pos");
            let content = get_child(children, "e");
            if pos == "top" {
                format!("\\overline{{{}}}", content)
            } else {
                format!("\\underline{{{}}}", content)
            }
        }
        "acc" => {
            let chr = {
                let c = get_child(children, "chr");
                if c.is_empty() {
                    get_child(children, "accPr")
                } else {
                    c
                }
            };
            let content = get_child(children, "e");
            map_accent(&chr, &content)
        }
        "groupChr" => {
            let chr = get_child(children, "chr");
            let pos = get_child(children, "pos");
            let content = get_child(children, "e");
            if chr == "\u{23DF}" || chr == "\u{23DE}" {
                if pos == "bot" {
                    format!("\\underbrace{{{}}}", content)
                } else {
                    format!("\\overbrace{{{}}}", content)
                }
            } else {
                content
            }
        }
        "eqArr" => {
            let rows: Vec<String> = children
                .iter()
                .filter(|(t, _)| t == "e")
                .map(|(_, v)| v.clone())
                .collect();
            format!(
                "\\begin{{aligned}} {} \\end{{aligned}}",
                rows.join(" \\\\ ")
            )
        }
        "limLow" => {
            let base = normalize_limit_base(&get_child(children, "e"));
            let limit = normalize_limit_script(&get_child(children, "lim"));
            format!("{}_{{{}}}", base, limit)
        }
        "limUpp" => {
            let base = normalize_limit_base(&get_child(children, "e"));
            let limit = normalize_limit_script(&get_child(children, "lim"));
            format!("{}^{{{}}}", base, limit)
        }
        "m" => {
            let rows: Vec<String> = children
                .iter()
                .filter(|(t, _)| t == "mr" || t == "mRow")
                .map(|(_, v)| v.clone())
                .collect();
            let body = if !rows.is_empty() {
                rows.join(" \\\\ ")
            } else {
                children
                    .iter()
                    .filter(|(t, _)| t == "e")
                    .map(|(_, v)| v.clone())
                    .collect::<Vec<_>>()
                    .join(" & ")
            };
            let columns = get_child(children, "mPr");
            if columns.is_empty() {
                format!("\\begin{{matrix}} {body} \\end{{matrix}}")
            } else {
                format!("\\begin{{array}}{{{columns}}}{body}\\end{{array}}")
            }
        }
        "mPr" => get_child(children, "mcs"),
        "count" | "mcJc" | "limLoc" | "grow" | "subHide" | "supHide" => get_child(children, "$val"),
        "mcs" => children
            .iter()
            .filter(|(tag, _)| tag == "mc")
            .map(|(_, value)| value.as_str())
            .collect(),
        "mc" => {
            let properties = get_child(children, "mcPr");
            if properties.is_empty() {
                "c".into()
            } else {
                properties
            }
        }
        "mcPr" => {
            let count = get_child(children, "count")
                .parse::<usize>()
                .unwrap_or(1)
                .min(128);
            let alignment = get_child(children, "mcJc");
            match alignment.as_str() {
                "left" => "l",
                "right" => "r",
                _ => "c",
            }
            .repeat(count)
        }
        "mr" | "mRow" => {
            let cells: Vec<String> = children
                .iter()
                .filter(|(t, _)| t == "e")
                .map(|(_, v)| v.clone())
                .collect();
            if cells.len() <= 1 {
                cells.first().cloned().unwrap_or_default()
            } else {
                cells.join(" & ")
            }
        }
        "e" | "sub" | "sup" | "num" | "den" | "deg" | "lim" => children
            .iter()
            .map(|(_, v)| v.clone())
            .collect::<Vec<_>>()
            .join(""),
        "pos" | "chr" => children
            .iter()
            .map(|(_, v)| v.clone())
            .collect::<Vec<_>>()
            .join(""),
        "begChr" | "endChr" | "sepChr" => get_child(children, "$val"),
        "dPr" => {
            let beg = children
                .iter()
                .find(|(tag, _)| tag == "begChr")
                .map(|(_, value)| value.clone())
                .unwrap_or_else(|| "(".into());
            let end = children
                .iter()
                .find(|(tag, _)| tag == "endChr")
                .map(|(_, value)| value.clone())
                .unwrap_or_else(|| ")".into());
            let separator = children
                .iter()
                .find(|(tag, _)| tag == "sepChr")
                .map(|(_, value)| format!(",sep={value}"))
                .unwrap_or_default();
            format!("beg={},end={}{}", beg, end, separator)
        }
        // Run properties: extract color/bold/italic/style for parent <m:r>
        "rPr" | "w:rPr" => {
            let mut parts = Vec::new();
            for (tag, val) in children {
                if tag == "color" || tag == "w:color" {
                    parts.push(format!("color={}", val));
                }
                if tag == "b" || tag == "w:b" {
                    parts.push("b=1".to_string());
                }
                if tag == "i" || tag == "w:i" {
                    parts.push("i=1".to_string());
                }
                if tag == "nor" {
                    parts.push("nor=1".to_string());
                }
                if tag == "sz" || tag == "w:sz" {
                    parts.push(format!("sz={}", val));
                }
                if tag == "sty" && !val.is_empty() {
                    parts.push(format!("sty={}", val));
                }
                // Handle nested w:rPr inside rPr
                if (tag == "w:rPr" || tag == "rPr") && !val.is_empty() {
                    for part in val.split(',') {
                        if !part.is_empty() {
                            parts.push(part.to_string());
                        }
                    }
                }
            }
            parts.join(",")
        }
        _ => children
            .iter()
            .map(|(_, v)| v.clone())
            .collect::<Vec<_>>()
            .join(""),
    }
}

fn half_points_to_latex_size(value: &str) -> &'static str {
    let Ok(size) = value.parse::<u16>() else {
        return "normalsize";
    };
    match size {
        0..=12 => "tiny",
        13..=15 => "scriptsize",
        16..=17 => "footnotesize",
        18..=19 => "small",
        20..=23 => "normalsize",
        24..=28 => "large",
        29..=34 => "Large",
        35..=40 => "LARGE",
        41..=49 => "huge",
        _ => "Huge",
    }
}

fn is_content_tag(t: &str) -> bool {
    matches!(t, "e" | "sub" | "sup" | "num" | "den" | "deg")
}

fn get_two(children: &[(String, String)]) -> (String, String) {
    let content: Vec<&String> = children
        .iter()
        .filter(|(t, _)| is_content_tag(t))
        .map(|(_, v)| v)
        .collect();
    (
        content.first().map(|s| s.to_string()).unwrap_or_default(),
        content.get(1).map(|s| s.to_string()).unwrap_or_default(),
    )
}

fn get_three(children: &[(String, String)]) -> (String, String, String) {
    let content: Vec<&String> = children
        .iter()
        .filter(|(t, _)| is_content_tag(t))
        .map(|(_, v)| v)
        .collect();
    (
        content.first().map(|s| s.to_string()).unwrap_or_default(),
        content.get(1).map(|s| s.to_string()).unwrap_or_default(),
        content.get(2).map(|s| s.to_string()).unwrap_or_default(),
    )
}

fn get_child(children: &[(String, String)], tag: &str) -> String {
    children
        .iter()
        .find(|(t, _)| t == tag)
        .map(|(_, v)| v.clone())
        .unwrap_or_default()
}

fn get_delimiter_chars(children: &[(String, String)]) -> (String, String) {
    let beg = get_child(children, "begChr");
    let end = get_child(children, "endChr");
    if !beg.is_empty() || !end.is_empty() {
        return (beg, end);
    }

    let dpr = get_child(children, "dPr");
    if let Some(rest) = dpr.strip_prefix("beg=") {
        if let Some((beg, end_part)) = rest.split_once(",end=") {
            return (
                beg.to_string(),
                end_part
                    .split_once(",sep=")
                    .map_or(end_part, |(end, _)| end)
                    .to_string(),
            );
        }
    }
    let mut chars = dpr.chars();
    let Some(first) = chars.next() else {
        return ("(".into(), ")".into());
    };
    let Some(last) = chars.next_back() else {
        return (first.to_string(), String::new());
    };
    (first.to_string(), last.to_string())
}

fn format_delimited_rows(beg: &str, end: &str, rows: &[String]) -> String {
    if beg == "{" && (end == "}" || end.is_empty()) && rows.iter().any(|row| row.contains(" & ")) {
        return format!("\\begin{{cases}} {} \\end{{cases}}", rows.join(" \\\\ "));
    }

    if let Some(env) = matrix_env_from_delimiters(beg, end) {
        return format!(
            "\\begin{{{}}} {} \\end{{{}}}",
            env,
            rows.join(" \\\\ "),
            env
        );
    }

    format!("{}{}{}", beg, rows.join(" \\\\ "), end)
}

fn whole_matrix_body(value: &str) -> Option<&str> {
    let value = value.trim();
    let begin = "\\begin{matrix}";
    let end = "\\end{matrix}";
    let content = value.strip_prefix(begin)?;
    let mut depth = 1usize;
    // Inspect only the canonical wrappers produced by this reader, including nested matrices.
    for (offset, _) in content.match_indices('\\') {
        let remaining = &content[offset..];
        if remaining.starts_with(begin) {
            depth += 1;
        } else if remaining.starts_with(end) {
            depth -= 1;
            if depth == 0 {
                return (offset + end.len() == content.len()).then(|| content[..offset].trim());
            }
        }
    }
    None
}

fn matrix_env_from_delimiters(beg: &str, end: &str) -> Option<&'static str> {
    match (beg, end) {
        ("(", ")") => Some("pmatrix"),
        ("[", "]") => Some("bmatrix"),
        ("{", "}") => Some("Bmatrix"),
        ("|", "|") => Some("vmatrix"),
        ("‖", "‖") => Some("Vmatrix"),
        _ => None,
    }
}

fn map_nary(chr: &str) -> &str {
    match chr {
        "\u{222B}" => "\\int",
        "\u{222E}" => "\\oint",
        "\u{222C}" => "\\iint",
        "\u{222D}" => "\\iiint",
        "\u{2211}" => "\\sum",
        "\u{220F}" => "\\prod",
        "\u{2210}" => "\\coprod",
        "\u{22C3}" => "\\bigcup",
        "\u{22C2}" => "\\bigcap",
        "\u{2202}" => "\\partial",
        "\u{2207}" => "\\nabla",
        _ => "\\int",
    }
}

fn map_function_name(name: &str) -> String {
    let trimmed = name.trim();
    if trimmed.len() <= 65_536
        && trimmed
            .bytes()
            .filter(|byte| matches!(byte, b'\\' | b'^' | b'_'))
            .count()
            <= 64
        && trimmed.contains(['^', '_'])
    {
        let mut node = crate::latex_parser::parse_latex(trimmed);
        if normalize_scripted_function_head(&mut node, 0) {
            return node.to_string();
        }
    }
    let normalized = trimmed
        .strip_prefix("\\mathrm{")
        .and_then(|value| value.strip_suffix('}'))
        .unwrap_or(trimmed);
    match normalized {
        "lim" | "limsup" | "liminf" | "max" | "min" | "sup" | "inf" | "log" | "ln" | "sin"
        | "cos" | "tan" | "cot" | "sec" | "csc" | "arcsin" | "arccos" | "arctan" | "sinh"
        | "cosh" | "tanh" | "exp" | "dim" | "det" | "gcd" => format!("\\{}", normalized),
        other if !other.is_empty() => format!("\\operatorname{{{}}}", other),
        _ => String::new(),
    }
}

pub(crate) fn normalize_scripted_function_head(
    node: &mut crate::latex_ast::LatexNode,
    depth: usize,
) -> bool {
    use crate::latex_ast::LatexNode;
    fn normalized_identifier(name: String) -> Option<LatexNode> {
        if !crate::unicodemath_pilot::is_identifier_name(&name) {
            return None;
        }
        Some(if crate::unicodemath_pilot::is_function_name(&name) {
            LatexNode::Operator(name)
        } else {
            LatexNode::OperatorName {
                name: "operatorname".into(),
                args: vec![LatexNode::Text(name)],
            }
        })
    }
    if depth >= 64 {
        return false;
    }
    match node {
        LatexNode::FontModifier { font, content } if font == "mathrm" => {
            let Some(name) = crate::unicodemath_pilot::function_identifier_text(content)
                .and_then(normalized_identifier)
            else {
                return false;
            };
            *node = name;
            true
        }
        LatexNode::Text(_) | LatexNode::Sequence(_) | LatexNode::Greek(_) => {
            let Some(name) = crate::unicodemath_pilot::function_identifier_text(node)
                .and_then(normalized_identifier)
            else {
                return false;
            };
            *node = name;
            true
        }
        LatexNode::Operator(name) => crate::unicodemath_pilot::is_function_name(name),
        LatexNode::OperatorName { .. } => {
            crate::unicodemath_pilot::custom_function_name(node).is_some()
        }
        LatexNode::Superscript { base, .. } | LatexNode::Subscript { base, .. } => {
            normalize_scripted_function_head(base, depth + 1)
        }
        LatexNode::Group(nodes) if nodes.len() == 1 => {
            normalize_scripted_function_head(&mut nodes[0], depth + 1)
        }
        _ => false,
    }
}

fn normalize_limit_base(base: &str) -> String {
    let trimmed = base.trim();
    let name = trimmed
        .strip_prefix("\\mathrm{")
        .and_then(|value| value.strip_suffix('}'))
        .unwrap_or(trimmed);
    match name {
        "lim" | "limsup" | "liminf" | "max" | "min" | "sup" | "inf" => {
            format!("\\{}", name)
        }
        _ => base.to_string(),
    }
}

fn normalize_limit_script(script: &str) -> String {
    script
        .replace('\u{2192}', "\\to ")
        .replace('\u{21D2}', "\\implies ")
}

fn map_accent(chr: &str, content: &str) -> String {
    match chr {
        "\u{0302}" | "\u{02C6}" => format!("\\hat{{{}}}", content),
        "\u{0304}" | "\u{02C9}" => format!("\\bar{{{}}}", content),
        "\u{0305}" => format!("\\overline{{{}}}", content),
        "\u{0307}" => format!("\\dot{{{}}}", content),
        "\u{0308}" => format!("\\ddot{{{}}}", content),
        "\u{030C}" | "\u{02C7}" => format!("\\check{{{}}}", content),
        "\u{0303}" | "\u{02DC}" => format!("\\tilde{{{}}}", content),
        "\u{20D7}" | "\u{2192}" => format!("\\vec{{{}}}", content),
        _ => format!("\\hat{{{}}}", content),
    }
}

#[cfg(test)]
mod structural_tests {
    use super::*;

    #[test]
    fn nary_limit_keeps_nested_fraction() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:nary><m:naryPr><m:chr m:val="∑"/></m:naryPr><m:sub><m:f><m:num><m:r><m:t>a</m:t></m:r></m:num><m:den><m:r><m:t>b</m:t></m:r></m:den></m:f></m:sub><m:sup><m:r><m:t>n</m:t></m:r></m:sup><m:e><m:r><m:t>x</m:t></m:r></m:e></m:nary></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert!(
            result.contains("\\sum") && result.contains("\\frac{a}{b}"),
            "nested nary limit was lost: {}",
            result
        );
    }

    #[test]
    fn lower_limit_preserves_operator_and_relation_commands() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:limLow><m:e><m:r><m:rPr><m:nor/></m:rPr><m:t>lim</m:t></m:r></m:e><m:lim><m:r><m:t>x→1</m:t></m:r></m:lim></m:limLow></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert_eq!(result, "\\lim_{x\\to 1}");
    }

    #[test]
    fn upper_limit_preserves_known_operator_command() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:limUpp><m:e><m:r><m:rPr><m:nor/></m:rPr><m:t>sup</m:t></m:r></m:e><m:lim><m:r><m:t>n</m:t></m:r></m:lim></m:limUpp></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert_eq!(result, "\\sup^{n}");
    }

    #[test]
    fn function_name_normal_run_roundtrips_to_command() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:func><m:fName><m:r><m:rPr><m:nor/></m:rPr><m:t>sin</m:t></m:r></m:fName><m:e><m:r><m:t>x</m:t></m:r></m:e></m:func></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert_eq!(result, "\\sin{x}");
    }

    #[test]
    fn delimited_rows_become_matrix_environment() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:r><m:e><m:r><m:t>a</m:t></m:r></m:e><m:e><m:r><m:t>b</m:t></m:r></m:e></m:r><m:r><m:e><m:r><m:t>c</m:t></m:r></m:e><m:e><m:r><m:t>d</m:t></m:r></m:e></m:r></m:d></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert!(
            result.contains("\\begin{pmatrix}")
                && result.contains("a & b")
                && result.contains("c & d"),
            "matrix row or column boundaries were lost: {}",
            result
        );
    }

    #[test]
    fn delimited_brace_rows_become_cases_environment() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:d><m:dPr><m:begChr m:val="{"/><m:endChr m:val="}"/></m:dPr><m:r><m:e><m:r><m:t>x</m:t></m:r></m:e><m:e><m:r><m:t>a</m:t></m:r></m:e><m:e><m:r><m:t>b</m:t></m:r></m:e></m:r><m:r><m:e><m:r><m:t>y</m:t></m:r></m:e><m:e><m:r><m:t>c</m:t></m:r></m:e><m:e><m:r><m:t>d</m:t></m:r></m:e></m:r></m:d></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert!(
            result.contains("\\begin{cases}")
                && result.contains("x & a & b")
                && result.contains("y & c & d"),
            "cases row or extra column boundaries were lost: {}",
            result
        );
    }
}

/// Parse OMML XML directly into a FormulaLayout (Math IR).
///
/// This bypasses the LaTeX intermediate format, providing direct OMML -> FormulaLayout
/// conversion for higher-fidelity round-trips.
pub fn parse_omml_to_layout(xml: &str) -> Result<latexsnipper_ast::FormulaLayout, String> {
    let math_xml = extract_o_math(xml).unwrap_or_else(|| xml.to_string());
    let cleaned = strip_xml_declaration(&math_xml);
    let root = parse_omml_node_to_layout(&cleaned)?;
    let symbol_count = count_symbols(&root);
    Ok(latexsnipper_ast::FormulaLayout {
        root,
        symbol_count,
        semantic_annotations: Vec::new(),
    })
}

fn parse_omml_node_to_layout(xml: &str) -> Result<latexsnipper_ast::FormulaNode, String> {
    let mut reader = Reader::from_str(xml);
    reader.config_mut().trim_text(false);
    let mut buf = Vec::new();
    let mut stack: Vec<(String, Vec<latexsnipper_ast::FormulaNode>)> = Vec::new();
    let mut current_text = String::new();

    loop {
        match reader.read_event_into(&mut buf) {
            Ok(Event::Start(e)) => {
                let tag = local(e.name().as_ref()).to_lowercase();
                stack.push((tag, Vec::new()));
                current_text.clear();
            }
            Ok(Event::Text(e)) => {
                let t = e.decode().map_err(|error| error.to_string())?;
                current_text.push_str(&t);
            }
            Ok(Event::GeneralRef(e)) => {
                current_text.push_str(&crate::xml_util::decode_xml_reference(&e)?);
            }
            Ok(Event::CData(e)) => {
                current_text.push_str(&e.decode().map_err(|error| error.to_string())?);
            }
            Ok(Event::Empty(_e)) => {
                let text = String::new();
                let node = make_symbol_from_text(&text);
                if let Some((_, ref mut children)) = stack.last_mut() {
                    children.push(node);
                }
            }
            Ok(Event::End(_)) => {
                if let Some((tag, children)) = stack.pop() {
                    let text = if tag == "t" {
                        current_text.as_str()
                    } else {
                        current_text.trim()
                    };
                    let node = build_omml_layout_node(&tag, &children, text);
                    if let Some((_, ref mut parent)) = stack.last_mut() {
                        parent.push(node);
                    } else {
                        return Ok(node);
                    }
                }
                current_text.clear();
            }
            Ok(Event::Eof) => break,
            Ok(Event::Comment(_))
            | Ok(Event::Decl(_))
            | Ok(Event::PI(_))
            | Ok(Event::DocType(_)) => continue,
            Err(e) => return Err(format!("XML parse error: {}", e)),
        }
    }

    stack
        .pop()
        .map(|(_, children)| {
            if children.len() == 1 {
                children.into_iter().next().unwrap()
            } else {
                latexsnipper_ast::FormulaNode::Group(children)
            }
        })
        .ok_or_else(|| "Empty OMML document".to_string())
}

fn build_omml_layout_node(
    tag: &str,
    children: &[latexsnipper_ast::FormulaNode],
    text: &str,
) -> latexsnipper_ast::FormulaNode {
    use latexsnipper_ast::{CommandInfo, FormulaNode, SymbolCategory, SymbolInfo};

    match tag {
        "r" => {
            if !text.is_empty() {
                FormulaNode::Symbol(SymbolInfo {
                    latex: crate::latex_utils::escape_text_symbols(text),
                    category: SymbolCategory::Letter,
                    rect: None,
                    confidence: 1.0,
                })
            } else if children.len() == 1 {
                children[0].clone()
            } else {
                FormulaNode::Group(children.to_vec())
            }
        }
        "f" => {
            let (num, den) = get_two_children(children);
            FormulaNode::Fraction {
                num: Box::new(num),
                den: Box::new(den),
            }
        }
        "rad" => {
            // `radPr` and a hidden/empty `deg` are represented by empty nodes
            // in this lightweight layout parser. Filter those wrappers so an
            // explicit degree is preserved and the radicand remains last.
            let meaningful: Vec<_> = children
                .iter()
                .filter(|child| !is_empty_layout_node(child))
                .cloned()
                .collect();
            let (index, radicand) = match meaningful.as_slice() {
                [] => (None, FormulaNode::Text(String::new())),
                [radicand] => (None, radicand.clone()),
                [index, rest @ ..] => (Some(Box::new(index.clone())), rest.last().unwrap().clone()),
            };
            FormulaNode::SquareRoot {
                index,
                content: Box::new(radicand),
            }
        }
        "nary" => {
            let chr = find_nary_chr(children);
            let (_lower, _upper, body) = get_three_children(children);
            FormulaNode::Command(CommandInfo {
                name: chr,
                args: vec![body],
            })
        }
        "sSup" => {
            let (base, exp) = get_two_children(children);
            FormulaNode::Superscript {
                base: Box::new(base),
                exp: Box::new(exp),
            }
        }
        "sSub" => {
            let (base, sub) = get_two_children(children);
            FormulaNode::Subscript {
                base: Box::new(base),
                sub: Box::new(sub),
            }
        }
        "oMath" | "oMathPara" => {
            if children.len() == 1 {
                children[0].clone()
            } else {
                FormulaNode::Group(children.to_vec())
            }
        }
        _ => {
            if children.is_empty() && !text.is_empty() {
                FormulaNode::Symbol(SymbolInfo {
                    latex: crate::latex_utils::escape_text_symbols(text),
                    category: SymbolCategory::Letter,
                    rect: None,
                    confidence: 1.0,
                })
            } else if children.len() == 1 {
                children[0].clone()
            } else {
                FormulaNode::Group(children.to_vec())
            }
        }
    }
}

fn get_two_children(
    children: &[latexsnipper_ast::FormulaNode],
) -> (latexsnipper_ast::FormulaNode, latexsnipper_ast::FormulaNode) {
    let empty = || latexsnipper_ast::FormulaNode::Text(String::new());
    match children.len() {
        0 => (empty(), empty()),
        1 => (children[0].clone(), empty()),
        _ => (children[0].clone(), children[1].clone()),
    }
}

fn get_three_children(
    children: &[latexsnipper_ast::FormulaNode],
) -> (
    latexsnipper_ast::FormulaNode,
    latexsnipper_ast::FormulaNode,
    latexsnipper_ast::FormulaNode,
) {
    let empty = || latexsnipper_ast::FormulaNode::Text(String::new());
    match children.len() {
        0 => (empty(), empty(), empty()),
        1 => (empty(), empty(), children[0].clone()),
        2 => (children[0].clone(), empty(), children[1].clone()),
        _ => (
            children[0].clone(),
            children[1].clone(),
            children[2].clone(),
        ),
    }
}

fn find_nary_chr(children: &[latexsnipper_ast::FormulaNode]) -> String {
    for child in children {
        if let latexsnipper_ast::FormulaNode::Group(group) = child {
            for node in group {
                if let latexsnipper_ast::FormulaNode::Symbol(s) = node {
                    if s.latex.len() == 1 && !s.latex.starts_with('\\') {
                        return s.latex.clone();
                    }
                }
            }
        }
    }
    "∑".to_string()
}

fn make_symbol_from_text(text: &str) -> latexsnipper_ast::FormulaNode {
    use latexsnipper_ast::{SymbolCategory, SymbolInfo};
    latexsnipper_ast::FormulaNode::Symbol(SymbolInfo {
        latex: crate::latex_utils::escape_text_symbols(text),
        category: SymbolCategory::Letter,
        rect: None,
        confidence: 1.0,
    })
}

fn is_empty_layout_node(node: &latexsnipper_ast::FormulaNode) -> bool {
    use latexsnipper_ast::FormulaNode;
    match node {
        FormulaNode::Symbol(symbol) => symbol.latex.is_empty(),
        FormulaNode::Text(text) => text.is_empty(),
        FormulaNode::Group(children) => children.iter().all(is_empty_layout_node),
        _ => false,
    }
}

fn count_symbols(node: &latexsnipper_ast::FormulaNode) -> usize {
    use latexsnipper_ast::FormulaNode;
    match node {
        FormulaNode::Symbol(_) => 1,
        FormulaNode::Command(c) => c
            .args
            .iter()
            .map(count_symbols)
            .sum::<usize>()
            .saturating_add(1),
        FormulaNode::Group(children) => children.iter().map(count_symbols).sum(),
        FormulaNode::Environment(env) => env.content.iter().flatten().map(count_symbols).sum(),
        FormulaNode::Superscript { base, exp } => count_symbols(base) + count_symbols(exp),
        FormulaNode::Subscript { base, sub } => count_symbols(base) + count_symbols(sub),
        FormulaNode::Fraction { num, den } => count_symbols(num) + count_symbols(den),
        FormulaNode::SquareRoot { index, content } => {
            index.as_deref().map(count_symbols).unwrap_or_default() + count_symbols(content)
        }
        FormulaNode::Text(t) => t.chars().count(),
        // Custom glyphs count as one symbol.
        FormulaNode::CustomGlyph(_) => 1,
    }
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fraction() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:f><m:fPr/><m:num><m:r><m:t>a</m:t></m:r></m:num><m:den><m:r><m:t>b</m:t></m:r></m:den></m:f></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert_eq!(result, "\\frac{a}{b}");
    }

    #[test]
    fn superscript() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:sSup><m:e><m:r><m:t>x</m:t></m:r></m:e><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSup></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert_eq!(result, "{x}^{2}");
    }

    #[test]
    fn subscript() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:sSub><m:e><m:r><m:t>x</m:t></m:r></m:e><m:sub><m:r><m:t>i</m:t></m:r></m:sub></m:sSub></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert_eq!(result, "{x}_{i}");
    }

    #[test]
    fn sqrt() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/><m:e><m:r><m:t>x</m:t></m:r></m:e></m:rad></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert_eq!(result, "\\sqrt{x}");
    }

    #[test]
    fn sqrt_with_degree() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:rad><m:radPr/><m:deg><m:r><m:t>3</m:t></m:r></m:deg><m:e><m:r><m:t>x</m:t></m:r></m:e></m:rad></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert_eq!(result, "\\sqrt[3]{x}");
    }

    #[test]
    fn layout_preserves_square_root_degree() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:rad><m:radPr/><m:deg><m:r><m:t>3</m:t></m:r></m:deg><m:e><m:r><m:t>x</m:t></m:r></m:e></m:rad></m:oMath>"#;
        let layout = parse_omml_to_layout(xml).unwrap();

        assert_eq!(layout.canonical_latex(), "\\sqrt[3]{x}");
        assert_eq!(layout.symbol_count, 2);
    }

    #[test]
    fn emc2() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:r><m:t>E</m:t></m:r><m:r><m:t>=</m:t></m:r><m:r><m:t>m</m:t></m:r><m:r><m:t>c</m:t></m:r><m:sSup><m:e><m:r><m:t></m:t></m:r></m:e><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSup></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert!(result.contains("E"));
        assert!(result.contains("="));
        assert!(result.contains("m"));
        assert!(result.contains("c"));
    }

    #[test]
    fn from_word_doc() {
        let xml = r#"<?xml version="1.0" standalone="yes"?>
<?mso-application progid="Word.Document"?>
<w:wordDocument xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">
<m:oMathPara><m:oMath><m:r><m:t>E</m:t></m:r><m:r><m:t>=</m:t></m:r><m:r><m:t>m</m:t></m:r><m:r><m:t>c</m:t></m:r><m:sSup><m:e><m:r><m:t></m:t></m:r></m:e><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSup></m:oMath></m:oMathPara>
</w:wordDocument>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert!(result.contains("E"));
        assert!(result.contains("="));
        assert!(result.contains("m"));
        assert!(result.contains("c"));
    }

    #[test]
    fn sum() {
        let xml = r#"<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:nary><m:naryPr><m:chr m:val="∑"/></m:naryPr><m:sub><m:r><m:t>i=1</m:t></m:r></m:sub><m:sup><m:r><m:t>n</m:t></m:r></m:sup><m:e><m:r><m:t>x</m:t></m:r></m:e></m:nary></m:oMath>"#;
        let result = parse_omml_to_latex(xml).unwrap();
        assert!(result.contains("\\sum"));
    }
}
