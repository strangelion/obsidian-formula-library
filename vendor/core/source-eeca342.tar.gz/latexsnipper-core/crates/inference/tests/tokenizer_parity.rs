//! Tokenizer parity tests: Rust tokenizers crate vs Python tokenizers.Tokenizer.
//!
//! Golden data can be regenerated directly from the packaged tokenizer:
//!   python -c "
//!   from tokenizers import Tokenizer
//!   import json
//!   tok = Tokenizer.from_file('tokenizer.json')
//!   ...
//!   "

use serde::Deserialize;

#[derive(Debug, Deserialize)]
struct GoldenCase {
    #[allow(dead_code)]
    desc: String,
    ids: Vec<u32>,
    decoded_skip: String,
    #[allow(dead_code)]
    decoded_raw: String,
}

fn load_golden() -> Vec<GoldenCase> {
    let path = concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../tests/fixtures/tokenizer_golden.json"
    );
    let data = std::fs::read_to_string(path).expect("Failed to read tokenizer_golden.json");
    serde_json::from_str(&data).expect("Failed to parse tokenizer_golden.json")
}

fn tokenizer_path() -> String {
    concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../tests/fixtures/pp_formulanet_tokenizer.json"
    )
    .to_string()
}

#[test]
fn tokenizer_rust_python_golden_parity() {
    let tokenizer =
        tokenizers::Tokenizer::from_file(tokenizer_path()).expect("Failed to load tokenizer.json");

    let cases = load_golden();
    assert!(!cases.is_empty(), "Golden file must contain test cases");

    for case in &cases {
        let actual = tokenizer
            .decode(&case.ids, true)
            .unwrap_or_else(|e| panic!("Decode failed for '{}': {}", case.desc, e));
        assert_eq!(
            actual, case.decoded_skip,
            "Mismatch for '{}':\n  expected: {:?}\n  actual:   {:?}",
            case.desc, case.decoded_skip, actual
        );
    }
}

#[test]
fn tokenizer_raw_decode_includes_special_tokens() {
    let tokenizer =
        tokenizers::Tokenizer::from_file(tokenizer_path()).expect("Failed to load tokenizer.json");

    // <s> = 0, <pad> = 1, </s> = 2
    let decoded = tokenizer.decode(&[0, 1, 2], false).unwrap();
    assert_eq!(decoded, "<s><pad></s>");

    // With skip_special, they should disappear
    let skipped = tokenizer.decode(&[0, 1, 2], true).unwrap();
    assert_eq!(skipped, "");
}

#[test]
fn tokenizer_bytelevel_roundtrip() {
    let mut tokenizer =
        tokenizers::Tokenizer::from_file(tokenizer_path()).expect("Failed to load tokenizer.json");
    tokenizer.with_padding(None);
    tokenizer.with_truncation(None).ok();

    let inputs = [r"\frac{1}{2}", r"\alpha+\beta", r"E=mc^2", "hello world"];
    for input in &inputs {
        let encoding = tokenizer.encode(*input, false).unwrap();
        let decoded = tokenizer.decode(encoding.get_ids(), true).unwrap();
        assert_eq!(decoded, *input, "ByteLevel roundtrip failed for: {}", input);
    }
}
