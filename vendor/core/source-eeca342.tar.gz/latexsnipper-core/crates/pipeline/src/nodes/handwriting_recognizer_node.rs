use async_trait::async_trait;
use latexsnipper_ast::*;
use latexsnipper_foundation::{Result, SnipperError};
use latexsnipper_image::operations;
use latexsnipper_inference::{
    load_tokenizer_from_str, postprocess_handwriting, recognize_formula,
    recognize_formula_with_tokenizer, RecognitionParams,
};
use latexsnipper_runtime::ModelId;

use crate::context::PipelineContext;
use crate::node::PipelineNode;
use crate::nodes::utils::{
    get_backend, get_or_create_session, model_artifact_path, resolve_model_handle, resolve_variant,
};

/// Recognizes content in handwriting-detected regions.
///
/// Uses TrOCR (optimized for handwriting) to recognize text and formulas
/// in regions detected as handwriting.
pub struct HandwritingRecognizerNode {
    name: String,
}

impl HandwritingRecognizerNode {
    pub fn new() -> Self {
        Self {
            name: "recognize_handwriting".into(),
        }
    }
}

impl Default for HandwritingRecognizerNode {
    fn default() -> Self {
        Self::new()
    }
}

#[async_trait]
impl PipelineNode for HandwritingRecognizerNode {
    fn name(&self) -> &str {
        &self.name
    }

    async fn process(&self, ctx: &mut PipelineContext) -> Result<()> {
        let models = match &ctx.models_dir {
            Some(d) => d.clone(),
            None => return Ok(()),
        };

        self.recognize_handwriting(ctx, &models).await
    }
}

impl HandwritingRecognizerNode {
    async fn recognize_handwriting(
        &self,
        ctx: &mut PipelineContext,
        models: &std::path::Path,
    ) -> Result<()> {
        let detections = ctx.artifacts.handwriting_detections.clone();
        if detections.is_empty() {
            return Ok(());
        }

        let (rec_config, _primary_path, rec_dir) = match resolve_variant(ctx, models, "formula-rec")
        {
            Ok(r) => r,
            Err(_) => {
                ctx.diagnostic_warn(
                    "recognize_handwriting",
                    "TrOCR model config not found for handwriting recognition",
                );
                return Ok(());
            }
        };

        let model_files = rec_config
            .pipeline
            .as_ref()
            .and_then(|pipeline| pipeline.model_files.as_ref());
        let enc_path = model_artifact_path(
            ctx,
            &rec_dir,
            model_files.and_then(|files| files.encoder.as_deref()),
            rec_config.pipeline_encoder_path(&rec_dir),
        )
        .ok_or_else(|| SnipperError::Model("Encoder not found".into()))?;
        let dec_path = model_artifact_path(
            ctx,
            &rec_dir,
            model_files.and_then(|files| files.decoder.as_deref()),
            rec_config.pipeline_decoder_path(&rec_dir),
        )
        .ok_or_else(|| SnipperError::Model("Decoder not found".into()))?;
        let tok_path = model_artifact_path(
            ctx,
            &rec_dir,
            model_files.and_then(|files| files.tokenizer.as_deref()),
            rec_config.pipeline_tokenizer_path(&rec_dir),
        )
        .ok_or_else(|| SnipperError::Model("Tokenizer not found".into()))?;
        let tokenizer_name = tok_path
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or("tokenizer.json");
        let tokenizer = ctx
            .model_resolver
            .as_ref()
            .and_then(|resolver| {
                let variant = ctx.model_variants.get("formula-rec")?;
                resolver
                    .read_text_artifact(&ModelId::new("formula-rec", variant), tokenizer_name)
                    .ok()
            })
            .and_then(|text| load_tokenizer_from_str(&text).ok());

        let backend = get_backend(ctx)?;
        let enc_handle = resolve_model_handle(ctx, "formula-rec/encoder", enc_path)?;
        let dec_handle = resolve_model_handle(ctx, "formula-rec/decoder", dec_path)?;

        let enc_session = get_or_create_session(ctx, "handwriting_encoder", &backend, &enc_handle)?;
        let dec_session = get_or_create_session(ctx, "handwriting_decoder", &backend, &dec_handle)?;

        let mut params = RecognitionParams::from_config(&rec_config);
        params.greedy = true;
        #[cfg(target_arch = "wasm32")]
        {
            params.max_tokens = params.max_tokens.min(32);
        }
        #[cfg(not(target_arch = "wasm32"))]
        {
            params.max_tokens = params.max_tokens.min(256);
        }

        let mut blocks = Vec::new();

        for det in &detections {
            let x = det.rect.x as u32;
            let y = det.rect.y as u32;
            let w = det.rect.width as u32;
            let h = det.rect.height as u32;

            if let Some(ref image) = ctx.image {
                if w >= 4 && h >= 4 {
                    let cropped =
                        operations::crop(image, Rect::new(x as f32, y as f32, w as f32, h as f32));

                    let recognized = if let Some(tokenizer) = &tokenizer {
                        recognize_formula_with_tokenizer(
                            &cropped,
                            &*enc_session,
                            &*dec_session,
                            tokenizer,
                            &params,
                        )
                    } else {
                        recognize_formula(
                            &cropped,
                            &*enc_session,
                            &*dec_session,
                            &tok_path,
                            &params,
                        )
                    };
                    match recognized {
                        Ok(result) => {
                            let processed_text = postprocess_handwriting(&result.text);

                            if !processed_text.is_empty() {
                                if looks_like_formula(&processed_text) {
                                    let mut f = Formula::latex(&processed_text);
                                    f.confidence = result.confidence;
                                    f.recognition_provenance =
                                        result.provenance.clone().map(Box::new);
                                    f.recognition_evidence =
                                        result.postprocess.clone().map(Box::new);
                                    blocks.push(Block::Formula(FormulaBlock {
                                        formula: f,
                                        label: None,
                                        number: None,
                                        environment: None,
                                        geometry: Some(Rect::new(
                                            x as f32, y as f32, w as f32, h as f32,
                                        )),
                                        source: Some(SourceInfo::new().with_page(ctx.current_page)),
                                    }));
                                } else {
                                    blocks.push(Block::Handwriting(HandwritingBlock {
                                        inlines: vec![Inline::Text(TextRun::new(&processed_text))],
                                        confidence: result.confidence,
                                        geometry: Some(Rect::new(
                                            x as f32, y as f32, w as f32, h as f32,
                                        )),
                                        source: Some(SourceInfo::new().with_page(ctx.current_page)),
                                    }));
                                }
                            }
                        }
                        Err(e) => log::warn!("Handwriting rec failed: {}", e),
                    }
                }
            }
        }

        ctx.artifacts.handwriting_blocks = blocks;
        log::info!(
            "Recognized {} handwriting blocks",
            ctx.artifacts.handwriting_blocks.len()
        );
        Ok(())
    }
}

/// Check if text looks like a mathematical formula.
fn looks_like_formula(text: &str) -> bool {
    if text.contains("\\frac") || text.contains("\\sqrt") {
        return true;
    }

    let strong_indicators = [
        "\\", // Backslash commands
        "^",  // Superscript
        "_",  // Subscript
        "=",  // Equations
    ];

    let strong_count = strong_indicators
        .iter()
        .filter(|&&ind| text.contains(ind))
        .count();

    if strong_count >= 2 {
        return true;
    }

    text.len() >= 3 && !text.contains(' ') && (text.contains('+') || text.contains('='))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_looks_like_formula() {
        assert!(looks_like_formula("E = mc^2"));
        assert!(looks_like_formula("\\frac{a}{b}"));
        assert!(looks_like_formula("x^2 + y^2 = z^2"));
        assert!(!looks_like_formula("Hello World"));
        assert!(!looks_like_formula("This is text"));
        assert!(!looks_like_formula("This is a test (with explanation)"));
        assert!(looks_like_formula("3x+2=5"));
    }
}
