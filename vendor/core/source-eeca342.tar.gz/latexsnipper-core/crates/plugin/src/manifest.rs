use latexsnipper_ast::FormatCapability;
use serde::{Deserialize, Serialize};

pub const PLUGIN_API_VERSION: u32 = 1;
pub const PLUGIN_ABI_VERSION: u32 = 1;
const LEGACY_CORE_CONTRACT_VERSION: semver::Version = semver::Version::new(2, 0, 0);

pub(crate) fn legacy_core_requirement_matches(
    requirement: &semver::VersionReq,
    current: &semver::Version,
) -> bool {
    requirement.matches(current) || requirement.matches(&LEGACY_CORE_CONTRACT_VERSION)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PluginHook {
    BeforeImport,
    AfterImport,
    BeforeRecognition,
    AfterRecognition,
    BeforeConversion,
    AfterConversion,
    BeforeExport,
    AfterExport,
    Validate,
    RegisterImporter,
    RegisterExporter,
    RegisterRuntime,
    RegisterModelAdapter,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PluginClass {
    BuiltInRust,
    IsolatedProcess,
    NativeAbi,
    WasiComponent,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PluginPermissions {
    /// Legacy read-only filesystem grants. New manifests should use
    /// `filesystemReadPaths` and `filesystemWritePaths` explicitly.
    #[serde(default)]
    pub filesystem_paths: Vec<String>,
    #[serde(default)]
    pub filesystem_read_paths: Vec<String>,
    #[serde(default)]
    pub filesystem_write_paths: Vec<String>,
    #[serde(default)]
    pub network_hosts: Vec<String>,
    #[serde(default)]
    pub environment_variables: Vec<String>,
    #[serde(default)]
    pub model_access: Vec<String>,
    #[serde(default)]
    pub temporary_directory: bool,
    #[serde(default)]
    pub capability_registration: bool,
    #[serde(default)]
    pub importer_registration: bool,
    #[serde(default)]
    pub exporter_registration: bool,
    #[serde(default)]
    pub runtime_registration: bool,
    pub memory_limit_bytes: Option<u64>,
    pub output_limit_bytes: Option<u64>,
    pub timeout_millis: Option<u64>,
    #[serde(default = "default_max_concurrent_executions")]
    pub max_concurrent_executions: usize,
}

fn default_max_concurrent_executions() -> usize {
    1
}

impl Default for PluginPermissions {
    fn default() -> Self {
        Self {
            filesystem_paths: Vec::new(),
            filesystem_read_paths: Vec::new(),
            filesystem_write_paths: Vec::new(),
            network_hosts: Vec::new(),
            environment_variables: Vec::new(),
            model_access: Vec::new(),
            temporary_directory: false,
            capability_registration: false,
            importer_registration: false,
            exporter_registration: false,
            runtime_registration: false,
            memory_limit_bytes: None,
            output_limit_bytes: None,
            timeout_millis: None,
            max_concurrent_executions: 1,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PluginDependency {
    pub id: String,
    pub version_requirement: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PluginManifest {
    pub id: String,
    pub name: String,
    pub version: String,
    pub plugin_api_version: u32,
    /// Stable external ABI or IPC protocol version. Built-in plugins leave it unset.
    pub abi_version: Option<u32>,
    pub core_version_requirement: String,
    #[serde(default)]
    pub capabilities: Vec<String>,
    /// Typed importer/exporter capabilities contributed while this plugin is enabled.
    #[serde(default)]
    pub format_capabilities: Vec<FormatCapability>,
    #[serde(default)]
    pub hooks: Vec<PluginHook>,
    #[serde(default)]
    pub priority: i32,
    #[serde(default)]
    pub dependencies: Vec<PluginDependency>,
    #[serde(default)]
    pub before: Vec<String>,
    #[serde(default)]
    pub after: Vec<String>,
    #[serde(default)]
    pub permissions: PluginPermissions,
    #[serde(default)]
    pub platforms: Vec<String>,
    #[serde(default)]
    pub architectures: Vec<String>,
    pub license: Option<String>,
    pub entrypoint: Option<String>,
    pub checksum_sha256: Option<String>,
    pub signature: Option<String>,
    pub configuration_schema: Option<serde_json::Value>,
    pub class: PluginClass,
}

impl PluginManifest {
    pub fn built_in(id: impl Into<String>, version: impl Into<String>) -> Self {
        let id = id.into();
        Self {
            name: id.clone(),
            id,
            version: version.into(),
            plugin_api_version: PLUGIN_API_VERSION,
            abi_version: None,
            core_version_requirement: format!("^{}", env!("CARGO_PKG_VERSION")),
            capabilities: Vec::new(),
            format_capabilities: Vec::new(),
            hooks: Vec::new(),
            priority: 0,
            dependencies: Vec::new(),
            before: Vec::new(),
            after: Vec::new(),
            permissions: PluginPermissions::default(),
            platforms: Vec::new(),
            architectures: Vec::new(),
            license: None,
            entrypoint: None,
            checksum_sha256: None,
            signature: None,
            configuration_schema: None,
            class: PluginClass::BuiltInRust,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn legacy_api_accepts_explicit_v2_contract_during_v3_alpha() {
        let requirement = semver::VersionReq::parse("^2.0.0").unwrap();
        let current = semver::Version::parse("3.0.0").unwrap();
        assert!(legacy_core_requirement_matches(&requirement, &current));

        let unsupported = semver::VersionReq::parse("^1.0.0").unwrap();
        assert!(!legacy_core_requirement_matches(&unsupported, &current));
    }
}
