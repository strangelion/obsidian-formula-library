use clap::{CommandFactory, FromArgMatches, Parser, Subcommand, ValueEnum};
use clap_complete::Shell;
use latexsnipper_ast::{
    CapabilityMatrix, Diagnostic, DiagnosticLevel, Document, ExportArtifact, ExportFormat,
    FidelityLevel, FormatCapability, GeneratedContent, ImportOptions, LossKind,
};
use latexsnipper_conversion::{
    DocumentConverter, DocumentExportService, DocumentImporter, OutputFormat,
};
use latexsnipper_engine::application::{
    RecognitionOptions as ApplicationRecognitionOptions, RecognitionProfile,
    RecognitionRequest as ApplicationRecognitionRequest, RecognitionSession,
};
use latexsnipper_engine::{sdk::Snipper, DocumentParseMode, EngineConfig, RecognizeMode};
use latexsnipper_export::VisualFormat;
#[cfg(any(target_os = "windows", target_os = "linux", target_os = "macos"))]
use latexsnipper_runtime::{
    providers::onnx_factory::OnnxRuntimeFactory, RuntimeKind, RuntimeRegistry,
};
use latexsnipper_syntax::latex::{LatexParser, LatexRenderer};
use latexsnipper_syntax::{Parser as _, Renderer as _};
use std::io::{self, Read, Write};

mod fs_util;
mod migration;
mod model_transport;

use migration::{MigrationCommand, MigrationRunStatus};

#[derive(Debug, Clone, Copy, ValueEnum)]
enum DiagnosticsFormat {
    Text,
    Json,
    Sarif,
}

#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum CliExitCode {
    GenericFailure = 1,
    InvalidArguments = 2,
    InvalidInput = 3,
    MissingModel = 4,
    RecognitionFailure = 5,
    UnsupportedConversion = 6,
    OutputValidationFailure = 7,
    StrictDiagnosticFailure = 8,
    PluginFailure = 9,
    PartialBatchFailure = 10,
    MigrationRequiresManualAction = 11,
}

impl CliExitCode {
    const fn contract() -> [(Self, &'static str); 11] {
        [
            (Self::GenericFailure, "generic failure"),
            (Self::InvalidArguments, "invalid arguments"),
            (Self::InvalidInput, "invalid or unsupported input"),
            (Self::MissingModel, "missing or invalid model"),
            (Self::RecognitionFailure, "recognition failure"),
            (Self::UnsupportedConversion, "unsupported conversion"),
            (Self::OutputValidationFailure, "output validation failure"),
            (Self::StrictDiagnosticFailure, "strict diagnostic failure"),
            (Self::PluginFailure, "plugin failure"),
            (Self::PartialBatchFailure, "partial batch failure"),
            (
                Self::MigrationRequiresManualAction,
                "migration requires manual action",
            ),
        ]
    }
}

#[derive(Parser)]
#[command(name = "snipper")]
#[command(version = env!("CARGO_PKG_VERSION"))]
#[command(about = "LaTeXSnipper Core -- Image to LaTeX/Markdown/Typst converter")]
#[command(long_about = "LaTeXSnipper Core CLI\n\n\
    A command-line tool for recognizing mathematical formulas in images\n\
    and converting them to various formats (LaTeX, Markdown, Typst, HTML, MathML, OMML).\n\n\
    USAGE:\n    \
    snipper recognize -i image.png -f latex\n    \
    snipper recognize -i image.png -f markdown -o output.md\n    \
    snipper parse -l '\\frac{a}{b}'\n    \
    snipper render -l '\\frac{a}{b}'\n\n\
    For more information, run 'snipper <command> --help'.")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Import a supported document and emit its unified JSON AST
    Import {
        /// Input document path
        input: String,
        /// Output JSON path; stdout when omitted
        #[arg(short = 'o', long)]
        output: Option<String>,
    },

    /// Convert a supported document through the unified AST
    Convert {
        /// Input paths, glob patterns, or directories
        #[arg(required = true)]
        input: Vec<String>,
        /// Target format
        #[arg(long)]
        to: String,
        /// Output path; required for binary targets
        #[arg(short = 'o', long)]
        output: Option<String>,
        /// Permit binary bytes on stdout when output is '-'
        #[arg(long)]
        force_binary_stdout: bool,
        /// Replace an existing output file
        #[arg(long, conflicts_with = "no_clobber")]
        force: bool,
        /// Refuse to replace an existing output file
        #[arg(long)]
        no_clobber: bool,
        /// Write through a same-directory temporary file and rename on success
        #[arg(long, default_value_t = true)]
        atomic: bool,
        /// Diagnostic rendering format
        #[arg(long, value_enum, default_value_t = DiagnosticsFormat::Text)]
        diagnostics: DiagnosticsFormat,
        /// Fail when any non-info diagnostic is emitted
        #[arg(long)]
        strict: bool,
        /// Fail when any warning diagnostic is emitted
        #[arg(long)]
        fail_on_warning: bool,
        /// Inclusive 1-based page range (START-END)
        #[arg(long, value_name = "START-END")]
        page_range: Option<String>,
        /// Reject importer fidelity loss and preserve unknown Office package parts
        #[arg(long)]
        strict_preservation: bool,
        /// Suppress non-data status output
        #[arg(long, conflicts_with = "verbose")]
        quiet: bool,
        /// Emit additional operational details to stderr
        #[arg(long)]
        verbose: bool,
        /// Convert directory contents recursively
        #[arg(long)]
        recursive: bool,
        /// Output directory for multiple inputs; relative paths are preserved
        #[arg(long)]
        output_dir: Option<String>,
        /// Maximum number of files converted concurrently
        #[arg(long, default_value_t = 1)]
        jobs: usize,
        /// Continue processing after a per-file failure
        #[arg(long)]
        continue_on_error: bool,
        /// Write a machine-readable batch report
        #[arg(long)]
        report: Option<String>,
    },

    /// Export a document to SVG, PDF, PNG, or plain text
    Export {
        /// Input document path
        input: String,
        /// Visual target format
        #[arg(long)]
        to: String,
        /// Output path
        #[arg(short = 'o', long)]
        output: String,
    },

    /// Inspect detected format and imported AST statistics
    Inspect {
        /// Input document path
        input: String,
        /// Emit machine-readable JSON
        #[arg(long)]
        json: bool,
    },

    /// Validate that a document is structurally importable
    Validate {
        /// Input document path
        input: String,
    },

    /// Recognize formulas in an image and export to a format
    #[command(
        long_about = "Recognize mathematical formulas and text in an image.\n\n\
        The executable capability and mode registries are appended to this help at runtime."
    )]
    Recognize {
        /// Input image path (png, jpg, pdf, bmp, tiff)
        #[arg(short = 'i', long)]
        input: String,

        /// Output format (default: latex)
        #[arg(short = 'f', long, default_value = "latex")]
        format: String,

        /// Output file path. If omitted, prints to stdout.
        #[arg(short = 'o', long)]
        output: Option<String>,

        /// Document parsing mode.
        #[arg(long, default_value = "specialized")]
        parse_mode: String,

        /// Recognition pipeline mode.
        #[arg(long, default_value = "formula")]
        recognize_mode: String,
    },

    /// Shorthand for 'recognize'
    Rec {
        /// Input image path
        #[arg(short = 'i', long)]
        input: String,

        /// Output format (default: latex)
        #[arg(short = 'f', long, default_value = "latex")]
        format: String,

        /// Output file path. If omitted, prints to stdout.
        #[arg(short = 'o', long)]
        output: Option<String>,

        /// Document parsing mode.
        #[arg(long, default_value = "specialized")]
        parse_mode: String,

        /// Recognition pipeline mode.
        #[arg(long, default_value = "formula")]
        recognize_mode: String,
    },

    /// Parse a LaTeX string to AST (JSON)
    #[command(long_about = "Parse a LaTeX string into an Abstract Syntax Tree.\n\n\
        Outputs the full AST as formatted JSON, useful for debugging\n\
        and understanding how LaTeXSnipper parses formulas.\n\n\
        EXAMPLES:\n    \
        snipper parse -l '\\frac{a}{b}'\n    \
        snipper parse -l 'E = mc^2'")]
    Parse {
        /// LaTeX string to parse
        #[arg(short = 'l', long)]
        latex: String,
    },

    /// Render or convert a single LaTeX formula
    #[command(
        long_about = "Render a LaTeX string by parsing it to AST and back, or convert the\n\
        formula directly to a semantic target such as MathML or OMML.\n\n\
        Without --to this remains a LaTeX roundtrip test. The output should be\n\
        semantically equivalent to the input, though formatting may differ.\n\n\
        EXAMPLES:\n    \
        snipper render -l '\\frac{a}{b}'\n    \
        snipper render -l 'x^2 + y^2 = r^2'\n    \
        snipper render -l '\\frac{a}{b}' --to omml -o formula.xml"
    )]
    Render {
        /// LaTeX string to render
        #[arg(short = 'l', long)]
        latex: String,
        /// Semantic output format (for example: latex, mathml, omml, or typst)
        #[arg(long)]
        to: Option<String>,
        /// Output path; stdout when omitted
        #[arg(short = 'o', long)]
        output: Option<String>,
    },

    /// Show version, build info, and system details
    #[command(long_about = "Show detailed version and build information.\n\n\
        Includes version number, build target, and runtime mode.\n\
        Use '-v' or '--version' as a flag on the root command for brief output.")]
    Version,

    /// Diagnose runtime, model, output, and capability readiness
    Doctor,

    /// Show conversion capabilities matrix
    #[command(long_about = "Display the conversion/export capabilities matrix.\n\n\
        Lists all supported input/output formats with fidelity levels,\n\
        supported features (formulas, tables, images, SVG, styles, layout),\n\
        and known information loss during conversion.\n\n\
        EXAMPLES:\n    \
        snipper capabilities\n    \
        snipper capabilities --format markdown\n    \
        snipper capabilities --input ast --output markdown\n    \
        snipper capabilities --input ast")]
    Capabilities {
        /// Output format for the matrix: "table" (default), "markdown", or "json"
        #[arg(short = 'f', long, default_value = "table")]
        format: String,

        /// Filter by input format (e.g., "ast", "markdown", "latex")
        #[arg(long)]
        input: Option<String>,

        /// Filter by output format (e.g., "markdown", "html", "svg")
        #[arg(long)]
        output: Option<String>,

        /// JSON API envelope version; only valid with --format json
        #[arg(long, value_parser = clap::value_parser!(u32).range(2..=3))]
        api_version: Option<u32>,
    },

    /// Inspect or migrate serialized v2 contracts without overwriting the source
    #[command(subcommand)]
    Migrate(MigrationCommand),

    /// Play the LaTeX Math Rendering Challenge (minigame)
    #[command(long_about = "Launch the LaTeX Math Rendering Challenge.\n\n\
        A terminal mini-game where you see ASCII math art and must type\n\
        the correct LaTeX code. Features 3 difficulty levels, streak\n\
        bonuses, speed bonuses, and a hint system.\n\n\
        GAME COMMANDS:\n    \
        quit   - exit the game\n    \
        hint   - reveal next character (-50 pts)\n    \
        skip   - skip current question (-100 pts)\n    \
        answer - reveal the answer (0 pts)\n\n\
        SCORING:\n    \
        Base: 100 pts per correct answer\n    \
        Streak: +50 pts per consecutive correct answer\n    \
        Speed: up to +50 pts for fast answers\n    \
        Hint penalty: -50 pts per hint\n    \
        Skip penalty: -100 pts")]
    Play,

    /// Manage models (download, list, verify)
    #[command(subcommand)]
    Models(ModelsCommand),

    /// Verify and manage explicitly installed plugin packages
    Plugin {
        /// Plugin store directory
        #[arg(long, default_value = ".snipper/plugins", global = true)]
        store_dir: String,

        #[command(subcommand)]
        command: PluginCommand,
    },

    /// Manage processing jobs
    #[command(subcommand)]
    Job(JobCommand),

    /// Generate shell completion definitions
    Completions {
        /// Target shell
        #[arg(value_enum)]
        shell: Shell,
    },

    /// Generate a roff man page
    Manpages {
        /// Directory that receives snipper.1
        #[arg(long, default_value = ".")]
        output_dir: String,
    },
}

#[derive(Subcommand)]
enum JobCommand {
    /// Create and run a recognition job
    #[command(long_about = "Create and run a recognition job.\n\n\
        Processes an input image through the full pipeline and\n\
        produces structured output with artifacts, diagnostics, and reports.\n\n\
        EXAMPLES:\n    \
        snipper job run -i scan.png -f latex\n    \
        snipper job run -i page.png -f markdown -o result.md\n    \
        snipper job run -i photo.jpg -f html --mode mixed")]
    Run {
        /// Input image path
        #[arg(short = 'i', long)]
        input: String,

        /// Output format (default: latex)
        #[arg(short = 'f', long, default_value = "latex")]
        format: String,

        /// Output file path (optional)
        #[arg(short = 'o', long)]
        output: Option<String>,

        /// Recognition pipeline mode
        #[arg(long, default_value = "formula")]
        mode: String,
    },

    /// Inspect a completed job's details
    #[command(long_about = "Inspect job details including status,\n\
        stage reports, and diagnostics.\n\n\
        EXAMPLES:\n    \
        snipper job inspect <job-id>")]
    Inspect {
        /// Job ID to inspect
        job_id: String,
    },
}

#[derive(Subcommand)]
enum ModelsCommand {
    /// Build a transport-v1 .lsmodel from one verified legacy model directory
    Package {
        /// Directory containing config.json and model artifacts
        #[arg(long)]
        source: std::path::PathBuf,
        /// Output .lsmodel path (must not already exist)
        #[arg(long)]
        output: std::path::PathBuf,
        /// Model catalog containing adapter and runtimeVariants metadata
        #[arg(long, default_value = "scripts/model-manifest.template.json")]
        catalog: std::path::PathBuf,
        /// Catalog category, for example formula-rec
        #[arg(long)]
        category: String,
        /// Catalog variant id, for example trocr-deit
        #[arg(long)]
        variant: String,
        /// Version written to manifest.toml
        #[arg(long)]
        model_version: String,
    },

    /// Inspect and validate a transport-v1 .lsmodel without extracting it
    Inspect {
        /// Input .lsmodel archive
        archive: std::path::PathBuf,
        /// Emit the complete inspection as JSON
        #[arg(long)]
        json: bool,
    },

    /// Download models from release
    #[command(long_about = "Download model packages from GitHub releases.\n\n\
        Downloads and extracts model packages to the models directory.\n\
        By default, downloads all required models from the official manifest.\n\n\
        EXAMPLES:\n    \
        snipper models download\n    \
        snipper models download --category formula-det\n    \
        snipper models download --all")]
    Download {
        /// Model category to download (e.g., formula-det, text-rec)
        #[arg(short = 'c', long, conflicts_with = "all")]
        category: Option<String>,

        /// Download all models (not just required ones)
        #[arg(short = 'a', long)]
        all: bool,

        /// Custom manifest URL
        #[arg(long)]
        manifest_url: Option<String>,
    },

    /// List installed models
    #[command(long_about = "List all installed model packages.\n\n\
        Shows which models are installed and their variants.\n\n\
        EXAMPLES:\n    \
        snipper models list\n    \
        snipper models list --category formula-det")]
    List {
        /// Filter by category
        #[arg(short = 'c', long)]
        category: Option<String>,
    },

    /// Verify model file existence against manifest
    #[command(
        long_about = "Verify that all model files listed in the manifest exist.\n\n\
SHA-256 integrity is checked at download time. This command only confirms\n\
that expected files are present after extraction.\n\n\
Examples:\n    \
snipper models verify\n    \
snipper models verify --category formula-det"
    )]
    Verify {
        /// Filter by category
        #[arg(short = 'c', long)]
        category: Option<String>,
    },

    /// Remove installed model variants while preserving the manifest
    Purge {
        /// Limit removal to one model category
        #[arg(short = 'c', long)]
        category: Option<String>,

        /// Limit removal to one variant; requires --category
        #[arg(long, requires = "category")]
        variant: Option<String>,

        /// Confirm destructive removal
        #[arg(long)]
        yes: bool,
    },
}

#[derive(Subcommand)]
enum PluginCommand {
    /// Manage signed remote plugin registries
    Registry {
        #[command(subcommand)]
        command: PluginRegistryCommand,
    },
    /// List installed plugin manifests and activation state
    List,
    /// Search verified signed registry targets
    Search { query: Option<String> },
    /// Show one installed plugin manifest
    Info { id: String },
    /// Verify a local package without installing or executing it
    Verify { source: String },
    /// Install a local package or a verified registry plugin ID in disabled state
    Install { source: String },
    /// Update one verified remote plugin or all installed remote plugins
    Update {
        id: Option<String>,
        #[arg(long, conflicts_with = "id")]
        all: bool,
    },
    /// Activate the last-known-good verified remote version
    Rollback { id: String },
    /// Remove an installed package
    Uninstall { id: String },
    /// Mark an installed package enabled for a compatible host
    Enable { id: String },
    /// Mark an installed package disabled
    Disable { id: String },
    /// Mark a remote plugin revoked and disable it locally
    Revoke { id: String },
    /// Verify every installed package and report execution-host readiness
    Doctor,
}

#[derive(Subcommand)]
enum PluginRegistryCommand {
    /// List configured registry origins and trust state
    List,
    /// Add an HTTPS registry origin without trusting it
    Add { name: String, origin: String },
    /// Remove a configured registry
    Remove {
        name: String,
        #[arg(long)]
        yes: bool,
    },
    /// Trust an initial or rotated signed root metadata file
    Trust {
        name: String,
        root: String,
        #[arg(long)]
        yes: bool,
    },
    /// Refresh verified metadata, or validate the offline cache
    Refresh {
        name: Option<String>,
        #[arg(long)]
        offline: bool,
    },
}

fn resolve_format(format: &str) -> String {
    format.to_ascii_lowercase()
}

fn render_formula(latex: &str, target: Option<&str>) -> Result<String, String> {
    let Some(target) = target else {
        let parser = LatexParser;
        let renderer = LatexRenderer;
        let document = parser
            .parse(latex)
            .map_err(|error| format!("parse failed: {error}"))?;
        return renderer
            .render(&document)
            .map_err(|error| format!("LaTeX roundtrip failed: {error}"));
    };

    let resolved = resolve_format(target);
    let Some(CliTarget::Semantic(format)) = resolve_cli_target(&resolved) else {
        let hint = suggest_format(&resolved)
            .map(|suggestion| format!(" Did you mean '{suggestion}'?"))
            .unwrap_or_default();
        return Err(format!(
            "unsupported single-formula target '{target}'.{hint} Use a semantic format such as latex, mathml, omml, or typst."
        ));
    };
    DocumentConverter::convert_latex_string(latex, format).map_err(|error| error.to_string())
}

fn suggest_format(input: &str) -> Option<&'static str> {
    let lower = input.to_lowercase();
    latexsnipper_conversion::CapabilityRegistry::for_target(
        latexsnipper_conversion::CapabilityTarget::Native,
    )
    .into_iter()
    .filter(|entry| entry.available)
    .flat_map(|entry| {
        std::iter::once((entry.format, entry.format)).chain(
            entry
                .aliases
                .iter()
                .copied()
                .map(move |alias| (entry.format, alias)),
        )
    })
    .min_by_key(|(_, candidate)| levenshtein_distance(&lower, candidate))
    .filter(|(_, candidate)| {
        lower.contains(candidate) || levenshtein_distance(&lower, candidate) <= 3
    })
    .map(|(format, _)| format)
}

fn parse_document_parse_mode(input: &str) -> Option<DocumentParseMode> {
    DocumentParseMode::from_label(input)
}

fn parse_recognize_mode(input: &str) -> Option<RecognizeMode> {
    RecognizeMode::from_label(input)
}

fn recognize_document(
    input: &str,
    parse_mode: DocumentParseMode,
    recognize_mode: RecognizeMode,
) -> Result<Document, String> {
    // Preserve the existing PDF OCR path until Core has an in-process PDF
    // renderer. The application API intentionally never spawns child processes.
    if is_pdf_input(std::path::Path::new(input)) {
        return Snipper::from_file_with_config(
            input,
            EngineConfig::default().set_parse_mode(parse_mode),
            recognize_mode,
        )
        .map(|snipper| snipper.document().clone())
        .map_err(|error| error.to_string());
    }

    let mut session = RecognitionSession::builder()
        .parse_mode(parse_mode)
        .build()
        .map_err(format_application_error)?;
    let request = ApplicationRecognitionRequest::from_path(input)
        .with_profile(RecognitionProfile::from(recognize_mode))
        .with_options(ApplicationRecognitionOptions {
            parse_mode: Some(parse_mode),
            ..ApplicationRecognitionOptions::default()
        });
    session
        .recognize(request)
        .map(|result| result.document)
        .map_err(format_application_error)
}

fn format_application_error(error: latexsnipper_engine::application::ApplicationError) -> String {
    match error.detail {
        Some(detail) => format!("{} ({detail})", error.message),
        None => error.message,
    }
}

fn is_pdf_input(path: &std::path::Path) -> bool {
    let extension_matches = path
        .extension()
        .and_then(|extension| extension.to_str())
        .is_some_and(|extension| extension.eq_ignore_ascii_case("pdf"));
    if extension_matches {
        return true;
    }
    let Ok(mut file) = std::fs::File::open(path) else {
        return false;
    };
    let mut signature = [0_u8; 5];
    file.read_exact(&mut signature).is_ok() && &signature == b"%PDF-"
}

fn levenshtein_distance(a: &str, b: &str) -> usize {
    let a_len = a.len();
    let b_len = b.len();
    let mut matrix = vec![vec![0usize; b_len + 1]; a_len + 1];

    for (i, row) in matrix.iter_mut().enumerate().take(a_len + 1) {
        row[0] = i;
    }
    if let Some(first_row) = matrix.first_mut() {
        for (j, cell) in first_row.iter_mut().enumerate().take(b_len + 1) {
            *cell = j;
        }
    }

    let a_bytes = a.as_bytes();
    let b_bytes = b.as_bytes();

    for i in 1..=a_len {
        for j in 1..=b_len {
            let cost = if a_bytes[i - 1] == b_bytes[j - 1] {
                0
            } else {
                1
            };
            matrix[i][j] = (matrix[i - 1][j] + 1)
                .min(matrix[i][j - 1] + 1)
                .min(matrix[i - 1][j - 1] + cost);
        }
    }

    matrix[a_len][b_len]
}

fn main() {
    env_logger::init();

    let cli = parse_cli();

    match cli.command {
        Commands::Import { input, output } => {
            let document = DocumentImporter::from_path(&input, ImportOptions::default())
                .unwrap_or_else(|error| exit_with_error("Import failed", error));
            let json = serde_json::to_string_pretty(&document)
                .unwrap_or_else(|error| exit_with_error("JSON serialization failed", error));
            if let Some(path) = output {
                std::fs::write(&path, json.as_bytes())
                    .unwrap_or_else(|error| exit_with_error("Write failed", error));
                eprintln!("Imported {} to {}", input, path);
            } else {
                println!("{json}");
            }
        }

        Commands::Convert {
            input,
            to,
            output,
            force_binary_stdout,
            force,
            no_clobber,
            atomic,
            diagnostics,
            strict,
            fail_on_warning,
            page_range,
            strict_preservation,
            quiet,
            verbose,
            recursive,
            output_dir,
            jobs,
            continue_on_error,
            report,
        } => {
            let advanced = AdvancedConversionOptions {
                page_range: page_range
                    .as_deref()
                    .map(parse_page_range)
                    .transpose()
                    .unwrap_or_else(|error| {
                        exit_with_code(error.code, "Invalid conversion options", error.message)
                    }),
                strict_preservation,
            };
            let options = ConvertOptions {
                output: output.as_deref(),
                force_binary_stdout,
                force,
                no_clobber,
                atomic,
                diagnostics,
                strict,
                fail_on_warning,
                quiet,
                verbose,
                advanced,
            };
            let batch = BatchOptions {
                recursive,
                output_dir: output_dir.as_deref(),
                jobs,
                continue_on_error,
                report: report.as_deref(),
            };
            if let Err(error) = convert_inputs(&input, &to, options, batch) {
                exit_with_code(error.code, "Conversion failed", error.message);
            }
        }

        Commands::Export { input, to, output } => {
            let visual = VisualFormat::from_label(&to).unwrap_or_else(|| {
                exit_with_error(
                    "Export failed",
                    format!("unsupported visual format '{to}'; use svg, pdf, png, or text"),
                )
            });
            let snipper = Snipper::import_path(&input, ImportOptions::default())
                .unwrap_or_else(|error| exit_with_error("Import failed", error));
            let mut artifact = snipper
                .export(visual)
                .unwrap_or_else(|error| exit_with_error("Export failed", error));
            artifact
                .write_to_path(&output)
                .unwrap_or_else(|error| exit_with_error("Write failed", error));
            print_diagnostics(&artifact.diagnostics);
            eprintln!(
                "Exported {} bytes to {}",
                artifact.size_bytes.unwrap_or(0),
                output
            );
        }

        Commands::Inspect { input, json } => {
            let bytes =
                std::fs::read(&input).unwrap_or_else(|error| exit_with_error("Read failed", error));
            let format =
                DocumentImporter::detect_format(&bytes, Some(std::path::Path::new(&input)))
                    .unwrap_or_else(|error| exit_with_error("Detection failed", error));
            let document =
                DocumentImporter::from_bytes(&bytes, Some(format), ImportOptions::default())
                    .unwrap_or_else(|error| exit_with_error("Import failed", error));
            if json {
                println!(
                    "{}",
                    serde_json::json!({
                        "format": format!("{format:?}"),
                        "pages": document.pages.len(),
                        "blocks": document.block_count(),
                        "assets": document.assets.len(),
                        "diagnostics": document.diagnostics,
                    })
                );
            } else {
                println!("Format: {format:?}");
                println!("Pages: {}", document.pages.len());
                println!("Blocks: {}", document.block_count());
                println!("Assets: {}", document.assets.len());
                print_diagnostics(&document.diagnostics);
            }
        }

        Commands::Validate { input } => {
            let document = DocumentImporter::from_path(&input, ImportOptions::default())
                .unwrap_or_else(|error| exit_with_error("Validation failed", error));
            print_diagnostics(&document.diagnostics);
            println!(
                "Valid: {} page(s), {} block(s), {} asset(s)",
                document.pages.len(),
                document.block_count(),
                document.assets.len()
            );
        }

        Commands::Recognize {
            input,
            format,
            output,
            parse_mode,
            recognize_mode,
        }
        | Commands::Rec {
            input,
            format,
            output,
            parse_mode,
            recognize_mode,
        } => {
            eprintln!("Processing: {}", input);

            let parse_mode = match parse_document_parse_mode(&parse_mode) {
                Some(mode) => mode,
                None => {
                    eprintln!("Unknown parse mode: '{}'", parse_mode);
                    eprintln!("  Supported parse modes: {}", supported_parse_modes());
                    std::process::exit(1);
                }
            };
            let recognize_mode = match parse_recognize_mode(&recognize_mode) {
                Some(mode) => mode,
                None => {
                    eprintln!("Unknown recognize mode: '{}'", recognize_mode);
                    eprintln!(
                        "  Supported recognize modes: {}",
                        supported_recognize_modes()
                    );
                    std::process::exit(1);
                }
            };
            let document = match recognize_document(&input, parse_mode, recognize_mode) {
                Ok(document) => document,
                Err(e) => {
                    eprintln!("Error: {}", e);
                    std::process::exit(1);
                }
            };

            eprintln!("Detected {} blocks", document.block_count());

            let resolved_format = resolve_format(&format);

            if let Some(CliTarget::Export(export_format)) = resolve_cli_target(&resolved_format) {
                let artifact = DocumentExportService::export(&document, export_format)
                    .unwrap_or_else(|error| {
                        eprintln!("Export error: {}", error);
                        std::process::exit(1);
                    });
                let bytes = artifact.as_bytes().unwrap_or_else(|| {
                    eprintln!("Export error: exporter returned no primary content");
                    std::process::exit(1);
                });
                if let Some(path) = output {
                    std::fs::write(&path, bytes).unwrap_or_else(|error| {
                        eprintln!("Failed to write {}: {}", path, error);
                        std::process::exit(1);
                    });
                    eprintln!("Exported to {} ({})", path, resolved_format);
                } else if artifact
                    .content
                    .as_ref()
                    .is_some_and(GeneratedContent::is_binary)
                {
                    eprintln!(
                        "Export error: binary format '{}' requires --output",
                        resolved_format
                    );
                    std::process::exit(2);
                } else {
                    let mut stdout = io::stdout().lock();
                    stdout.write_all(bytes).unwrap_or_else(|error| {
                        eprintln!("Failed to write stdout: {}", error);
                        std::process::exit(1);
                    });
                    stdout.write_all(b"\n").unwrap_or_else(|error| {
                        eprintln!("Failed to write stdout: {}", error);
                        std::process::exit(1);
                    });
                }
                return;
            }

            let output_result = match resolved_format.as_str() {
                "latex" | "tex" => DocumentConverter::new(OutputFormat::Latex).convert(&document),
                "latex_display" | "display" => {
                    DocumentConverter::new(OutputFormat::LatexDisplay).convert(&document)
                }
                "latex_equation" | "equation" | "eqn" => {
                    DocumentConverter::new(OutputFormat::LatexEquation).convert(&document)
                }
                "markdown" | "md" => {
                    DocumentConverter::new(OutputFormat::MarkdownBlock).convert(&document)
                }
                "markdown_inline" | "md_inline" => {
                    DocumentConverter::new(OutputFormat::MarkdownInline).convert(&document)
                }
                "typst" => DocumentConverter::new(OutputFormat::Typst).convert(&document),
                "html" => DocumentConverter::new(OutputFormat::Html).convert(&document),
                "mathml" => DocumentConverter::new(OutputFormat::MathML).convert(&document),
                "omml" => DocumentConverter::new(OutputFormat::OMML).convert(&document),
                "json" => serde_json::to_string_pretty(&document).map_err(|error| {
                    latexsnipper_foundation::SnipperError::Conversion(error.to_string())
                }),
                _ => {
                    eprintln!("Unknown format: '{}'", resolved_format);
                    if let Some(suggestion) = suggest_format(&resolved_format) {
                        eprintln!("  Did you mean '{}'?", suggestion);
                    }
                    eprintln!(
                        "  Supported formats: {}",
                        registered_format_names().join(", ")
                    );
                    eprintln!("  Hint: use -h to see all options");
                    std::process::exit(1);
                }
            };

            match output_result {
                Ok(text) => {
                    if let Some(path) = output {
                        std::fs::write(&path, &text).unwrap_or_else(|e| {
                            eprintln!("Failed to write {}: {}", path, e);
                            std::process::exit(1);
                        });
                        eprintln!("Exported to {} ({})", path, resolved_format);
                    } else {
                        println!("{}", text);
                    }
                }
                Err(e) => {
                    eprintln!("Export error: {}", e);
                    std::process::exit(1);
                }
            }
        }

        Commands::Parse { latex } => {
            let parser = LatexParser;
            match parser.parse(&latex) {
                Ok(doc) => {
                    println!("Parsed: {} blocks", doc.block_count());
                    let json = serde_json::to_string_pretty(&doc).expect("JSON failed");
                    println!("{}", json);
                }
                Err(e) => {
                    eprintln!("Parse error: {}", e);
                    std::process::exit(1);
                }
            }
        }

        Commands::Render { latex, to, output } => match render_formula(&latex, to.as_deref()) {
            Ok(rendered) => {
                if let Some(path) = output {
                    std::fs::write(&path, &rendered).unwrap_or_else(|error| {
                        eprintln!("Failed to write {}: {}", path, error);
                        std::process::exit(1);
                    });
                } else {
                    println!("{}", rendered);
                }
            }
            Err(error) => {
                eprintln!("Render error: {}", error);
                std::process::exit(1);
            }
        },

        Commands::Version => {
            println!("snipper {}", env!("CARGO_PKG_VERSION"));
            println!("LaTeXSnipper Core -- Real ONNX Runtime Mode");
            println!("Stable exit codes:");
            for (code, description) in CliExitCode::contract() {
                println!("  {} {description}", code as i32);
            }
            println!();
            println!("Try 'snipper play' for a hidden mini-game!");
        }

        Commands::Doctor => {
            let current_dir = std::env::current_dir().unwrap_or_default();
            let models_dir = current_dir.join("models");
            #[cfg(any(target_os = "windows", target_os = "linux", target_os = "macos"))]
            let runtime =
                RuntimeRegistry::with_factory(OnnxRuntimeFactory::new(models_dir.clone()))
                    .probe(&RuntimeKind::OnnxRuntime);
            #[cfg(not(any(target_os = "windows", target_os = "linux", target_os = "macos")))]
            let runtime: Option<serde_json::Value> = None;
            let (capabilities, capability_registry_error) = match build_capability_matrix() {
                Ok(matrix) => (matrix, None),
                Err(error) => (
                    latexsnipper_conversion::DocumentExportService::capability_matrix(),
                    Some(error),
                ),
            };
            let model_state = doctor_model_state(&models_dir);
            let plugin_state = doctor_plugin_state(std::path::Path::new(".snipper/plugins"));
            println!(
                "{}",
                serde_json::to_string_pretty(&serde_json::json!({
                    "os": std::env::consts::OS,
                    "architecture": std::env::consts::ARCH,
                    "coreVersion": env!("CARGO_PKG_VERSION"),
                    "runtime": runtime,
                    "modelDirectory": models_dir,
                    "modelDirectoryExists": models_dir.is_dir(),
                    "models": model_state,
                    "outputDirectory": current_dir,
                    "outputDirectoryWritable": directory_is_writable(&current_dir),
                    "plugins": plugin_state,
                    "availableConversions": capabilities.entries.iter().filter(|entry| entry.available).count(),
                    "capabilityRegistryError": capability_registry_error,
                    "exitCodes": CliExitCode::contract().into_iter().map(|(code, description)| serde_json::json!({
                        "code": code as i32,
                        "description": description,
                    })).collect::<Vec<_>>(),
                }))
                .expect("doctor report serialization must succeed")
            );
        }

        Commands::Capabilities {
            format,
            input,
            output,
            api_version,
        } => {
            let normalized_format = format.to_ascii_lowercase();
            if !matches!(
                normalized_format.as_str(),
                "table" | "markdown" | "md" | "json"
            ) {
                exit_with_code(
                    CliExitCode::InvalidArguments,
                    "Invalid capability options",
                    format!(
                        "unsupported capability output format '{format}'; use table, markdown, or json"
                    ),
                );
            }
            if normalized_format != "json" && api_version.is_some() {
                exit_with_code(
                    CliExitCode::InvalidArguments,
                    "Invalid capability options",
                    "--api-version is only meaningful with --format json",
                );
            }
            let matrix = build_capability_matrix().unwrap_or_else(|error| {
                exit_with_code(
                    CliExitCode::PluginFailure,
                    "Capability registry failed",
                    error,
                )
            });
            let filtered = filter_capabilities(&matrix, input.as_deref(), output.as_deref());
            match normalized_format.as_str() {
                "markdown" | "md" => print_capabilities_markdown(&filtered),
                "json" => {
                    #[cfg(any(target_os = "windows", target_os = "linux", target_os = "macos"))]
                    let runtime = RuntimeRegistry::with_factory(OnnxRuntimeFactory::new(
                        std::path::PathBuf::from("models"),
                    ))
                    .probe(&RuntimeKind::OnnxRuntime);
                    #[cfg(not(any(
                        target_os = "windows",
                        target_os = "linux",
                        target_os = "macos"
                    )))]
                    let runtime: Option<serde_json::Value> = None;
                    let data = serde_json::json!({
                        "capabilities": filtered,
                        "runtime": runtime,
                    });
                    let value = if api_version.unwrap_or(3) == 3 {
                        serde_json::to_value(latexsnipper_api_types::ApiEnvelopeV3::success(
                            data,
                            Vec::new(),
                        ))
                        .expect("v3 capability envelope serialization must succeed")
                    } else {
                        data
                    };
                    println!(
                        "{}",
                        serde_json::to_string_pretty(&value)
                            .expect("capability JSON serialization must succeed")
                    );
                }
                _ => print_capabilities_table(&filtered),
            }
        }

        Commands::Migrate(command) => match migration::run(command) {
            Ok(MigrationRunStatus::Completed) => {}
            Ok(MigrationRunStatus::RequiresManualAction) => {
                std::process::exit(CliExitCode::MigrationRequiresManualAction as i32)
            }
            Err(error) => exit_with_code(CliExitCode::InvalidInput, "Migration failed", error),
        },

        Commands::Play => play_game(),

        Commands::Models(cmd) => match cmd {
            ModelsCommand::Package {
                source,
                output,
                catalog,
                category,
                variant,
                model_version,
            } => {
                let request = model_transport::LegacyPackageRequest {
                    source: &source,
                    output: &output,
                    catalog: &catalog,
                    category: &category,
                    variant: &variant,
                    version: &model_version,
                };
                match model_transport::package_legacy_model(request) {
                    Ok(manifest) => println!("{}", manifest.id),
                    Err(error) => exit_with_code(
                        CliExitCode::MissingModel,
                        "Model package creation failed",
                        error,
                    ),
                }
            }
            ModelsCommand::Inspect { archive, json } => {
                match model_transport::inspect_archive(&archive) {
                    Ok(inspection) if json => println!(
                        "{}",
                        serde_json::to_string_pretty(&inspection)
                            .expect("model inspection must serialize")
                    ),
                    Ok(inspection) => println!(
                        "{} (transport v{}, {} entries)",
                        inspection.manifest.id,
                        inspection.layout.transport_version,
                        inspection.layout.entry_count
                    ),
                    Err(error) => exit_with_code(
                        CliExitCode::MissingModel,
                        "Model package inspection failed",
                        error,
                    ),
                }
            }
            ModelsCommand::Download {
                category,
                all,
                manifest_url,
            } => {
                handle_models_download(category, all, manifest_url);
            }
            ModelsCommand::List { category } => {
                handle_models_list(category);
            }
            ModelsCommand::Verify { category } => {
                handle_models_verify(category);
            }
            ModelsCommand::Purge {
                category,
                variant,
                yes,
            } => {
                if let Err(error) = handle_models_purge(category, variant, yes) {
                    exit_with_code(error.code, "Model purge failed", error.message);
                }
            }
        },
        Commands::Plugin { store_dir, command } => {
            if let Err(error) = handle_plugin_command(&store_dir, command) {
                exit_with_code(CliExitCode::PluginFailure, "Plugin command failed", error);
            }
        }
        Commands::Job(cmd) => match cmd {
            JobCommand::Run {
                input,
                format,
                output,
                mode,
            } => {
                handle_job_run(&input, &format, output.as_deref(), &mode);
            }
            JobCommand::Inspect { job_id } => {
                handle_job_inspect(&job_id);
            }
        },
        Commands::Completions { shell } => {
            let mut command = Cli::command();
            clap_complete::generate(shell, &mut command, "snipper", &mut io::stdout());
        }
        Commands::Manpages { output_dir } => {
            let directory = std::path::Path::new(&output_dir);
            std::fs::create_dir_all(directory)
                .unwrap_or_else(|error| exit_with_error("Man page directory failed", error));
            let path = directory.join("snipper.1");
            let mut file = std::fs::File::create(&path)
                .unwrap_or_else(|error| exit_with_error("Man page creation failed", error));
            clap_mangen::Man::new(Cli::command())
                .render(&mut file)
                .unwrap_or_else(|error| exit_with_error("Man page rendering failed", error));
            eprintln!("Generated {}", path.display());
        }
    }
}

fn parse_cli() -> Cli {
    let formats: &'static str = Box::leak(
        format!(
            "Available formats on this build: {}",
            registered_format_names().join(", ")
        )
        .into_boxed_str(),
    );
    let recognize: &'static str = Box::leak(
        format!(
            "Available formats: {}\nParse modes: {}\nRecognition modes: {}",
            registered_format_names().join(", "),
            supported_parse_modes(),
            supported_recognize_modes(),
        )
        .into_boxed_str(),
    );
    let matches = Cli::command()
        .mut_subcommand("convert", |command| command.after_help(formats))
        .mut_subcommand("recognize", |command| command.after_help(recognize))
        .mut_subcommand("rec", |command| command.after_help(recognize))
        .get_matches();
    Cli::from_arg_matches(&matches).unwrap_or_else(|error| error.exit())
}

#[derive(Clone, Copy)]
struct ConvertOptions<'a> {
    output: Option<&'a str>,
    force_binary_stdout: bool,
    force: bool,
    no_clobber: bool,
    atomic: bool,
    diagnostics: DiagnosticsFormat,
    strict: bool,
    fail_on_warning: bool,
    quiet: bool,
    verbose: bool,
    advanced: AdvancedConversionOptions,
}

#[derive(Clone, Copy, Default)]
struct AdvancedConversionOptions {
    page_range: Option<latexsnipper_ast::PageRange>,
    strict_preservation: bool,
}

impl AdvancedConversionOptions {
    fn import_options(self) -> ImportOptions {
        ImportOptions {
            page_range: self.page_range,
            strict: self.strict_preservation,
            preserve_unknown_parts: self.strict_preservation,
            ..ImportOptions::default()
        }
    }

    fn diagnostic(self) -> Option<Diagnostic> {
        (self.page_range.is_some() || self.strict_preservation).then(|| {
            Diagnostic::new(
                DiagnosticLevel::Info,
                "CLI_OPTIONS_APPLIED",
                format!(
                    "pageRange={}, strictPreservation={}",
                    self.page_range
                        .map(|range| format!("{}-{}", range.start, range.end))
                        .unwrap_or_else(|| "all".to_string()),
                    self.strict_preservation
                ),
            )
        })
    }
}

#[derive(Clone, Copy)]
struct BatchOptions<'a> {
    recursive: bool,
    output_dir: Option<&'a str>,
    jobs: usize,
    continue_on_error: bool,
    report: Option<&'a str>,
}

#[derive(Debug, Clone)]
struct CliFailure {
    code: CliExitCode,
    message: String,
}

impl CliFailure {
    fn new(code: CliExitCode, message: impl Into<String>) -> Self {
        Self {
            code,
            message: message.into(),
        }
    }
}

#[derive(Debug, Clone, Copy)]
enum CliTarget {
    Semantic(OutputFormat),
    Export(ExportFormat),
}

#[derive(Debug, Clone)]
struct BatchTask {
    input: std::path::PathBuf,
    relative: std::path::PathBuf,
    output: Option<std::path::PathBuf>,
}

#[derive(Debug)]
struct BatchOutcome {
    input: String,
    output: Option<String>,
    success: bool,
    exit_code: i32,
    message: Option<String>,
}

fn convert_inputs(
    inputs: &[String],
    target_label: &str,
    options: ConvertOptions<'_>,
    batch: BatchOptions<'_>,
) -> Result<(), CliFailure> {
    if batch.jobs == 0 {
        return Err(CliFailure::new(
            CliExitCode::InvalidArguments,
            "--jobs must be greater than zero",
        ));
    }
    let target = resolve_cli_target(target_label).ok_or_else(|| {
        CliFailure::new(
            CliExitCode::UnsupportedConversion,
            format!("unsupported target format '{target_label}'"),
        )
    })?;
    let mut tasks = expand_batch_inputs(inputs, batch.recursive)?;
    if tasks.is_empty() {
        return Err(CliFailure::new(
            CliExitCode::InvalidInput,
            "no input files matched",
        ));
    }
    if tasks.len() > 1 && options.output.is_some() {
        return Err(CliFailure::new(
            CliExitCode::InvalidArguments,
            "-o/--output is only valid for one input; use --output-dir for batch conversion",
        ));
    }
    if tasks.len() > 1 && batch.output_dir.is_none() {
        return Err(CliFailure::new(
            CliExitCode::InvalidArguments,
            "multiple inputs require --output-dir",
        ));
    }

    if let Some(output_dir) = batch.output_dir {
        let output_dir = std::path::Path::new(output_dir);
        let extension = target_extension(target);
        for task in &mut tasks {
            let mut relative = task.relative.clone();
            relative.set_extension(&extension);
            task.output = Some(output_dir.join(relative));
        }
    } else if tasks.len() == 1 {
        tasks[0].output = options.output.map(std::path::PathBuf::from);
    }

    let worker_count = batch.jobs.min(tasks.len()).max(1);
    let next = std::sync::atomic::AtomicUsize::new(0);
    let stop = std::sync::atomic::AtomicBool::new(false);
    let outcomes = std::sync::Mutex::new(Vec::with_capacity(tasks.len()));
    std::thread::scope(|scope| {
        for _ in 0..worker_count {
            scope.spawn(|| loop {
                if stop.load(std::sync::atomic::Ordering::Acquire) {
                    break;
                }
                let index = next.fetch_add(1, std::sync::atomic::Ordering::AcqRel);
                let Some(task) = tasks.get(index) else {
                    break;
                };
                let output = task
                    .output
                    .as_ref()
                    .map(|path| path.to_string_lossy().into_owned());
                let input = task.input.to_string_lossy().into_owned();
                let task_options = ConvertOptions {
                    output: output.as_deref(),
                    ..options
                };
                let result = convert_path(&input, target_label, task_options);
                let outcome = match result {
                    Ok(()) => BatchOutcome {
                        input,
                        output,
                        success: true,
                        exit_code: 0,
                        message: None,
                    },
                    Err(error) => {
                        if !batch.continue_on_error {
                            stop.store(true, std::sync::atomic::Ordering::Release);
                        }
                        BatchOutcome {
                            input,
                            output,
                            success: false,
                            exit_code: error.code as i32,
                            message: Some(error.message),
                        }
                    }
                };
                outcomes.lock().unwrap().push(outcome);
            });
        }
    });

    let mut outcomes = outcomes.into_inner().unwrap();
    outcomes.sort_by(|left, right| left.input.cmp(&right.input));
    if let Some(report) = batch.report {
        write_batch_report(report, target_label, &outcomes)?;
    }
    let failures: Vec<_> = outcomes.iter().filter(|outcome| !outcome.success).collect();
    if failures.is_empty() {
        return Ok(());
    }
    if batch.continue_on_error {
        return Err(CliFailure::new(
            CliExitCode::PartialBatchFailure,
            format!(
                "{} of {} batch conversions failed",
                failures.len(),
                outcomes.len()
            ),
        ));
    }
    let failure = failures[0];
    Err(CliFailure::new(
        exit_code_from_i32(failure.exit_code),
        failure
            .message
            .clone()
            .unwrap_or_else(|| "batch conversion failed".to_string()),
    ))
}

fn expand_batch_inputs(inputs: &[String], recursive: bool) -> Result<Vec<BatchTask>, CliFailure> {
    if inputs.iter().any(|input| input == "-") {
        if inputs.len() != 1 {
            return Err(CliFailure::new(
                CliExitCode::InvalidArguments,
                "stdin cannot be combined with other batch inputs",
            ));
        }
        return Ok(vec![BatchTask {
            input: std::path::PathBuf::from("-"),
            relative: std::path::PathBuf::from("stdin"),
            output: None,
        }]);
    }

    let mut discovered =
        std::collections::BTreeMap::<std::path::PathBuf, std::path::PathBuf>::new();
    for input in inputs {
        if contains_glob(input) {
            let root = glob_root(input);
            let mut matched = false;
            for entry in glob::glob(input).map_err(|error| {
                CliFailure::new(CliExitCode::InvalidArguments, format!("{input}: {error}"))
            })? {
                let path = entry.map_err(|error| {
                    CliFailure::new(CliExitCode::InvalidInput, error.to_string())
                })?;
                if path.is_file() {
                    matched = true;
                    let relative = safe_relative_path(&path, &root);
                    discovered.insert(path, relative);
                }
            }
            if !matched {
                return Err(CliFailure::new(
                    CliExitCode::InvalidInput,
                    format!("glob matched no files: {input}"),
                ));
            }
            continue;
        }

        let path = std::path::PathBuf::from(input);
        if path.is_dir() {
            collect_directory_inputs(&path, &path, recursive, &mut discovered)?;
        } else {
            let relative = path
                .file_name()
                .map(std::path::PathBuf::from)
                .unwrap_or_else(|| std::path::PathBuf::from("input"));
            discovered.insert(path, relative);
        }
    }
    Ok(discovered
        .into_iter()
        .map(|(input, relative)| BatchTask {
            input,
            relative,
            output: None,
        })
        .collect())
}

fn collect_directory_inputs(
    root: &std::path::Path,
    directory: &std::path::Path,
    recursive: bool,
    discovered: &mut std::collections::BTreeMap<std::path::PathBuf, std::path::PathBuf>,
) -> Result<(), CliFailure> {
    let mut entries: Vec<_> = std::fs::read_dir(directory)
        .map_err(|error| {
            CliFailure::new(
                CliExitCode::InvalidInput,
                format!("{}: {error}", directory.display()),
            )
        })?
        .collect::<Result<_, _>>()
        .map_err(|error| CliFailure::new(CliExitCode::InvalidInput, error.to_string()))?;
    entries.sort_by_key(std::fs::DirEntry::file_name);
    for entry in entries {
        let path = entry.path();
        if path.is_file() {
            discovered.insert(path.clone(), safe_relative_path(&path, root));
        } else if recursive && path.is_dir() {
            collect_directory_inputs(root, &path, true, discovered)?;
        }
    }
    Ok(())
}

fn contains_glob(input: &str) -> bool {
    input
        .chars()
        .any(|character| matches!(character, '*' | '?' | '['))
}

fn glob_root(pattern: &str) -> std::path::PathBuf {
    let wildcard = pattern
        .char_indices()
        .find_map(|(index, character)| "*?[".contains(character).then_some(index))
        .unwrap_or(pattern.len());
    let prefix = &pattern[..wildcard];
    let path = std::path::Path::new(prefix);
    if prefix.ends_with('/') || prefix.ends_with('\\') {
        path.to_path_buf()
    } else {
        path.parent()
            .unwrap_or_else(|| std::path::Path::new("."))
            .to_path_buf()
    }
}

fn safe_relative_path(path: &std::path::Path, root: &std::path::Path) -> std::path::PathBuf {
    path.strip_prefix(root)
        .ok()
        .filter(|relative| {
            relative
                .components()
                .all(|component| matches!(component, std::path::Component::Normal(_)))
        })
        .map(std::path::PathBuf::from)
        .or_else(|| path.file_name().map(std::path::PathBuf::from))
        .unwrap_or_else(|| std::path::PathBuf::from("input"))
}

fn target_extension(target: CliTarget) -> String {
    match target {
        CliTarget::Semantic(format) => format.extension().to_string(),
        CliTarget::Export(format) => DocumentExportService::format_label(format).to_string(),
    }
}

fn write_batch_report(
    report: &str,
    target: &str,
    outcomes: &[BatchOutcome],
) -> Result<(), CliFailure> {
    let entries: Vec<_> = outcomes
        .iter()
        .map(|outcome| {
            serde_json::json!({
                "input": outcome.input,
                "output": outcome.output,
                "success": outcome.success,
                "exitCode": outcome.exit_code,
                "message": outcome.message,
            })
        })
        .collect();
    let successful = outcomes.iter().filter(|outcome| outcome.success).count();
    let bytes = serde_json::to_vec_pretty(&serde_json::json!({
        "schemaVersion": 1,
        "target": target,
        "total": outcomes.len(),
        "successful": successful,
        "failed": outcomes.len() - successful,
        "files": entries,
    }))
    .map_err(|error| CliFailure::new(CliExitCode::GenericFailure, error.to_string()))?;
    let report_options = ConvertOptions {
        output: Some(report),
        force_binary_stdout: false,
        force: true,
        no_clobber: false,
        atomic: true,
        diagnostics: DiagnosticsFormat::Text,
        strict: false,
        fail_on_warning: false,
        quiet: true,
        verbose: false,
        advanced: AdvancedConversionOptions::default(),
    };
    write_output_file(report, &bytes, &report_options)
}

fn exit_code_from_i32(code: i32) -> CliExitCode {
    CliExitCode::contract()
        .into_iter()
        .find_map(|(candidate, _)| (candidate as i32 == code).then_some(candidate))
        .unwrap_or(CliExitCode::GenericFailure)
}

fn convert_path(input: &str, target: &str, options: ConvertOptions<'_>) -> Result<(), CliFailure> {
    let target = resolve_cli_target(target).ok_or_else(|| {
        let suggestion = suggest_registered_format(target)
            .map(|value| format!("; did you mean '{value}'?"))
            .unwrap_or_default();
        CliFailure::new(
            CliExitCode::UnsupportedConversion,
            format!(
                "unsupported target format '{target}'{suggestion}; available formats: {}",
                registered_format_names().join(", ")
            ),
        )
    })?;
    let document = read_document(input, options.advanced)?;
    let mut artifact =
        match target {
            CliTarget::Semantic(format) => DocumentConverter::new(format)
                .convert_artifact(&document)
                .map_err(|error| CliFailure::new(CliExitCode::UnsupportedConversion, error))?,
            CliTarget::Export(format) => {
                DocumentExportService::export(&document, format).map_err(|error| {
                    CliFailure::new(CliExitCode::UnsupportedConversion, error.to_string())
                })?
            }
        };
    if let Some(diagnostic) = options.advanced.diagnostic() {
        artifact.diagnostics.push(diagnostic);
    }

    if !options.quiet {
        emit_diagnostics(&artifact.diagnostics, options.diagnostics)?;
    }
    if diagnostics_fail(
        &artifact.diagnostics,
        options.strict,
        options.fail_on_warning,
    ) {
        return Err(CliFailure::new(
            CliExitCode::StrictDiagnosticFailure,
            "diagnostics exceeded the requested strictness threshold",
        ));
    }

    let bytes = artifact.as_bytes().ok_or_else(|| {
        CliFailure::new(
            CliExitCode::OutputValidationFailure,
            "exporter returned no primary content",
        )
    })?;
    let binary = artifact
        .content
        .as_ref()
        .is_some_and(GeneratedContent::is_binary);
    let output = options.output.unwrap_or("-");
    if output == "-" {
        if binary && !options.force_binary_stdout {
            return Err(CliFailure::new(
                CliExitCode::InvalidArguments,
                "binary stdout is disabled; pass --force-binary-stdout explicitly",
            ));
        }
        let mut stdout = io::stdout().lock();
        stdout.write_all(bytes).map_err(|error| {
            CliFailure::new(CliExitCode::GenericFailure, format!("stdout: {error}"))
        })?;
        stdout.flush().map_err(|error| {
            CliFailure::new(CliExitCode::GenericFailure, format!("stdout: {error}"))
        })?;
        return Ok(());
    }

    validate_generated_artifact(&artifact, output)?;
    write_output_file(output, bytes, &options)?;
    if options.verbose && !options.quiet {
        eprintln!(
            "Converted {input} to {output} ({} bytes, format {})",
            bytes.len(),
            artifact.format
        );
    }
    Ok(())
}

fn resolve_cli_target(label: &str) -> Option<CliTarget> {
    let lowercase = label.trim().to_ascii_lowercase();
    if let Some(format) = OutputFormat::all().iter().copied().find(|format| {
        format.name() == lowercase
            || latexsnipper_conversion::semantic_aliases(*format).contains(&lowercase.as_str())
    }) {
        return Some(CliTarget::Semantic(format));
    }
    DocumentExportService::format_from_label(&lowercase).map(CliTarget::Export)
}

fn registered_format_names() -> Vec<&'static str> {
    let mut names: Vec<_> = latexsnipper_conversion::CapabilityRegistry::for_target(
        latexsnipper_conversion::CapabilityTarget::Native,
    )
    .into_iter()
    .filter(|entry| entry.available)
    .map(|entry| entry.format)
    .collect();
    names.sort_unstable();
    names.dedup();
    names
}

fn supported_parse_modes() -> String {
    DocumentParseMode::all()
        .iter()
        .map(|mode| mode.label())
        .collect::<Vec<_>>()
        .join(", ")
}

fn supported_recognize_modes() -> String {
    RecognizeMode::all()
        .iter()
        .map(|mode| mode.label())
        .collect::<Vec<_>>()
        .join(", ")
}

fn suggest_registered_format(input: &str) -> Option<&'static str> {
    registered_format_names()
        .into_iter()
        .min_by_key(|candidate| levenshtein_distance(&input.to_ascii_lowercase(), candidate))
        .filter(|candidate| levenshtein_distance(&input.to_ascii_lowercase(), candidate) <= 3)
}

fn read_document(input: &str, advanced: AdvancedConversionOptions) -> Result<Document, CliFailure> {
    if input != "-" {
        return DocumentImporter::from_path(input, advanced.import_options()).map_err(|error| {
            CliFailure::new(CliExitCode::InvalidInput, format!("{input}: {error}"))
        });
    }

    let mut bytes = Vec::new();
    io::stdin()
        .read_to_end(&mut bytes)
        .map_err(|error| CliFailure::new(CliExitCode::InvalidInput, format!("stdin: {error}")))?;
    if bytes.is_empty() {
        return Err(CliFailure::new(
            CliExitCode::InvalidInput,
            "stdin did not contain a document",
        ));
    }
    DocumentImporter::from_bytes(&bytes, None, advanced.import_options())
        .map_err(|error| CliFailure::new(CliExitCode::InvalidInput, format!("stdin: {error}")))
}

fn parse_page_range(value: &str) -> Result<latexsnipper_ast::PageRange, CliFailure> {
    let (start, end) = value.split_once('-').ok_or_else(|| {
        CliFailure::new(
            CliExitCode::InvalidArguments,
            "--page-range must use START-END",
        )
    })?;
    let start = start.parse::<u32>().map_err(|_| {
        CliFailure::new(
            CliExitCode::InvalidArguments,
            "page range start must be a positive integer",
        )
    })?;
    let end = end.parse::<u32>().map_err(|_| {
        CliFailure::new(
            CliExitCode::InvalidArguments,
            "page range end must be a positive integer",
        )
    })?;
    if start == 0 || end < start {
        return Err(CliFailure::new(
            CliExitCode::InvalidArguments,
            "page range must be 1-based with END >= START",
        ));
    }
    Ok(latexsnipper_ast::PageRange { start, end })
}

fn emit_diagnostics(
    diagnostics: &[Diagnostic],
    format: DiagnosticsFormat,
) -> Result<(), CliFailure> {
    match format {
        DiagnosticsFormat::Text => print_diagnostics(diagnostics),
        DiagnosticsFormat::Json => eprintln!(
            "{}",
            serde_json::to_string(diagnostics).map_err(|error| {
                CliFailure::new(CliExitCode::GenericFailure, error.to_string())
            })?
        ),
        DiagnosticsFormat::Sarif => {
            let results: Vec<_> = diagnostics
                .iter()
                .map(|diagnostic| {
                    serde_json::json!({
                        "ruleId": diagnostic.code,
                        "level": match diagnostic.level {
                            DiagnosticLevel::Info => "note",
                            DiagnosticLevel::Warning => "warning",
                            DiagnosticLevel::Error => "error",
                        },
                        "message": { "text": diagnostic.message },
                    })
                })
                .collect();
            eprintln!(
                "{}",
                serde_json::json!({
                    "version": "2.1.0",
                    "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
                    "runs": [{
                        "tool": { "driver": { "name": "LaTeXSnipper", "version": env!("CARGO_PKG_VERSION") } },
                        "results": results,
                    }]
                })
            );
        }
    }
    Ok(())
}

fn diagnostics_fail(diagnostics: &[Diagnostic], strict: bool, fail_on_warning: bool) -> bool {
    diagnostics.iter().any(|diagnostic| match diagnostic.level {
        DiagnosticLevel::Error => strict,
        DiagnosticLevel::Warning => strict || fail_on_warning,
        DiagnosticLevel::Info => false,
    })
}

fn validate_generated_artifact(artifact: &ExportArtifact, output: &str) -> Result<(), CliFailure> {
    let Some(GeneratedContent::Binary(bytes)) = artifact.content.as_ref() else {
        return Ok(());
    };
    let hint = std::path::Path::new(output);
    let format = DocumentImporter::detect_format(bytes, Some(hint)).map_err(|error| {
        CliFailure::new(
            CliExitCode::OutputValidationFailure,
            format!(
                "generated {} failed format validation: {error}",
                artifact.format
            ),
        )
    })?;
    DocumentImporter::from_bytes(bytes, Some(format), ImportOptions::default()).map_err(
        |error| {
            CliFailure::new(
                CliExitCode::OutputValidationFailure,
                format!(
                    "generated {} could not be reopened: {error}",
                    artifact.format
                ),
            )
        },
    )?;
    Ok(())
}

fn write_output_file(
    output: &str,
    bytes: &[u8],
    options: &ConvertOptions<'_>,
) -> Result<(), CliFailure> {
    let path = std::path::Path::new(output);
    let parent = path
        .parent()
        .filter(|value| !value.as_os_str().is_empty())
        .unwrap_or_else(|| std::path::Path::new("."));
    std::fs::create_dir_all(parent).map_err(|error| {
        CliFailure::new(
            CliExitCode::GenericFailure,
            format!(
                "could not create output directory {}: {error}",
                parent.display()
            ),
        )
    })?;
    if path.exists() && (options.no_clobber || !options.force) {
        return Err(CliFailure::new(
            CliExitCode::InvalidArguments,
            format!("output already exists: {output}; pass --force to replace it"),
        ));
    }
    if !options.atomic {
        return std::fs::write(path, bytes).map_err(|error| {
            CliFailure::new(CliExitCode::GenericFailure, format!("{output}: {error}"))
        });
    }

    let file_name = path
        .file_name()
        .and_then(|value| value.to_str())
        .ok_or_else(|| CliFailure::new(CliExitCode::InvalidArguments, "invalid output path"))?;
    let unique = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    let temporary = parent.join(format!(
        ".{file_name}.snipper-{}-{unique}.tmp",
        std::process::id()
    ));
    let result = (|| -> Result<(), CliFailure> {
        let mut file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temporary)
            .map_err(|error| CliFailure::new(CliExitCode::GenericFailure, error.to_string()))?;
        file.write_all(bytes)
            .and_then(|_| file.flush())
            .and_then(|_| file.sync_all())
            .map_err(|error| CliFailure::new(CliExitCode::GenericFailure, error.to_string()))?;
        drop(file);
        fs_util::activate_file(&temporary, path, options.force)
            .map_err(|error| CliFailure::new(CliExitCode::GenericFailure, error.to_string()))
    })();
    if result.is_err() {
        let _ = std::fs::remove_file(&temporary);
    }
    result
}

fn doctor_model_state(models_dir: &std::path::Path) -> serde_json::Value {
    let manifest_path = models_dir.join("model-manifest.json");
    if !manifest_path.is_file() {
        return serde_json::json!({
            "manifestAvailable": false,
            "installedVariants": 0,
            "expectedFilesPresent": false,
            "checksumStatus": "unavailable_without_manifest",
        });
    }
    let manifest = match load_runtime_model_manifest(&manifest_path) {
        Ok(value) => value,
        Err(error) => {
            return serde_json::json!({
                "manifestAvailable": true,
                "manifestValid": false,
                "error": error.to_string(),
            });
        }
    };
    let manager = latexsnipper_model::ModelManager::new(models_dir.to_path_buf());
    let mut installed = 0usize;
    let mut checked_files = 0usize;
    let mut missing_files = 0usize;
    for (category, info) in &manifest.categories {
        for variant_id in manager.list_installed(category) {
            installed += 1;
            if let Some(variant) = info
                .variants
                .iter()
                .find(|candidate| candidate.id == variant_id)
            {
                let directory = manager.variant_dir(category, &variant_id);
                for file in &variant.files {
                    checked_files += 1;
                    if !directory.join(file).is_file() {
                        missing_files += 1;
                    }
                }
            }
        }
    }
    serde_json::json!({
        "manifestAvailable": true,
        "manifestValid": true,
        "installedVariants": installed,
        "checkedFiles": checked_files,
        "missingFiles": missing_files,
        "expectedFilesPresent": missing_files == 0,
        "checksumStatus": "archives_verified_at_download; extracted_files_checked_for_presence",
    })
}

fn load_runtime_model_manifest(
    path: &std::path::Path,
) -> latexsnipper_foundation::Result<latexsnipper_model::ModelManifest> {
    latexsnipper_model::LoadedModelManifest::load(path)?.into_runtime_manifest()
}

fn download_runtime_model_manifest(
    url: &str,
    save_path: &std::path::Path,
) -> latexsnipper_foundation::Result<latexsnipper_model::ModelManifest> {
    let loaded = latexsnipper_model::LoadedModelManifest::download(url)?;
    loaded.save(save_path)?;
    loaded.into_runtime_manifest()
}

fn doctor_plugin_state(store_dir: &std::path::Path) -> serde_json::Value {
    let store = latexsnipper_plugin::PluginStore::new(store_dir.to_path_buf());
    let plugins = match store.list() {
        Ok(value) => value,
        Err(error) => {
            return serde_json::json!({
                "storeDirectory": store_dir,
                "registryValid": false,
                "error": error.to_string(),
                "nativeAbiHostAvailable": false,
                "wasiComponentHostAvailable": false,
                "brokeredPermissionEnforcement": true,
                "nativeProcessOsSandboxed": false,
                "responseBudgetScope": "response-file-observation",
            });
        }
    };
    let enabled = plugins.iter().filter(|plugin| plugin.enabled).count();
    let failed_integrity = plugins
        .iter()
        .filter(|plugin| store.verify_installed(&plugin.manifest.id).is_err())
        .count();
    let plugin_details = plugins
        .iter()
        .map(|plugin| {
            let process_host = matches!(
                plugin.manifest.class,
                latexsnipper_plugin::PluginClass::IsolatedProcess
            );
            serde_json::json!({
                "id": plugin.manifest.id,
                "class": plugin.manifest.class,
                "enabled": plugin.enabled,
                "executionHostAvailable": process_host,
                "effectivePermissions": store.effective_permissions(&plugin.manifest.id).ok(),
            })
        })
        .collect::<Vec<_>>();
    serde_json::json!({
        "storeDirectory": store_dir,
        "registryValid": true,
        "installed": plugins.len(),
        "enabled": enabled,
        "failedIntegrity": failed_integrity,
        "isolatedProcessHostAvailable": true,
        "nativeAbiHostAvailable": false,
        "wasiComponentHostAvailable": false,
        "brokeredPermissionEnforcement": true,
        "nativeProcessOsSandboxed": false,
        "responseBudgetScope": "response-file-observation",
        "processTreeContainment": if cfg!(unix) { "unix-process-group" } else { "windows-job-object-after-spawn" },
        "plugins": plugin_details,
    })
}

fn directory_is_writable(directory: &std::path::Path) -> bool {
    let probe = directory.join(format!(
        ".snipper-write-probe-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos()
    ));
    match std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&probe)
    {
        Ok(file) => {
            drop(file);
            std::fs::remove_file(probe).is_ok()
        }
        Err(_) => false,
    }
}

fn print_diagnostics(diagnostics: &[Diagnostic]) {
    for diagnostic in diagnostics {
        eprintln!(
            "[{:?}] {}: {}",
            diagnostic.level, diagnostic.code, diagnostic.message
        );
    }
}

fn exit_with_error(prefix: &str, error: impl std::fmt::Display) -> ! {
    eprintln!("{prefix}: {error}");
    std::process::exit(1)
}

fn exit_with_code(code: CliExitCode, prefix: &str, error: impl std::fmt::Display) -> ! {
    eprintln!("{prefix}: {error}");
    std::process::exit(code as i32)
}

fn handle_models_download(category: Option<String>, all: bool, manifest_url: Option<String>) {
    let models_dir = std::path::PathBuf::from("models");
    let manager = latexsnipper_model::ModelManager::new(models_dir);

    // Load manifest
    use latexsnipper_model::manifest::DEFAULT_MANIFEST_URL;
    let manifest_path = std::path::PathBuf::from("models/model-manifest.json");

    // --manifest-url overrides local manifest: always download fresh
    let manifest = if let Some(url) = manifest_url {
        eprintln!("Downloading manifest from {}", url);
        match download_runtime_model_manifest(&url, &manifest_path) {
            Ok(m) => {
                eprintln!("Manifest downloaded successfully.");
                m
            }
            Err(e) => {
                eprintln!("Failed to download manifest: {}", e);
                std::process::exit(1);
            }
        }
    } else if manifest_path.exists() {
        match load_runtime_model_manifest(&manifest_path) {
            Ok(m) => m,
            Err(e) => {
                eprintln!("Failed to load local manifest: {}", e);
                eprintln!("Try --manifest-url to download a fresh manifest.");
                std::process::exit(1);
            }
        }
    } else {
        let url = DEFAULT_MANIFEST_URL.to_string();
        eprintln!("Local manifest not found, downloading from {}", url);

        match download_runtime_model_manifest(&url, &manifest_path) {
            Ok(m) => {
                eprintln!("Manifest downloaded successfully.");
                m
            }
            Err(e) => {
                eprintln!("Failed to download manifest: {}", e);
                eprintln!(
                    "Ensure you have a network connection, or provide a local manifest at {}",
                    manifest_path.display()
                );
                std::process::exit(1);
            }
        }
    };

    if let Some(cat) = category {
        // Download specific category
        if let Some(info) = manifest.categories.get(&cat) {
            let variant_id = info.default.as_deref().unwrap_or("default");
            if let Some(variant) = info.variants.iter().find(|v| v.id == variant_id) {
                if let Some(ref zip_file) = variant.zip_file {
                    let url = format!("{}/{}", manifest.base_url, zip_file);
                    eprintln!("Downloading {} from {}", cat, url);

                    let progress =
                        Box::new(|status: latexsnipper_model::DownloadStatus| match status {
                            latexsnipper_model::DownloadStatus::Starting { url, total_bytes } => {
                                eprintln!("Starting download: {}", url);
                                if let Some(total) = total_bytes {
                                    eprintln!("  Size: {:.1} MB", total as f64 / 1024.0 / 1024.0);
                                }
                            }
                            latexsnipper_model::DownloadStatus::Progress { downloaded, total } => {
                                if let Some(total) = total {
                                    let percent = downloaded as f64 / total as f64 * 100.0;
                                    eprint!("\r  Progress: {:.1}%", percent);
                                }
                            }
                            latexsnipper_model::DownloadStatus::Extracting { file } => {
                                eprintln!("\n  Extracting: {}", file);
                            }
                            latexsnipper_model::DownloadStatus::Complete { path } => {
                                eprintln!("  Installed to: {}", path.display());
                            }
                            latexsnipper_model::DownloadStatus::Failed { error } => {
                                eprintln!("  Failed: {}", error);
                            }
                        });

                    let expected_sha256 = manifest.checksums.get(zip_file).map(|s| s.as_str());

                    match manager.download_with_progress(
                        &url,
                        &cat,
                        &variant.id,
                        expected_sha256,
                        &variant.files,
                        Some(progress),
                    ) {
                        Ok(path) => {
                            eprintln!("Successfully downloaded {} to {}", cat, path.display());
                        }
                        Err(e) => {
                            eprintln!("Download failed: {}", e);
                            std::process::exit(1);
                        }
                    }
                }
            }
        } else {
            eprintln!("Unknown category: {}", cat);
            eprintln!(
                "Available categories: {:?}",
                manifest.categories.keys().collect::<Vec<_>>()
            );
            std::process::exit(1);
        }
    } else if all {
        // Download all models
        eprintln!("Downloading all models...");
        match manager.download_all(&manifest, true, None) {
            Ok(paths) => {
                eprintln!("Downloaded {} model packages", paths.len());
                for path in &paths {
                    eprintln!("  - {}", path.display());
                }
            }
            Err(e) => {
                eprintln!("Download failed: {}", e);
                std::process::exit(1);
            }
        }
    } else {
        // Download only required models
        eprintln!("Downloading required models...");
        match manager.download_all(&manifest, false, None) {
            Ok(paths) => {
                eprintln!("Downloaded {} model packages", paths.len());
                for path in &paths {
                    eprintln!("  - {}", path.display());
                }
            }
            Err(e) => {
                eprintln!("Download failed: {}", e);
                std::process::exit(1);
            }
        }
    }
}

fn handle_models_list(category: Option<String>) {
    let models_dir = std::path::PathBuf::from("models");
    let manager = latexsnipper_model::ModelManager::new(models_dir);

    if let Some(cat) = category {
        let variants = manager.list_installed(&cat);
        if variants.is_empty() {
            eprintln!("No models installed for category: {}", cat);
        } else {
            eprintln!("Installed models for {}:", cat);
            for variant in &variants {
                eprintln!("  - {}", variant);
            }
        }
    } else {
        // List all categories
        let manifest_path = std::path::PathBuf::from("models/model-manifest.json");
        if manifest_path.exists() {
            if let Ok(manifest) = load_runtime_model_manifest(&manifest_path) {
                eprintln!("Installed models:");
                for (cat, info) in &manifest.categories {
                    let variants = manager.list_installed(cat);
                    if variants.is_empty() {
                        eprintln!("  {} (not installed)", cat);
                    } else {
                        eprintln!("  {}:", cat);
                        for variant in &variants {
                            let status =
                                if let Some(v) = info.variants.iter().find(|v| &v.id == variant) {
                                    if let Some(ref zip) = v.zip_file {
                                        format!(" ({})", zip)
                                    } else {
                                        String::new()
                                    }
                                } else {
                                    String::new()
                                };
                            eprintln!("    - {}{}", variant, status);
                        }
                    }
                }
            }
        } else {
            eprintln!("No manifest found. Run 'snipper models download' first.");
        }
    }
}

fn handle_models_verify(category: Option<String>) {
    let models_dir = std::path::PathBuf::from("models");
    let manager = latexsnipper_model::ModelManager::new(models_dir);

    let manifest_path = std::path::PathBuf::from("models/model-manifest.json");
    if !manifest_path.exists() {
        eprintln!("No manifest found. Run 'snipper models download' first.");
        std::process::exit(1);
    }

    let manifest = match load_runtime_model_manifest(&manifest_path) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("Failed to load manifest: {}", e);
            std::process::exit(1);
        }
    };

    let categories = if let Some(cat) = category {
        vec![cat]
    } else {
        manifest.categories.keys().cloned().collect()
    };

    let mut all_valid = true;
    let mut total_files = 0;
    let mut verified_files = 0;

    for cat in &categories {
        if let Some(info) = manifest.categories.get(cat) {
            let variants = manager.list_installed(cat);
            if variants.is_empty() {
                eprintln!("  {} (not installed)", cat);
                continue;
            }

            for variant in &variants {
                if let Some(v) = info.variants.iter().find(|v| &v.id == variant) {
                    let dir = manager.variant_dir(cat, variant);
                    let mut missing = Vec::new();
                    let mut present = Vec::new();

                    for file in &v.files {
                        total_files += 1;
                        let file_path = dir.join(file);
                        if !file_path.exists() {
                            missing.push(file.as_str());
                            all_valid = false;
                        } else {
                            present.push(file.as_str());
                            verified_files += 1;
                        }
                    }

                    if missing.is_empty() {
                        eprintln!(
                            "  {}/{} - VERIFY_OK ({} files)",
                            cat,
                            variant,
                            present.len()
                        );
                    } else {
                        for m in &missing {
                            eprintln!("  {}/{} - MISSING: {}", cat, variant, m);
                        }
                    }
                }
            }
        }
    }

    eprintln!(
        "\nVerified {}/{} files across installed models.",
        verified_files, total_files
    );
    if all_valid {
        eprintln!("All model files present.");
        eprintln!(
            "Note: SHA-256 integrity is verified at download time. Re-download to re-verify."
        );
    } else {
        eprintln!("Some model files are missing. Run 'snipper models download' to re-download.");
        std::process::exit(1);
    }
}

// ── Job handlers ─────────────────────────────────────────────

fn handle_models_purge(
    category: Option<String>,
    variant: Option<String>,
    confirmed: bool,
) -> Result<(), CliFailure> {
    if !confirmed {
        return Err(CliFailure::new(
            CliExitCode::InvalidArguments,
            "refusing to remove models without --yes",
        ));
    }
    if let Some(value) = category.as_deref() {
        validate_storage_name(value, "category")?;
    }
    if let Some(value) = variant.as_deref() {
        validate_storage_name(value, "variant")?;
    }

    let models_dir = std::path::PathBuf::from("models");
    let manager = latexsnipper_model::ModelManager::new(models_dir.clone());
    let categories = if let Some(category) = category {
        vec![category]
    } else if models_dir.is_dir() {
        let mut names = std::fs::read_dir(&models_dir)
            .map_err(|error| CliFailure::new(CliExitCode::GenericFailure, error.to_string()))?
            .filter_map(Result::ok)
            .filter(|entry| entry.path().is_dir())
            .filter_map(|entry| entry.file_name().into_string().ok())
            .filter(|name| validate_storage_name(name, "category").is_ok())
            .collect::<Vec<_>>();
        names.sort();
        names
    } else {
        Vec::new()
    };

    let mut removed = 0usize;
    for category in categories {
        let variants = if let Some(variant) = variant.as_ref() {
            vec![variant.clone()]
        } else {
            manager.list_installed(&category)
        };
        for variant in variants {
            let directory = manager.variant_dir(&category, &variant);
            if !directory.is_dir() {
                continue;
            }
            manager
                .delete_variant(&category, &variant)
                .map_err(|error| CliFailure::new(CliExitCode::GenericFailure, error.to_string()))?;
            removed += 1;
            eprintln!("Removed {category}/{variant}");
        }
    }
    eprintln!("Removed {removed} installed model variant(s); manifest files were preserved.");
    Ok(())
}

fn handle_plugin_command(store_dir: &str, command: PluginCommand) -> Result<(), String> {
    let store_root = std::path::PathBuf::from(store_dir);
    let store = latexsnipper_plugin::PluginStore::new(store_root.clone());
    let registries =
        latexsnipper_plugin::SignedRegistryManager::new(store_root.join("signed-registries"));
    match command {
        PluginCommand::Registry { command } => {
            handle_plugin_registry_command(&registries, command)?;
        }
        PluginCommand::List => {
            let plugins = store.list().map_err(|error| error.to_string())?;
            let local_plugins = plugins
                .iter()
                .map(|plugin| {
                    serde_json::json!({
                        "plugin": plugin,
                        "trustState": local_plugin_trust_state(&plugin.manifest.class),
                    })
                })
                .collect::<Vec<_>>();
            let remote_plugins = registries
                .remote_store()
                .list()
                .map_err(|error| error.to_string())?;
            println!(
                "{}",
                serde_json::to_string_pretty(&serde_json::json!({
                    "schemaVersion": 2,
                    "storeDirectory": store.root(),
                    "plugins": &plugins,
                    "localPlugins": local_plugins,
                    "remotePlugins": remote_plugins,
                }))
                .map_err(|error| error.to_string())?
            );
        }
        PluginCommand::Search { query } => {
            let results = registries
                .search(query.as_deref())
                .map_err(|error| error.to_string())?;
            println!(
                "{}",
                serde_json::to_string_pretty(&serde_json::json!({
                    "schemaVersion": 1,
                    "results": results,
                }))
                .map_err(|error| error.to_string())?
            );
        }
        PluginCommand::Info { id } => {
            if let Some(plugin) = registries
                .remote_store()
                .get(&id)
                .map_err(|error| error.to_string())?
            {
                println!(
                    "{}",
                    serde_json::to_string_pretty(&plugin).map_err(|error| error.to_string())?
                );
                return Ok(());
            }
            let plugin = store
                .get(&id)
                .map_err(|error| error.to_string())?
                .ok_or_else(|| format!("Plugin '{id}' is not installed"))?;
            println!(
                "{}",
                serde_json::to_string_pretty(&plugin).map_err(|error| error.to_string())?
            );
        }
        PluginCommand::Verify { source } => {
            reject_remote_plugin_source(&source)?;
            let path = std::path::Path::new(&source);
            if path.exists() {
                let verification = store
                    .verify_package(path)
                    .map_err(|error| error.to_string())?;
                print_plugin_verification(&verification)?;
            } else {
                let plugin = registries
                    .remote_store()
                    .get(&source)
                    .map_err(|error| error.to_string())?
                    .ok_or_else(|| format!("Plugin '{source}' is not installed"))?;
                let verification = registries
                    .remote_store()
                    .verify_installed(&source)
                    .map_err(|error| error.to_string())?;
                println!(
                    "{}",
                    serde_json::to_string_pretty(&serde_json::json!({
                        "verified": true,
                        "executed": false,
                        "trustState": plugin.trust_state,
                        "provenance": plugin.provenance,
                        "package": verification,
                    }))
                    .map_err(|error| error.to_string())?
                );
            }
        }
        PluginCommand::Install { source } => {
            reject_remote_plugin_source(&source)?;
            let path = std::path::Path::new(&source);
            let installed = if path.exists() {
                serde_json::to_value(store.install(path).map_err(|error| error.to_string())?)
                    .map_err(|error| error.to_string())?
            } else {
                serde_json::to_value(
                    registries
                        .install(&source, env!("CARGO_PKG_VERSION"))
                        .map_err(|error| error.to_string())?,
                )
                .map_err(|error| error.to_string())?
            };
            println!(
                "{}",
                serde_json::to_string_pretty(&serde_json::json!({
                    "installed": installed,
                    "executed": false,
                    "message": "Package verified and installed disabled; no plugin code was executed",
                }))
                .map_err(|error| error.to_string())?
            );
        }
        PluginCommand::Update { id, all } => {
            let updated = if all {
                registries
                    .update_all(env!("CARGO_PKG_VERSION"))
                    .map_err(|error| error.to_string())?
            } else {
                let id = id.ok_or_else(|| "plugin update requires <id> or --all".to_string())?;
                vec![registries
                    .install(&id, env!("CARGO_PKG_VERSION"))
                    .map_err(|error| error.to_string())?]
            };
            println!(
                "{}",
                serde_json::to_string_pretty(&serde_json::json!({
                    "updated": updated,
                    "executed": false,
                }))
                .map_err(|error| error.to_string())?
            );
        }
        PluginCommand::Rollback { id } => {
            let plugin = registries
                .remote_store()
                .rollback(&id)
                .map_err(|error| error.to_string())?;
            println!(
                "{}",
                serde_json::to_string_pretty(&serde_json::json!({
                    "rolledBack": plugin,
                    "executed": false,
                }))
                .map_err(|error| error.to_string())?
            );
        }
        PluginCommand::Uninstall { id } => {
            if store.get(&id).map_err(|error| error.to_string())?.is_none()
                && registries
                    .remote_store()
                    .get(&id)
                    .map_err(|error| error.to_string())?
                    .is_some()
            {
                return Err(format!(
                    "Remote plugin '{id}' cannot be removed by the legacy uninstall path; disable it or revoke its trust first"
                ));
            }
            store.uninstall(&id).map_err(|error| error.to_string())?;
            println!("Plugin '{id}' uninstalled");
        }
        PluginCommand::Enable { id } => {
            if store.get(&id).map_err(|error| error.to_string())?.is_some() {
                let plugin = store
                    .set_enabled(&id, true)
                    .map_err(|error| error.to_string())?;
                println!(
                    "Plugin '{}' enabled in store metadata; execution still requires a compatible host",
                    plugin.manifest.id
                );
            } else {
                let plugin = registries
                    .remote_store()
                    .set_enabled(&id, true)
                    .map_err(|error| error.to_string())?;
                println!(
                    "Verified WASI plugin '{}' enabled; declared capabilities are now eligible for registration",
                    plugin.manifest.id
                );
            }
        }
        PluginCommand::Disable { id } => {
            if store.get(&id).map_err(|error| error.to_string())?.is_some() {
                let plugin = store
                    .set_enabled(&id, false)
                    .map_err(|error| error.to_string())?;
                println!("Plugin '{}' disabled", plugin.manifest.id);
            } else {
                let plugin = registries
                    .remote_store()
                    .set_enabled(&id, false)
                    .map_err(|error| error.to_string())?;
                println!("Verified WASI plugin '{}' disabled", plugin.manifest.id);
            }
        }
        PluginCommand::Revoke { id } => {
            let plugin = registries
                .remote_store()
                .revoke(&id)
                .map_err(|error| error.to_string())?;
            println!(
                "{}",
                serde_json::to_string_pretty(&plugin).map_err(|error| error.to_string())?
            );
        }
        PluginCommand::Doctor => {
            let plugins = store.list().map_err(|error| error.to_string())?;
            let checks = plugins
                .iter()
                .map(|plugin| match store.verify_installed(&plugin.manifest.id) {
                    Ok(verification) => serde_json::json!({
                        "id": plugin.manifest.id,
                        "class": plugin.manifest.class,
                        "enabled": plugin.enabled,
                        "trustState": local_plugin_trust_state(&plugin.manifest.class),
                        "verified": true,
                        "entrypointSha256": verification.entrypoint_sha256,
                        "executionHostAvailable": matches!(
                            plugin.manifest.class,
                            latexsnipper_plugin::PluginClass::IsolatedProcess
                        ),
                        "effectivePermissions": store.effective_permissions(&plugin.manifest.id).ok(),
                    }),
                    Err(error) => serde_json::json!({
                        "id": plugin.manifest.id,
                        "enabled": plugin.enabled,
                        "trustState": "quarantined",
                        "verified": false,
                        "error": error.to_string(),
                        "executionHostAvailable": false,
                        "effectivePermissions": serde_json::Value::Null,
                    }),
                })
                .collect::<Vec<_>>();
            let healthy = checks
                .iter()
                .all(|check| check["verified"].as_bool() == Some(true));
            let remote_store = registries.remote_store();
            let remote_plugins = remote_store.list().map_err(|error| error.to_string())?;
            let remote_checks = remote_plugins
                .iter()
                .map(
                    |plugin| match remote_store.verify_installed(&plugin.manifest.id) {
                        Ok(verification) => serde_json::json!({
                            "id": plugin.manifest.id,
                            "class": plugin.manifest.execution_class,
                            "trustState": plugin.trust_state,
                            "enabled": plugin.enabled,
                            "verified": true,
                            "artifactSha256": verification.artifact_sha256,
                            "executionHostAvailable": false,
                        }),
                        Err(error) => serde_json::json!({
                            "id": plugin.manifest.id,
                            "trustState": "quarantined",
                            "enabled": false,
                            "verified": false,
                            "error": error.to_string(),
                            "executionHostAvailable": false,
                        }),
                    },
                )
                .collect::<Vec<_>>();
            let remote_consistency = remote_store.doctor().map_err(|error| error.to_string())?;
            let remote_healthy = remote_consistency.healthy
                && remote_checks
                    .iter()
                    .all(|check| check["verified"].as_bool() == Some(true));
            println!(
                "{}",
                serde_json::to_string_pretty(&serde_json::json!({
                    "schemaVersion": 1,
                    "storeDirectory": store.root(),
                    "installed": plugins.len(),
                    "packageIntegrityHealthy": healthy && remote_healthy,
                    "isolatedProcessHostAvailable": true,
                    "nativeAbiHostAvailable": false,
                    "wasiComponentHostAvailable": false,
                    "brokeredPermissionEnforcement": true,
                    "nativeProcessOsSandboxed": false,
                    "responseBudgetScope": "response-file-observation",
                    "processTreeContainment": if cfg!(unix) { "unix-process-group" } else { "windows-job-object-after-spawn" },
                    "plugins": checks,
                    "remotePlugins": remote_checks,
                    "remoteStoreConsistency": remote_consistency,
                }))
                .map_err(|error| error.to_string())?
            );
            if !healthy || !remote_healthy {
                return Err("one or more installed plugin packages failed verification".to_string());
            }
        }
    }
    Ok(())
}

fn local_plugin_trust_state(class: &latexsnipper_plugin::PluginClass) -> &'static str {
    match class {
        latexsnipper_plugin::PluginClass::BuiltInRust => "trusted_built_in",
        latexsnipper_plugin::PluginClass::IsolatedProcess => "reviewed_local_native_process",
        latexsnipper_plugin::PluginClass::WasiComponent
        | latexsnipper_plugin::PluginClass::NativeAbi => "unverified",
    }
}

fn handle_plugin_registry_command(
    manager: &latexsnipper_plugin::SignedRegistryManager,
    command: PluginRegistryCommand,
) -> Result<(), String> {
    let value = match command {
        PluginRegistryCommand::List => serde_json::json!({
            "schemaVersion": 1,
            "registries": manager.list().map_err(|error| error.to_string())?,
        }),
        PluginRegistryCommand::Add { name, origin } => serde_json::to_value(
            manager
                .add(&name, &origin)
                .map_err(|error| error.to_string())?,
        )
        .map_err(|error| error.to_string())?,
        PluginRegistryCommand::Remove { name, yes } => {
            if !yes {
                return Err("registry removal requires explicit --yes confirmation".to_string());
            }
            serde_json::to_value(manager.remove(&name).map_err(|error| error.to_string())?)
                .map_err(|error| error.to_string())?
        }
        PluginRegistryCommand::Trust { name, root, yes } => {
            if !yes {
                return Err("trust-root changes require explicit --yes confirmation".to_string());
            }
            let path = std::path::Path::new(&root);
            let metadata = std::fs::metadata(path).map_err(|error| error.to_string())?;
            if !metadata.is_file() || metadata.len() > 8 * 1024 * 1024 {
                return Err("trust-root file is invalid or exceeds 8 MiB".to_string());
            }
            let bytes = std::fs::read(path).map_err(|error| error.to_string())?;
            let now = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map_err(|error| error.to_string())?
                .as_secs();
            serde_json::to_value(
                manager
                    .trust(&name, &bytes, now)
                    .map_err(|error| error.to_string())?,
            )
            .map_err(|error| error.to_string())?
        }
        PluginRegistryCommand::Refresh { name, offline } => {
            let now = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map_err(|error| error.to_string())?
                .as_secs();
            if let Some(name) = name {
                serde_json::to_value(
                    manager
                        .refresh(&name, offline, now)
                        .map_err(|error| error.to_string())?,
                )
                .map_err(|error| error.to_string())?
            } else {
                serde_json::to_value(
                    manager
                        .refresh_all(offline, now)
                        .map_err(|error| error.to_string())?,
                )
                .map_err(|error| error.to_string())?
            }
        }
    };
    println!(
        "{}",
        serde_json::to_string_pretty(&value).map_err(|error| error.to_string())?
    );
    Ok(())
}

fn reject_remote_plugin_source(source: &str) -> Result<(), String> {
    if source.contains("://") {
        return Err(
            "arbitrary URL plugin sources are forbidden; configure and trust a registry, then use a plugin ID"
                .to_string(),
        );
    }
    Ok(())
}

fn print_plugin_verification(
    verification: &latexsnipper_plugin::PluginVerification,
) -> Result<(), String> {
    println!(
        "{}",
        serde_json::to_string_pretty(&serde_json::json!({
            "verified": true,
            "executed": false,
            "manifest": verification.manifest,
            "manifestPath": verification.manifest_path,
            "entrypointPath": verification.entrypoint_path,
            "entrypointSha256": verification.entrypoint_sha256,
            "fileCount": verification.file_count,
            "totalBytes": verification.total_bytes,
        }))
        .map_err(|error| error.to_string())?
    );
    Ok(())
}

fn validate_storage_name(value: &str, label: &str) -> Result<(), CliFailure> {
    let path = std::path::Path::new(value);
    if value.is_empty()
        || value == "."
        || value == ".."
        || path.components().count() != 1
        || !matches!(
            path.components().next(),
            Some(std::path::Component::Normal(_))
        )
    {
        return Err(CliFailure::new(
            CliExitCode::InvalidArguments,
            format!("invalid model {label}: {value}"),
        ));
    }
    Ok(())
}

fn handle_job_run(input: &str, format: &str, output: Option<&str>, mode: &str) {
    use latexsnipper_engine::Job;

    let recognize_mode = match parse_recognize_mode(mode) {
        Some(m) => m,
        None => {
            eprintln!("Unknown recognize mode: '{}'", mode);
            return;
        }
    };

    // Create a job
    let mut job = Job::new(format!("job_{}", chrono_job_id()), input);

    eprintln!("Job '{}' created", job.id);
    eprintln!("  Input:  {}", input);
    eprintln!("  Format: {}", format);
    eprintln!("  Mode:   {}", mode);

    // Run the pipeline (reuse recognize logic)
    let document = match recognize_document(input, DocumentParseMode::default(), recognize_mode) {
        Ok(document) => document,
        Err(e) => {
            job.status = latexsnipper_engine::JobStatus::Failed;
            eprintln!("Job failed: {}", e);
            return;
        }
    };

    job.status = latexsnipper_engine::JobStatus::Completed;
    eprintln!("  Blocks: {}", document.block_count());

    // Export
    let resolved = resolve_format(format);
    let result = match resolved.as_str() {
        "latex" => DocumentConverter::new(OutputFormat::Latex).convert(&document),
        "markdown" => DocumentConverter::new(OutputFormat::MarkdownBlock).convert(&document),
        "typst" => DocumentConverter::new(OutputFormat::Typst).convert(&document),
        "html" => DocumentConverter::new(OutputFormat::Html).convert(&document),
        "mathml" => DocumentConverter::new(OutputFormat::MathML).convert(&document),
        "omml" => DocumentConverter::new(OutputFormat::OMML).convert(&document),
        "json" => serde_json::to_string_pretty(&document)
            .map_err(|error| latexsnipper_foundation::SnipperError::Conversion(error.to_string())),
        other => {
            eprintln!("Unsupported format: {}", other);
            return;
        }
    };

    match result {
        Ok(text) => {
            if let Some(path) = output {
                let _ = std::fs::write(path, &text);
                eprintln!("  Output: {}", path);
            } else {
                println!("{}", text);
            }
            // Record artifact
            job.add_artifact(
                "output_1",
                latexsnipper_ast::ArtifactKind::ConvertedText,
                output.unwrap_or("<stdout>"),
                None,
            );
            job.result = Some(text);
        }
        Err(e) => {
            job.status = latexsnipper_engine::JobStatus::Failed;
            job.add_diagnostic(latexsnipper_ast::Diagnostic::new(
                latexsnipper_ast::DiagnosticLevel::Error,
                "E_EXPORT",
                format!("Export failed: {}", e),
            ));
            eprintln!("Export error: {}", e);
        }
    }

    eprintln!("Job '{}' status: {:?}", job.id, job.status);
    if !job.diagnostics.is_empty() {
        eprintln!("  Diagnostics: {}", job.diagnostics.len());
        for d in &job.diagnostics {
            eprintln!("    [{:?}] {}: {}", d.level, d.code, d.message);
        }
    }
}

fn handle_job_inspect(job_id: &str) {
    eprintln!("Job '{}' inspection:", job_id);
    eprintln!("  (Job history is not persisted across sessions)");
    eprintln!("  Use --help to see all job options.");
}

/// Generate a simple unique job ID based on timestamp.
fn chrono_job_id() -> String {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default();
    format!("{:x}", now.as_nanos())
}

fn build_capability_matrix() -> Result<CapabilityMatrix, String> {
    let mut matrix = latexsnipper_conversion::DocumentExportService::capability_matrix();
    let remote_root = std::path::PathBuf::from(".snipper/plugins/signed-registries/remote");
    if remote_root.exists() {
        latexsnipper_plugin::RemotePluginStore::new(remote_root)
            .extend_capability_matrix(&mut matrix)
            .map_err(|error| error.to_string())?;
    }
    Ok(matrix)
}
/// Filter capability entries by input/output format.
fn filter_capabilities(
    matrix: &CapabilityMatrix,
    input_filter: Option<&str>,
    output_filter: Option<&str>,
) -> CapabilityMatrix {
    let input_filter = input_filter.map(|s| s.to_ascii_lowercase());
    let output_filter = output_filter.map(|s| s.to_ascii_lowercase());

    let entries: Vec<FormatCapability> = matrix
        .entries
        .iter()
        .filter(|e| {
            let input_match = match &input_filter {
                Some(ref f) => e
                    .input
                    .as_deref()
                    .map(|i| i.to_ascii_lowercase().contains(f.as_str()))
                    .unwrap_or(false),
                None => true,
            };
            let output_match = match &output_filter {
                Some(ref f) => e
                    .output
                    .as_deref()
                    .map(|o| o.to_ascii_lowercase().contains(f.as_str()))
                    .unwrap_or(false),
                None => true,
            };
            input_match && output_match
        })
        .cloned()
        .collect();

    CapabilityMatrix {
        schema_version: matrix.schema_version.clone(),
        entries,
    }
}

fn format_fidelity(f: &FidelityLevel) -> &'static str {
    match f {
        FidelityLevel::Lossless => "lossless",
        FidelityLevel::MostlyLossless => "mostly",
        FidelityLevel::SemanticOnly => "semantic",
        FidelityLevel::VisualOnly => "visual",
        FidelityLevel::BestEffort => "best-effort",
    }
}

fn format_losses(losses: &[LossKind]) -> String {
    if losses.is_empty() {
        "none".to_string()
    } else {
        losses
            .iter()
            .map(|l| match l {
                LossKind::StyleLoss => "style",
                LossKind::LayoutLoss => "layout",
                LossKind::AssetRasterized => "raster",
                LossKind::FormulaDowngraded => "formula",
                LossKind::TableStructureLoss => "table-struct",
                LossKind::OfficeObjectPreviewOnly => "office-preview",
                LossKind::UnsupportedAnnotation => "annotation",
            })
            .collect::<Vec<_>>()
            .join(", ")
    }
}

fn print_capabilities_table(matrix: &CapabilityMatrix) {
    println!();
    println!("  LaTeXSnipper Core — Conversion Capabilities");
    println!("  Schema v{}", matrix.schema_version);
    println!();
    println!(
        "  {:<36} {:<10} {:<8} {:<26}",
        "Conversion", "Fidelity", "Formulas", "Loss"
    );
    println!("  {:-<36} {:-<10} {:-<8} {:-<26}", "", "", "", "");
    for entry in &matrix.entries {
        let label = format!(
            "{} -> {}",
            entry.input.as_deref().unwrap_or("?"),
            entry.output.as_deref().unwrap_or("?")
        );
        let formulas = if entry.supports_formula { "✓" } else { "✗" };
        println!(
            "  {:<36} {:<10} {:<8} {:<26}",
            label,
            format_fidelity(&entry.fidelity),
            formulas,
            format_losses(&entry.known_loss)
        );
    }
    println!();
    println!("  Legend: ✓=supported  ✗=not supported");
    println!("  Run 'snipper capabilities --format markdown' for detailed view.");
}

fn print_capabilities_markdown(matrix: &CapabilityMatrix) {
    println!("# LaTeXSnipper Core — Capability Matrix");
    println!();
    println!("Schema version: {}", matrix.schema_version);
    println!();
    for entry in &matrix.entries {
        let from = entry.input.as_deref().unwrap_or("?");
        let to = entry.output.as_deref().unwrap_or("?");
        println!("## {} → {}", from, to);
        println!();
        println!("| Property | Value |");
        println!("|---|---|");
        println!("| Fidelity | {} |", format_fidelity(&entry.fidelity));
        println!(
            "| Formulas | {} |",
            if entry.supports_formula { "✓" } else { "✗" }
        );
        println!(
            "| Tables   | {} |",
            if entry.supports_table { "✓" } else { "✗" }
        );
        println!(
            "| Images   | {} |",
            if entry.supports_image { "✓" } else { "✗" }
        );
        println!(
            "| SVG      | {} |",
            if entry.supports_svg { "✓" } else { "✗" }
        );
        println!(
            "| Style    | {} |",
            if entry.supports_style { "✓" } else { "✗" }
        );
        println!(
            "| Layout   | {} |",
            if entry.supports_layout { "✓" } else { "✗" }
        );
        println!(
            "| Office   | {} |",
            if entry.supports_office_objects {
                "✓"
            } else {
                "✗"
            }
        );
        println!("| Known loss | {} |", format_losses(&entry.known_loss));
        if !entry.notes.is_empty() {
            println!("| Notes | {} |", entry.notes.join("; "));
        }
        println!();
    }
}

fn play_game() {
    use std::time::Instant;

    // ========================================================================
    // Puzzle Pool: (ascii_art, answer, hint, difficulty)
    // difficulty: 1=beginner, 2=intermediate, 3=advanced
    // ========================================================================
    struct Puzzle {
        art: &'static str,
        answer: &'static str,
        hint: &'static str,
        difficulty: u8,
    }

    let all_puzzles: Vec<Puzzle> = vec![
        // --- Difficulty 1: Beginner ---
        Puzzle {
            art: "  x",
            answer: "x",
            hint: "just the letter x",
            difficulty: 1,
        },
        Puzzle {
            art: "  a + b",
            answer: "a+b",
            hint: "a plus b",
            difficulty: 1,
        },
        Puzzle {
            art: "  42",
            answer: "42",
            hint: "the number 42",
            difficulty: 1,
        },
        Puzzle {
            art: "  E = mc^2",
            answer: "E=mc^2",
            hint: "E equals mc squared",
            difficulty: 1,
        },
        Puzzle {
            art: "  a^2",
            answer: "a^2",
            hint: "a superscript 2",
            difficulty: 1,
        },
        Puzzle {
            art: "  x_i",
            answer: "x_i",
            hint: "x subscript i",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\pi",
            answer: "\\pi",
            hint: "Greek letter pi",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\alpha",
            answer: "\\alpha",
            hint: "first Greek letter",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\beta",
            answer: "\\beta",
            hint: "second Greek letter",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\gamma",
            answer: "\\gamma",
            hint: "third Greek letter",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\infty",
            answer: "\\infty",
            hint: "infinity symbol",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\pm",
            answer: "\\pm",
            hint: "plus-minus sign",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\times",
            answer: "\\times",
            hint: "multiplication sign",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\leq",
            answer: "\\leq",
            hint: "less than or equal",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\geq",
            answer: "\\geq",
            hint: "greater than or equal",
            difficulty: 1,
        },
        Puzzle {
            art: "  \\neq",
            answer: "\\neq",
            hint: "not equal sign",
            difficulty: 1,
        },
        // --- Difficulty 2: Intermediate ---
        Puzzle {
            art: "  a / b\n  ---",
            answer: "\\frac{a}{b}",
            hint: "fraction a over b",
            difficulty: 2,
        },
        Puzzle {
            art: "  ___\n / 25",
            answer: "\\sqrt{25}",
            hint: "square root of 25",
            difficulty: 2,
        },
        Puzzle {
            art: "  ___\n / a+b",
            answer: "\\sqrt{a+b}",
            hint: "square root of sum",
            difficulty: 2,
        },
        Puzzle {
            art: "  n\n  \\ Sigma\n  i=1",
            answer: "\\sum_{i=1}^{n}",
            hint: "sum from i=1 to n",
            difficulty: 2,
        },
        Puzzle {
            art: "  b\n  \\ Integral\n  a",
            answer: "\\int_{a}^{b}",
            hint: "definite integral a to b",
            difficulty: 2,
        },
        Puzzle {
            art: "  \\rightarrow",
            answer: "\\rightarrow",
            hint: "right arrow",
            difficulty: 2,
        },
        Puzzle {
            art: "  \\leftarrow",
            answer: "\\leftarrow",
            hint: "left arrow",
            difficulty: 2,
        },
        Puzzle {
            art: "  \\theta",
            answer: "\\theta",
            hint: "Greek letter theta",
            difficulty: 2,
        },
        Puzzle {
            art: "  \\lambda",
            answer: "\\lambda",
            hint: "wavelength symbol",
            difficulty: 2,
        },
        Puzzle {
            art: "  \\sigma",
            answer: "\\sigma",
            hint: "standard deviation",
            difficulty: 2,
        },
        Puzzle {
            art: "  \\omega",
            answer: "\\omega",
            hint: "angular frequency",
            difficulty: 2,
        },
        Puzzle {
            art: "  \\nabla",
            answer: "\\nabla",
            hint: "del operator",
            difficulty: 2,
        },
        Puzzle {
            art: "  \\partial",
            answer: "\\partial",
            hint: "partial derivative",
            difficulty: 2,
        },
        Puzzle {
            art: "  a \\cdot b",
            answer: "a \\cdot b",
            hint: "dot product notation",
            difficulty: 2,
        },
        Puzzle {
            art: "  x \\in R",
            answer: "x \\in \\mathbb{R}",
            hint: "x is in reals (use mathbb)",
            difficulty: 2,
        },
        Puzzle {
            art: "  A \\cup B",
            answer: "A \\cup B",
            hint: "A union B",
            difficulty: 2,
        },
        // --- Difficulty 3: Advanced ---
        Puzzle {
            art: "    n\n    \\ Sigma   k^2\n    k=1",
            answer: "\\sum_{k=1}^{n} k^2",
            hint: "sum of squares",
            difficulty: 3,
        },
        Puzzle {
            art: "       ___\n      / a\n     / ---\n    /  b",
            answer: "\\sqrt{\\frac{a}{b}}",
            hint: "square root of fraction",
            difficulty: 3,
        },
        Puzzle {
            art: "  d/dx [ f(x) ]",
            answer: "\\frac{d}{dx} [ f(x) ]",
            hint: "derivative notation",
            difficulty: 3,
        },
        Puzzle {
            art: "  lim\n  x->0  sin(x)/x",
            answer: "\\lim_{x \\to 0} \\frac{\\sin(x)}{x}",
            hint: "famous limit",
            difficulty: 3,
        },
        Puzzle {
            art: "    n\n    \\ Prod   i\n    i=1",
            answer: "\\prod_{i=1}^{n} i",
            hint: "product notation",
            difficulty: 3,
        },
        Puzzle {
            art: "  e^{i\\pi} + 1 = 0",
            answer: "e^{i\\pi} + 1 = 0",
            hint: "Euler's identity",
            difficulty: 3,
        },
        Puzzle {
            art: "  | \\psi > ",
            answer: "|\\psi\\rangle",
            hint: "ket notation (bra-ket)",
            difficulty: 3,
        },
        Puzzle {
            art: "  < \\phi | \\psi >",
            answer: "\\langle \\phi | \\psi \\rangle",
            hint: "inner product (bra-ket)",
            difficulty: 3,
        },
        Puzzle {
            art: "  A^T",
            answer: "A^T",
            hint: "matrix transpose",
            difficulty: 3,
        },
        Puzzle {
            art: "  det(A)",
            answer: "\\det(A)",
            hint: "matrix determinant",
            difficulty: 3,
        },
        Puzzle {
            art: "  \\forall x \\in X",
            answer: "\\forall x \\in X",
            hint: "for all x in X",
            difficulty: 3,
        },
        Puzzle {
            art: "  \\exists x",
            answer: "\\exists x",
            hint: "there exists x",
            difficulty: 3,
        },
        Puzzle {
            art: "  \\oint E \\cdot dl",
            answer: "\\oint \\mathbf{E} \\cdot d\\mathbf{l}",
            hint: "line integral (closed)",
            difficulty: 3,
        },
        Puzzle {
            art: "  \\binom{n}{k}",
            answer: "\\binom{n}{k}",
            hint: "binomial coefficient",
            difficulty: 3,
        },
        Puzzle {
            art: "  a \\equiv b (mod n)",
            answer: "a \\equiv b \\pmod{n}",
            hint: "modular congruence",
            difficulty: 3,
        },
        Puzzle {
            art: "  \\int_0^\\infty e^{-x} dx",
            answer: "\\int_0^{\\infty} e^{-x} dx",
            hint: "improper integral",
            difficulty: 3,
        },
    ];

    // ========================================================================
    // Title Screen
    // ========================================================================
    println!();
    println!("  ╔══════════════════════════════════════════════════╗");
    println!("  ║       LaTeX Math Rendering Challenge             ║");
    println!("  ╠══════════════════════════════════════════════════╣");
    println!("  ║  See the math art below. Type the LaTeX code!    ║");
    println!("  ║                                                  ║");
    println!("  ║  Commands:                                       ║");
    println!("  ║    quit   - exit game                            ║");
    println!("  ║    hint   - reveal next character (-50 pts)      ║");
    println!("  ║    skip   - skip question (-100 pts)             ║");
    println!("  ║    answer - reveal answer (0 pts)                ║");
    println!("  ║                                                  ║");
    println!("  ║  Scoring:                                        ║");
    println!("  ║    Base: 100 pts    Streak bonus: +50 per combo  ║");
    println!("  ║    Speed bonus: up to +50 pts for fast answers   ║");
    println!("  ╚══════════════════════════════════════════════════╝");
    println!();

    // ========================================================================
    // Difficulty Selection
    // ========================================================================
    println!("  Select difficulty:");
    println!("    1) Beginner   - basic symbols and simple expressions");
    println!("    2) Intermediate - fractions, roots, sums");
    println!("    3) Advanced   - calculus, linear algebra, logic");
    println!("    4) Mixed      - all difficulties shuffled");
    print!("  Choice [1/2/3/4] > ");
    io::stdout().flush().unwrap();

    let mut diff_input = String::new();
    io::stdin().read_line(&mut diff_input).unwrap();
    let difficulty = match diff_input.trim() {
        "1" => 1u8,
        "2" => 2,
        "3" => 3,
        _ => 4, // mixed
    };

    // Filter and shuffle puzzles
    let mut puzzles: Vec<&Puzzle> = if difficulty == 4 {
        all_puzzles.iter().collect()
    } else {
        all_puzzles
            .iter()
            .filter(|p| p.difficulty == difficulty)
            .collect()
    };

    // Simple seeded shuffle using Fisher-Yates with a basic PRNG
    let seed = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_millis() as u64;
    let mut rng_state = seed;
    for i in (1..puzzles.len()).rev() {
        rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1);
        let j = (rng_state >> 33) as usize % (i + 1);
        puzzles.swap(i, j);
    }

    let total_rounds = puzzles.len().min(15); // Cap at 15 rounds
    let puzzles = &puzzles[..total_rounds];

    // ========================================================================
    // Game Loop
    // ========================================================================
    let mut score: i64 = 0;
    let mut streak: u32 = 0;
    let mut correct: u32 = 0;
    let mut hints_used: u32 = 0;
    let game_start = Instant::now();

    println!();
    println!("  Starting {} rounds. Good luck!", total_rounds);
    println!();

    for (round, puzzle) in puzzles.iter().enumerate() {
        let round_num = round + 1;
        let diff_label = match puzzle.difficulty {
            1 => "Beginner",
            2 => "Intermediate",
            _ => "Advanced",
        };

        // Header
        println!(
            "  ┌─ Round {}/{} ─────────────────────────────────",
            round_num, total_rounds
        );
        println!("  │ Difficulty: {}", diff_label);
        if streak >= 3 {
            println!("  │ Streak: {}x (+{} bonus)", streak, streak * 50);
        }
        println!("  │");
        println!("  │  What is the LaTeX for this?");

        // Render ASCII art
        for line in puzzle.art.lines() {
            println!("  │    {}", line);
        }
        println!("  │");

        // Hint tracking
        let mut revealed_hint = false;
        let mut hint_chars = 0usize;

        // Input loop for this round
        let round_start = Instant::now();
        let mut answered = false;

        while !answered {
            print!("  └─> ");
            io::stdout().flush().unwrap();

            let mut guess = String::new();
            io::stdin().read_line(&mut guess).unwrap();
            let trimmed = guess.trim();

            match trimmed {
                "quit" | "q" | "exit" => {
                    println!();
                    print_final_stats(score, correct, total_rounds as u32, hints_used, &game_start);
                    return;
                }
                "hint" | "h" => {
                    if hint_chars < puzzle.answer.len() {
                        hint_chars += 1;
                        revealed_hint = true;
                        let partial: String = puzzle.answer.chars().take(hint_chars).collect();
                        let penalty = 50;
                        score -= penalty;
                        hints_used += 1;
                        println!("  [HINT] (cost: -{} pts): {}", penalty, partial);
                        println!("  [HINT] Full hint: {}", puzzle.hint);
                    } else {
                        println!(
                            "  [HINT] No more characters to reveal. Full hint: {}",
                            puzzle.hint
                        );
                    }
                    continue;
                }
                "skip" | "s" => {
                    score -= 100;
                    streak = 0;
                    println!("  [SKIP] Skipped (-100 pts). Answer was: {}", puzzle.answer);
                    println!();
                    break;
                }
                "answer" | "a" => {
                    println!("  [ANSWER] {}", puzzle.answer);
                    streak = 0;
                    println!();
                    break;
                }
                _ => {}
            }

            // Normalize: remove backslash for comparison flexibility
            let normalize = |s: &str| -> String {
                s.chars()
                    .filter(|c| !c.is_whitespace())
                    .collect::<String>()
                    .to_lowercase()
            };

            let guess_norm = normalize(trimmed);
            let answer_norm = normalize(puzzle.answer);

            if guess_norm == answer_norm {
                // Correct!
                let elapsed = round_start.elapsed().as_secs();
                let speed_bonus: i64 = if elapsed <= 3 {
                    50
                } else if elapsed <= 8 {
                    30
                } else if elapsed <= 15 {
                    10
                } else {
                    0
                };
                streak += 1;
                let streak_bonus = (streak.saturating_sub(1)) as i64 * 50;
                let base = 100i64;
                let total_pts = base + streak_bonus + speed_bonus;
                score += total_pts;
                correct += 1;

                println!();
                println!(
                    "  [CORRECT] +{} pts (base:{} streak:{} speed:{})",
                    total_pts, base, streak_bonus, speed_bonus
                );
                if streak >= 3 {
                    println!("  [STREAK] {}x streak! Keep it going!", streak);
                }
                println!();
                answered = true;
            } else {
                // Check Levenshtein for near-miss
                let dist = levenshtein_distance(&guess_norm, &answer_norm);
                if dist <= 2 && !guess_norm.is_empty() {
                    println!("  [CLOSE] But not quite. (edit distance: {})", dist);
                } else if revealed_hint {
                    println!("  [WRONG] Try again or type 'skip'.");
                } else {
                    println!("  [WRONG] Try again, or type 'hint' for help.");
                }
            }
        }
    }

    // ========================================================================
    // Final Stats
    // ========================================================================
    print_final_stats(score, correct, total_rounds as u32, hints_used, &game_start);
}

fn print_final_stats(
    score: i64,
    correct: u32,
    total: u32,
    hints_used: u32,
    start: &std::time::Instant,
) {
    let elapsed = start.elapsed();
    let mins = elapsed.as_secs() / 60;
    let secs = elapsed.as_secs() % 60;
    let accuracy = if total > 0 {
        (correct as f64 / total as f64 * 100.0) as u32
    } else {
        0
    };

    let rank = match score {
        s if s >= 2000 => "Grandmaster",
        s if s >= 1500 => "LaTeX Wizard",
        s if s >= 1000 => "Math Artist",
        s if s >= 500 => "Formula Apprentice",
        s if s >= 200 => "Symbol Explorer",
        _ => "Keep Practicing!",
    };

    println!("  ╔══════════════════════════════════════════════════╗");
    println!("  ║              Game Over!                          ║");
    println!("  ╠══════════════════════════════════════════════════╣");
    println!(
        "  ║  Score:       {:>6} pts                          ║",
        score
    );
    println!(
        "  ║  Correct:     {}/{} ({:>3}%)                      ║",
        correct, total, accuracy
    );
    println!(
        "  ║  Hints used:  {:>6}                               ║",
        hints_used
    );
    println!(
        "  ║  Time:        {:>2}:{:02}                               ║",
        mins, secs
    );
    println!("  ║  Rank:        {:<34} ║", rank);
    println!("  ╚══════════════════════════════════════════════════╝");
    println!();

    // ASCII art based on score
    if score >= 1500 {
        println!("       *  *  *  *  *");
        println!("      *  LA TEX  *");
        println!("       *  MASTER *");
        println!("        * * * * *");
    } else if score >= 500 {
        println!("      \\frac{{success}}{{practice}} = \\infty");
    } else {
        println!("      Keep going! \\int practice \\, dx = mastery");
    }
    println!();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resolves_all_public_format_aliases() {
        assert_eq!(resolve_format("latex_display"), "latex_display");
        assert_eq!(resolve_format("LATEX_EQUATION"), "latex_equation");
        assert_eq!(resolve_format("markdown_inline"), "markdown_inline");
        assert_eq!(resolve_format("latex"), "latex");
        assert_eq!(suggest_format("equationlatex"), Some("latex_equation"));
    }

    #[test]
    fn renders_a_single_formula_to_omml() {
        let output = render_formula(r"\frac{a}{b}", Some("omml")).unwrap();
        assert!(output.contains("<m:oMath"));
        assert!(output.contains("<m:f>"));
        assert!(output.contains("http://schemas.openxmlformats.org/officeDocument/2006/math"));
    }

    #[test]
    fn preserves_the_default_latex_roundtrip() {
        let output = render_formula(r"x^2", None).unwrap();
        assert!(output.contains('x'));
        assert!(output.contains('2'));
    }

    #[test]
    fn rejects_visual_single_formula_targets() {
        let error = render_formula("x", Some("png")).unwrap_err();
        assert!(error.contains("unsupported single-formula target"));
    }

    #[test]
    fn recognition_formats_route_through_the_unified_export_registry() {
        assert!(matches!(
            resolve_cli_target("text"),
            Some(CliTarget::Export(ExportFormat::PlainText))
        ));
        assert!(matches!(
            resolve_cli_target("pdf"),
            Some(CliTarget::Export(ExportFormat::Pdf))
        ));
    }

    #[test]
    fn parses_openocr_modes() {
        assert_eq!(
            parse_document_parse_mode("openocr-text"),
            Some(DocumentParseMode::OpenOcrText)
        );
        assert_eq!(
            parse_document_parse_mode("opendoc_hybrid"),
            Some(DocumentParseMode::OpenDocHybrid)
        );
        assert!(matches!(
            parse_recognize_mode("text"),
            Some(RecognizeMode::Text)
        ));
        assert!(matches!(
            parse_recognize_mode("mixed"),
            Some(RecognizeMode::Mixed)
        ));
        assert!(matches!(
            parse_recognize_mode("cropped-formula"),
            Some(RecognizeMode::CroppedFormula)
        ));
    }
}
